# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

from pathlib import Path
import random

import clr
from System import Enum, Int32, Double

class GridDistortion(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self,
            field=1,
            wavelength=1,
            symmetric_magnification=False,
            scale_factor=1.0,
            aspect=1.0,
            field_width=0.0,
            grid_number=2
            ):
        '''
        Runs a Grid Distortion analysis

        There is no IAR_ so need to save the results to disk and parse.  Output only has 8 digits
        '''
        
        # validate grid number
        grid_number = max(min(int(grid_number - (grid_number % 2)), 100), 2)

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.GridDistortion)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Field.SetFieldNumber(field)
        win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.SymmetricMagnification = symmetric_magnification
        win_settings.ScaleFactor = scale_factor
        win_settings.Aspect = aspect
        win_settings.FieldWidth = field_width
        win_settings.GridNumber = grid_number

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # get a random file to save the data
        fn = Path(self.zos.TheSystem.SystemFile).parent / f'grid_distortion_{random.randint(100000000, 999999999)}.txt'
        res.GetTextFile(str(fn))

        start = None
        nrows = 0
        # find the start and end of the data
        encoding = self.zos.detect_encoding(fn)
        with open(fn, 'r', encoding=encoding) as file:
            for lineno, line in enumerate(file):
                parts = line.split()
                parts = [s for s in parts if s]

                if start is None:
                    if len(parts) > 0 and parts[0] == 'i':
                        start = lineno + 1
                else:
                    if line.strip() == '':
                        break
                    nrows += 1
                    
        df = pd.read_csv(
            fn,
            sep=r'\s+',
            encoding=encoding,
            skiprows=start,
            nrows=nrows,
            header=None
        )

        # add the header columns
        df.columns = ['i', 'j', 'x_field', 'y_field', 'r_field', 'predicted_x', 'predicted_y', 'real_x', 'real_y', 'distortion']

        # strip percent sign & convert to float
        df['distortion'] = df['distortion'].str.rstrip('%').astype('float') / 100.0

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'field': win_settings.Field.GetFieldNumber(),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'symmetric_magnification': win_settings.SymmetricMagnification,
            'scale_factor': win_settings.ScaleFactor,
            'aspect': win_settings.Aspect,
            'field_width': win_settings.Aspect,
            'grid_number': win_settings.GridNumber
        }

        data = df.to_json(orient='records')

        win.Close()

        # delete the file
        if fn.is_file():
            fn.unlink()

        return {'type': 'scatter', 'settings': settings, 'header': header, 'data': [data]}
    
    

    

if __name__ == '__main__':
    pass
