# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class Transmission(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav
    
    def run(self, 
        field=1, 
        wavelength=0, 
        number_of_rays=51
        ):
        '''
        Runs a Ray Fan analysis

        Use `wavelength=0` for all wavelengths
        Use `field=0` for all fields
        Use `surface=0` for the Image surface
        '''

        wave = self.get_pwav() if wavelength == 0 else wavelength


        # get the normalized pupil coordinates
        pupil = list(np.linspace(-1, 1, number_of_rays))
        nsur = self.zos.TheSystem.LDE.NumberOfSurfaces - 1 

        output = []
        for p in pupil:
            output.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CODA, nsur, wave, field, 0, p, 0, 0, 0))
            output.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CODA, nsur, wave, field, 0, 0, p, 0, 0))


        
        one_output = {}
        one_output.update({'description': 'transmission fan'})
        one_output.update({'xlabel': f'Pupil Zone'})
        one_output.update({'xdata': pupil})
        one_output.update({'series_labels': ['Px', 'Py']})
        one_output.update({'num_series': 2})
        one_output.update({'ydata': output})

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': 'TransmissionFan',
            'field': field,
            'wavelength': wave,
            'number_of_rays': number_of_rays
        }

        data = [one_output]

        header = []

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
