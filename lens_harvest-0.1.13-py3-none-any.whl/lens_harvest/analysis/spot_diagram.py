# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# commmon imports across all files
from ..connect import Connect
import numpy as np
import pandas as pd

# enum parsing for `ZOSAPI` namespace
import clr
from System import Enum

# reading/writing merit function files
import uuid
from pathlib import Path

# plotting
import itertools
import matplotlib.pyplot as plt

class SpotDiagram(object):
    '''
    Mimics both a Standard Spot Diagram and a Through Focus Spot Diagram.
    The only difference between these 2:
        - Standard Spot Diagram      : has `DirectionCosine`, does not have `DeltaFocus`
        - Through Focus Spot Diagram : has `DeltaFocus`, does not have `DirectionCosine`
    '''
    def __init__(self, mod_sys = None):
        # connect to OpticStudio
        self.zos = Connect()

        if mod_sys:
            self.TheSystem = mod_sys
        else:
            self.TheSystem = self.zos.TheSystem.CopySystem()
        
        # constants for the system
        self.pwav = None
    def __del__(self):
        # close the system...needed if the Spot Diagram or Spot Diagram Through Focus is used inside a loop
        # mrh: might need to add more checks to make sure copied systems are actually properly closed
        # self.TheSystem.Close(False)
        pass

    def get_normalized_field_coordinates(self, field_number=1):
        if field_number < 1:
            field_number = 1
        if field_number > self.TheSystem.SystemData.Fields.NumberOfFields:
            field_number = self.TheSystem.SystemData.Fields.NumberOfFields
        
        # determine maximum field values
        mx = 0
        my = 0
        for f in range(1, self.TheSystem.SystemData.Fields.NumberOfFields + 1):
            field = self.TheSystem.SystemData.Fields.GetField(f)
            if field.X > mx: mx = field.X
            if field.Y > my: my = field.Y
        
        # determine if radial or rectangular normalization
        if self.TheSystem.SystemData.Fields.Normalization == self.zos.ZOSAPI.SystemData.FieldNormalizationType.Radial:
            my = (mx*mx + my*my)**0.5
            mx = my
        
        # get the field coordinates & normalized values
        field = self.TheSystem.SystemData.Fields.GetField(field_number)
        hx = 0.0 if abs(mx) < 1e-10 else field.X / mx
        hy = 0.0 if abs(my) < 1e-10 else field.Y / my

        return (hx, hy)

    def _get_hexapolar(self, ray_density):
        px = [
            (r / ray_density) * np.cos(np.deg2rad(60 - (60 / r) * a))
            for r in range(1, ray_density + 1)
            for a in range(6 * r)
        ]
        py = [
            (r / ray_density) * np.sin(np.deg2rad(60 - (60 / r) * a))
            for r in range(1, ray_density + 1)
            for a in range(6 * r)
        ]
        
        # always insert the chief ray
        px.insert(0, 0)
        py.insert(0, 0)

        return (px, py)
    def _get_square(self, ray_density):
        step = 1 / ray_density
        coords = np.arange(-1.0, 1.0 + step, step)

        px = [x for x in coords for y in coords if x**2 + y**2 <= 1]
        py = [y for x in coords for y in coords if x**2 + y**2 <= 1]

        return (px, py)
    def _get_dither(self, ray_density):
        # dithered is not truly random because it needs to be 'deterministic' from run-to-run in an optimizer
        
        # px = oldpx + dither * (2.0*random_double(X) - 1.0);
        # py = oldpy + dither * (2.0*random_double(X) - 1.0);

        res = ([], [])

        return res

    def _p(self, terms=10):
        z = 0
        return ' ' + ' '.join([f"{z:.12e}"] * terms) + '\n'

    def _normalized_field_to_number(self, df, lookup):
        # build reverse lookup: (hx, hy) → field
        tol = 1e-10
        decimals = 10

        reverse_lookup = {
            (round(hx, decimals), round(hy, decimals)): field
            for field, (hx, hy) in lookup.items()
        }

        # round your dataframe columns
        hx_r = df['hx'].round(decimals)
        hy_r = df['hy'].round(decimals)

        # map using tuples
        df['field'] = list(zip(hx_r, hy_r))
        df['field'] = df["field"].map(reverse_lookup)

        # `field`` is appended to the end but let's pop it to the right location
        df.insert(3, 'field', df.pop('field'))
        
        # drop extra columns to reduce memory and disk size
        df = df.drop(columns=['surf', 'hx', 'hy'])

        # finally pivot the dataframe so we have actually have 1 row representing a single point
        df = (
            df.pivot_table(
                index=["wave", "field", "px", "py"],  # uniquely identifies a point
                columns="oper",
                values="value"
            )
            .reset_index()
        )

        return df

    def calculate_summary(self, df, ref):
        # --- Step 2: build reference dataframe ---
        ref_df = pd.DataFrame(ref).rename(
            columns={"f": "field", "w": "wave", "x": "rx", "y": "ry"}
        )
        
        # --- Step 3: merge reference onto each row ---
        xy = df.merge(ref_df, on=["wave", "field"], how="left")

        # sanity check (optional but smart)
        if xy[["rx", "ry"]].isna().any().any():
            raise ValueError("Missing reference values for some (wave, field)")

        # --- Step 4: compute radius per row ---
        dx = xy["REAX"] - xy["rx"]
        dy = xy["REAY"] - xy["ry"]
        xy["r"] = np.sqrt(dx * dx + dy * dy)

        # --- Step 5: aggregate per (wave, field) ---
        stats = (
            xy.groupby(["wave", "field"])["r"]
            .agg(
                rms=lambda x: np.sqrt(np.mean(x**2)) * 1000,
                geo=lambda x: x.max() * 1000 
            )
            .reset_index()
        )

        return stats

    def run(self, 
            field=0, 
            surface=0,
            wavelength=0,
            pattern='hexapolar',
            refer_to='chiefray',
            ray_density=6,
            show_airy_disk=True,
            config_number = 1
            ):
        '''
        Mimics a Standard Spot Diagram and Through Focus Spot Diagram.
        The ZOS-API does not actually have this hooked up so we'll need to manually 
        recreate the analysis.  While there is a `RayTrace.dll` that helps with 
        high overhead methods like `AddRay` or `GetNextResult`, we can get all the 
        information from the MFE.  So, this uses Python's Context Manager to write 
        a `.mf` file, load, calculate, & save the `.mf`, then parse for the data.
        In testing, this tends to be way faster for a large number of rays

        Settings not implemented:
            - use_polarization
            - scatter_rays
            - direction_cosine
        '''
        use_polarization=False
        scatter_rays=False
        # print(f'last surface : {self.TheSystem.LDE.GetSurfaceAt(self.TheSystem.LDE.NumberOfSurfaces - 2).Thickness}')
        # self.TheSystem.SaveAs(r'c:\temp\fts.zmx')
        # there is no analysis to open
        mfdir = Path(self.zos.TheApplication.ZemaxDataDir) / 'MeritFunction'
        mf = mfdir / f'{uuid.uuid4().hex}.mf'

        # determine the correct image surface
        if surface == 0:
            surface = self.TheSystem.LDE.NumberOfSurfaces - 1

        # get the normalized pupil coordinates
        if pattern.lower() == 'hexapolar':
            pupil = self._get_hexapolar(ray_density)
        elif pattern.lower() == 'dithered':
            pass
        else:
            pupil = self._get_square(ray_density)

        # build a field<->normalized_field mapping
        field_map = {}

        # we need the reference coordinate calculated inside the loops for summary information
        ref = []

        # write the desired operands to the MF file
        skip_lines = 1
        with open(mf, 'w') as file:
            file.write('VERS 210902\n')

            # account for multi-config
            if self.TheSystem.MFE.GetOperandAt(1).Type == self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CONF:
                file.write(f'CONF {config_number} 0' + self._p(10))
                skip_lines += 1

            # loop through all the requested fields
            fs = 1 if field == 0 else field
            fe = self.TheSystem.SystemData.Fields.NumberOfFields + 1 if field == 0 else field + 1
            for f in range(fs, fe):
                # get the normalized field coordinates
                hx, hy = self.get_normalized_field_coordinates(field_number=f)
                field_map.update({f: (hx, hy)})
                
                # loop through all the requested wavelengths
                ws = 1 if wavelength == 0 else wavelength
                we = self.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1 if wavelength == 0 else wavelength + 1
                for w in range(ws, we):
                    # calculate the reference
                    ref.append({'f': f, 'w': w})
                    if refer_to.lower() == 'centroid':
                        ref[-1].update({
                            'x': self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CENX, surface, w, field, 0, 5, 0, 0, 0),
                            'y': self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CENY, surface, w, field, 0, 5, 0, 0, 0)
                        })
                    elif refer_to.lower() == 'middle':
                        # need to run the analysis and then actually find the `min` and `max` values for the middle
                        ref[-1].update({'x': float('nan'), 'y': float('nan')})
                    elif refer_to.lower() == 'vertex':
                        ref[-1].update({'x': 0.0, 'y': 0.0})
                    else:   # 'chiefray' and default
                        ref[-1].update({
                            'x': self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surface, w, hx, hy, 0, 0, 0, 0),
                            'y': self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surface, w, hx, hy, 0, 0, 0, 0),
                        })

                    # loop through the pupil coordinates
                    for px, py in zip(*pupil):
                        file.write(f'REAX {surface} {w} {hx:.12e} {hy:.12e} {px:.12e} {py:.12e}' + self._p(6))
                        file.write(f'REAY {surface} {w} {hx:.12e} {hy:.12e} {px:.12e} {py:.12e}' + self._p(6))
                        pass

        # load the file, calculate & resave
        self.TheSystem.MFE.LoadMeritFunction(str(mf))
        self.TheSystem.MFE.CalculateMeritFunction()
        self.TheSystem.MFE.SaveMeritFunction(str(mf))

        # open the file and read into pandas
        encoding = self.zos.detect_encoding(str(mf))
        df = pd.read_csv(
            str(mf),
            sep=r'\s+',
            skiprows=skip_lines,
            header=None,
            usecols=[0, 1, 2, 3, 4, 5, 6, 11],
            engine='c',
            dtype = {
                0: "category",
                1: "int32",
                2: "int32",
                3: "float64",
                4: "float64",
                5: "float64",
                6: "float64",
                11: "float64",
            },
            encoding=encoding
        )
        df.columns = ['oper', 'surf', 'wave', 'hx', 'hy', 'px', 'py', 'value']
        
        # change from normalized field to field number
        df = self._normalized_field_to_number(df, field_map)
        
        # Delete it manually when done
        # mf.unlink()

        # calculate the summmary information
        stats = self.calculate_summary(df, ref)
        
        # it's always a good idea to save the input settings so we know how to recreate the data
        data = {
            'window': 'SpotDiagram',
            'field': field,
            'surface': surface,
            'wavelength': wavelength,
            'pattern': pattern,
            'refer_to': refer_to,
            'ray_density': ray_density,
            'use_polarization': use_polarization,
            'scatter_rays': scatter_rays,
            'show_airy_disk': show_airy_disk
        }

        # print(stats)

        # for row in stats:
        #     print(stats[row])
        header = ['wave   field         rms             geo']
        for row in stats.itertuples():
            header.append(f'{row.wave:<6} {row.field:<6} {row.rms:15.8f} {row.geo:15.8f}')
            

        return {'type': 'scatter', 'settings': data, 'header': header, 'data': [df.to_json(orient='records')]}
    
    def plot(self, df):
        # step 1: find the maximum range across all fields
        field_stats = (
            df.groupby("field")
            .agg(
                x_min=("REAX", "min"),
                x_max=("REAX", "max"),
                y_min=("REAY", "min"),
                y_max=("REAY", "max"),
            )
        )

        # this almost gets it but we still need to account for the reference...this just assumes the `refer_to` is 'middle'
        field_stats["dx"] = field_stats["x_max"] - field_stats["x_min"]
        field_stats["dy"] = field_stats["y_max"] - field_stats["y_min"]

        field_stats["size"] = field_stats[["dx", "dy"]].max(axis=1)
        
        global_size = field_stats["size"].max()
        half = global_size / 2

        field_stats["cx"] = (field_stats["x_min"] + field_stats["x_max"]) / 2
        field_stats["cy"] = (field_stats["y_min"] + field_stats["y_max"]) / 2

        # ✅ Step 2: setup subplot grid (one per field)
        fields = sorted(df["field"].unique())
        waves = sorted(df["wave"].unique())

        fig, axes = plt.subplots(
            len(fields),
            1,
            figsize=(6, 4 * len(fields)),
            sharex=False,
            sharey=False
        )

        # if only one field, axes is not a list
        if len(fields) == 1:
            axes = [axes]

         # 🎨 Step 3: assign colors per wave
        colors = ['#0000ff', '#00ff00', '#ff0000', '#bfbf00', '#ff00ff', '#00ffff', '#7f7fff', '#7fff7f']

        # 📊 Step 4: plot
        for ax, f in zip(axes, fields):
            sub = df[df["field"] == f]

            # plot waves
            for w in waves:
                s = sub[sub["wave"] == w]
                if s.empty:
                    continue

                # ax.scatter(s["REAX"], s["REAY"], s=10, color=wave_colors[w])
                ax.scatter(s["REAX"], s["REAY"], s=2, color=colors[(w - 1) % len(colors)])

            # "good enough" for now (need to account for `centroid` and `chiefray`)
            half *= 1.1
            cx = field_stats.loc[f, 'cx']
            cy = field_stats.loc[f, 'cy']
            ax.set_xlim(cx - half, cx + half)
            ax.set_ylim(cy - half, cy + half)
            

            ax.set_title(f"Field {f}")
            ax.set_aspect('equal')
            ax.set_box_aspect(1)

        plt.show(block=True)
        pass


if __name__ == '__main__':
    pass
