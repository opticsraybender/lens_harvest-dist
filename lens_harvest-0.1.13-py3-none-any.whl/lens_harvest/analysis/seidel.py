# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

class Seidel(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
        
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav

    def _yu(self):
        '''
        Internal function to trace the paraxial y-height and u=m/n direction cosine

        Note: this is the only function in this class that actually performs a ray trace.  All other Operand Values are just for reporting purposes
        '''
        self.ym = []
        self.um = []
        self.yc = []
        self.uc = []
        self.indx = []
        self.indx_min = []
        self.indx_max = []

        # initial 

        for surf in range(0, self.zos.TheSystem.LDE.NumberOfSurfaces):
            # get the paraxial on-axis marginal ray values
            pary = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARY, surf, self.wave['idx'], 0, 0, 0, 1, 0, 0)
            parb = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARB, surf, self.wave['idx'], 0, 0, 0, 1, 0, 0)
            parc = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARC, surf, self.wave['idx'], 0, 0, 0, 1, 0, 0)
            self.ym.append(pary)
            self.um.append(parb / parc)

            # get the paraxial full-field chief ray values
            pary = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARY, surf, self.wave['idx'], 0, 1, 0, 0, 0, 0)
            parb = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARB, surf, self.wave['idx'], 0, 1, 0, 0, 0, 0)
            parc = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARC, surf, self.wave['idx'], 0, 1, 0, 0, 0, 0)
            self.yc.append(pary)
            self.uc.append(parb / parc)

            # get the refractive index since we're already in the surface loop
            self.indx.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.INDX, surf, self.wave['idx'], 0, 0, 0, 0, 0, 0))
            self.indx_min.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.INDX, surf, self.wave_min['idx'], 0, 0, 0, 0, 0, 0))
            self.indx_max.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.INDX, surf, self.wave_max['idx'], 0, 0, 0, 0, 0, 0))

        return True
    def _seidel(self):
        '''
        Calculate the actual Seidel coefficients.  

        Use `get_seidel()` to return the actual coefficients
        '''
        self.s1 = []
        self.s2 = []
        self.s3 = []
        self.s4 = []
        self.s5 = []
        self.lc = []        # lateral color (CTR, CT)
        self.ac = []        # axial color   (CLA, CL)
        for surf in range(1, self.zos.TheSystem.LDE.NumberOfSurfaces):
            # note this works for standard surfaces...for aspheric surfaces need to find the "effective curvature"
            curv = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CVVA, surf, 0, 0, 0, 0, 0, 0, 0)

            n1 = self.indx[surf - 1]
            n2 = self.indx[surf]

            am = n1 * (self.ym[surf] * curv + self.um[surf - 1])
            ac = n1 * (self.yc[surf] * curv + self.uc[surf - 1])

            delta_um = (self.um[surf] / n2) - (self.um[surf - 1] / n1)
            power = curv * ((1 / n2) - (1 / n1))

            self.s1.append(-am * am * self.ym[surf] * delta_um)
            self.s2.append(-am * ac * self.ym[surf] * delta_um)
            self.s3.append(-ac * ac * self.ym[surf] * delta_um)
            self.s4.append(-self.invariant**2 * power)

            if abs(am) > 1e-6:
                self.s5.append(-ac / am * (self.invariant**2 * power + ac * ac * self.ym[surf] * delta_um))
            else:
                self.s5.append(-ac * (ac * ac * self.ym[surf] * (1 / (n2 * n2) - 1 / (n1 * n1)) - (self.invariant + ac * self.ym[surf]) * self.yc[surf] * power))
            
            # lateral and axial color
            d1 = (self.indx_min[surf - 1] - self.indx_max[surf - 1]) / self.indx[surf - 1]
            d2 = (self.indx_min[surf] - self.indx_max[surf]) / self.indx[surf]
            self.lc.append(-ac * self.ym[surf] * (d2 - d1))     # chief ray, so transverse @ image plane
            self.ac.append(-am * self.ym[surf] * (d2 - d1))     # marginal ray, so axial @ image plane
        
    def get_wavefront_coefficients(self):
        '''
        Calculates the Wavefront Coefficients from the Seidel Coefficients
        '''
        wl = self.wave['val'] / 1000
        
        w040 = [x / (8.0 * wl) for x in self.s1]
        w131 = [x / (2.0 * wl) for x in self.s2]
        w222 = [x / (2.0 * wl) for x in self.s3]
        w220 = [x / (4.0 * wl) for x in self.s4]
        w311 = [x / (2.0 * wl) for x in self.s5]
        w020 = [x / (2.0 * wl) for x in self.ac]
        w111 = [x / (1.0 * wl) for x in self.lc]

        return {'w040': w040, 'w131': w131, 'w222': w222, 'w220': w220, 'w311': w311, 'w020': w020, 'w111': w111}
    def get_tra(self):
        '''
        Calculates the Transverse Aberration Coefficients from the Seidel Coefficients
        '''

        n_um = abs(self.indx[-1]) * self.um[-1]
        
        tsph = [-x / (2 * n_um) for x in self.s1]
        tsco = [-x / (2 * n_um) for x in self.s2]
        ttco = [-3 * x / (2 * n_um) for x in self.s2]
        tast = [-x / (n_um) for x in self.s3]
        tpfc = [-x / (2 * n_um) for x in self.s4]
        tsfc = [-(x + y) / (2 * n_um) for x, y in zip(self.s3, self.s4)]
        ttfc = [-(3 * x + y) / (2 * n_um) for x, y in zip(self.s3, self.s4)]
        tdis = [-x / (2 * n_um) for x in self.s5]
        taxc = [x / (n_um) for x in self.ac]
        tlac = [x / (n_um) for x in self.lc]

        return {'tsph': tsph, 'tsco': tsco, 'ttco': ttco, 'tast': tast, 'tpfc': tpfc, 'tsfc': tsfc, 'ttfc': ttfc, 'tdis': tdis, 'taxc': taxc, 'tlac': tlac}

    def get_lac(self):
        '''
        Calculates the Longitudinal Aberration Coefficients from the Seidel Coefficients
        '''

        n_um2 = abs(self.indx[-1]) * self.um[-1]**2

        lsph = [x / (2 * n_um2) for x in self.s1]
        lsco = [x / (2 * n_um2) for x in self.s2]
        ltco = [3 * x / (2 * n_um2) for x in self.s2]
        last = [x / (n_um2) for x in self.s3]
        lpfc = [x / (2 * n_um2) for x in self.s4]
        lsfc = [(x + y) / (2 * n_um2) for x, y in zip(self.s3, self.s4)]
        ltfc = [(3 * x + y) / (2 * n_um2) for x, y in zip(self.s3, self.s4)]
        ldis = [x / (2 * n_um2) for x in self.s5]
        laxc = [x / (n_um2) for x in self.ac]
        llac = [x / (n_um2) for x in self.lc]

        return {'lsph': lsph, 'lsco': lsco, 'ltco': ltco, 'last': last, 'lpfc': lpfc, 'lsfc': lsfc, 'ltfc': ltfc, 'ldis': ldis, 'laxc': laxc, 'llac': llac}

    def get_seidels(self):
        return {'s1': self.s1, 's2': self.s2, 's3': self.s3, 's4': self.s4, 's5': self.s5, 'ac': self.ac, 'lc': self.lc}
    
    def run(self, 
            wavelength=0, 
            ignore_distortion=False, 
            ignore_chromatic=False
            ):
        if wavelength < 1 or wavelength > self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths:
            wave = self.get_pwav()
        else:
            wave = wavelength

        # store the calculation wavelength for other methods
        self.wave = {'idx': wave, 'val': self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(wave).Wavelength}

        # get the min/max wavelengths for axial & lateral colors
        self.wave_min = {'idx': 1, 'val': 9e9}
        self.wave_max = {'idx': 1, 'val': -9e9}
        for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
            w = self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).Wavelength 
            if w < self.wave_min['val']: self.wave_min = {'idx': i, 'val': w}
            if w > self.wave_max['val']: self.wave_max = {'idx': i, 'val': w}
        
        
        # calculate the paraxial ray trace (always in the +y direction)        
        self._yu()

        # calculate the lagrange invariant
        ss = self.zos.TheSystem.LDE.StopSurface
        self.invariant = self.ym[ss] * self.uc[ss - 1] * self.indx[ss - 1]

        # always run the seidel calculation
        self._seidel()

        settings = {'window': 'Seidel', 'wavelength': wave}
        header = []
        data = pd.DataFrame(self.get_seidels())
        data.index += 1
        data.loc['Sum'] = data.sum()

        return {'type': 'table', 'settings': settings, 'header': header, 'data': [data.to_json(orient='records')]}
if __name__ == '__main__':
    pass
