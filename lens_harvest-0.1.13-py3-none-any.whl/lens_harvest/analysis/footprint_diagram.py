# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# commmon imports across all files
from ..connect import Connect
import numpy as np
import pandas as pd

# enum parsing for `ZOSAPI` namespace
import clr
from System import Enum, Int32, Double

# reading/writing merit function files
import uuid
from pathlib import Path

# plotting
import itertools
import matplotlib.pyplot as plt

class FootprintDiagram(object):
    '''
    Mimics the Footprint Diagram including `Remove Vignetting` and the `Ring` density
    '''
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def get_normalized_field_coordinates(self, field_number=1):
        if field_number < 1:
            field_number = 1
        if field_number > self.zos.TheSystem.SystemData.Fields.NumberOfFields:
            field_number = self.zos.TheSystem.SystemData.Fields.NumberOfFields
        
        # determine maximum field values
        mx = 0
        my = 0
        for f in range(1, self.zos.TheSystem.SystemData.Fields.NumberOfFields + 1):
            field = self.zos.TheSystem.SystemData.Fields.GetField(f)
            if field.X > mx: mx = field.X
            if field.Y > my: my = field.Y
        
        # determine if radial or rectangular normalization
        if self.zos.TheSystem.SystemData.Fields.Normalization == self.zos.ZOSAPI.SystemData.FieldNormalizationType.Radial:
            my = (mx*mx + my*my)**0.5
            mx = my
        
        # get the field coordinates & normalized values
        field = self.zos.TheSystem.SystemData.Fields.GetField(field_number)
        hx = 0.0 if abs(mx) < 1e-10 else field.X / mx
        hy = 0.0 if abs(my) < 1e-10 else field.Y / my

        return (hx, hy)



    def get_square(self, ray_density):
        step = 1 / ray_density
        coords = np.arange(-1.0, 1.0 + step, step)

        px = [x for x in coords for y in coords if x**2 + y**2 <= 1]
        py = [y for x in coords for y in coords if x**2 + y**2 <= 1]

        return (px, py)

    def get_ring(self, theta_step = 2):
        '''
        Returns the initial (px, py) for an unvignetted ring
        '''
        radius = 1.0
        theta = np.arange(0, 2 * np.pi, np.deg2rad(theta_step))
        
        px = radius * np.cos(theta)
        py = radius * np.sin(theta)

        return (px, py)
    
    def arc_points(self, x0, y0, cx, cy, angle_deg, n):
        # Convert to radians (flip sign because numpy uses CCW positive)
        angle_rad = -np.deg2rad(angle_deg)
        
        # Radius
        r = np.sqrt((x0 - cx)**2 + (y0 - cy)**2)
        
        # Starting angle
        theta0 = np.arctan2(y0 - cy, x0 - cx)
        
        # Generate angles along the arc
        thetas = np.linspace(theta0, theta0 + angle_rad, n + 1)
        
        # Compute points
        x = cx + r * np.cos(thetas)
        y = cy + r * np.sin(thetas)
        
        return np.column_stack((x, y))
    def get_uda(self, filename):
        if not Path(filename).is_file():
            filename = Path(self.zos.TheApplication.ObjectsDir) / rf'Apertures/{filename}'

        encoding = self.zos.detect_encoding(filename)
        
        with open(Path(filename), 'r', encoding=encoding) as file:
            lines = file.readlines()

        # remove blank lines
        lines = [s for s in lines if s.strip()]
        
        paths = []
        arc_lin = []
        for line in lines:
            parts = line.split()

            # skip comments
            if line.strip()[0] == '!': 
                continue
            
            # let's strip commas (Help File states `LIN -10, 10` is valid)
            parts = [x.strip(', ') for x in parts]

            if parts[0].lower() == 'arc':
                # ARC cx cy angle n
                cx = float(parts[1])
                cy = float(parts[2])
                angle = float(parts[3]) # keep in angles since we convert in the method
                n = max(min(2 if len(parts) == 4 else int(parts[4]), 64), 2)

                x0 = arc_lin[-1][0] if len(arc_lin) > 0 else 0
                y0 = arc_lin[-1][1] if len(arc_lin) > 0 else 0
                arc = self.arc_points(x0, y0, cx, cy, angle, n)

                for x, y in zip(arc[:, 0], arc[:, 1]):
                    arc_lin.append([x, y])
                # arc_lin.append([arc[:, 0].tolist(), arc[:, 1].tolist()])
                pass
            elif parts[0].lower() == 'brk':
                # stop and close the last aperture
                arc_lin.append((arc_lin[0]))
                al_np = np.array(arc_lin)
                x = al_np[:, 0]
                y = al_np[:, 1]
                paths.append([x, y])
                arc_lin = []
                pass
            elif parts[0].lower() == 'cir':
                # CIR cx cy radius n
                cx = float(parts[1])
                cy = float(parts[2])
                r  = float(parts[3])
                n  = max(min(int(parts[4]) if len(parts) == 5 else 32, 64), 8)
                
                theta = np.linspace(0, -2 * np.pi, n + 1)
                
                x = r * np.cos(theta) + cx
                y = r * np.sin(theta) + cy
                
                paths.append([x, y])
                pass
            elif parts[0].lower() == 'eli':
                # ELI cx cy rx ry angle n
                cx = float(parts[1])
                cy = float(parts[2])
                rx = float(parts[3])
                ry = float(parts[4])
                angle = 0
                n = 32
                
                if len(parts) >= 6:
                    angle = np.deg2rad(float(parts[5])) * -1
                if len(parts) == 7:
                    n = max(min(int(parts[6]), 64), 8)
                
                # sampling
                theta = np.linspace(0, 2 * np.pi, n + 1)

                # base ellipse
                x = rx * np.cos(theta)
                y = ry * np.sin(theta)

                # rotated ellipse
                xr = x * np.cos(angle) - y * np.sin(angle) + cx
                yr = x * np.sin(angle) + y * np.cos(angle) + cy

                paths.append([xr, yr])

                pass
            elif parts[0].lower() == 'lin' or self.zos.try_float(parts[0]):
                # LIN x y n (don't know how to parse the `n` from a visual standpoint)
                # LIN x y
                # x y
                if parts[0].lower() == 'lin':
                    x = float(parts[1])
                    y = float(parts[2])
                else:
                    x = float(parts[0])
                    y = float(parts[1])
                
                arc_lin.append([x, y])
                
                pass
            elif parts[0].lower() == 'pol':
                # POL cx cy radius n angle
                # this is the same as the circle but it just has a rotation angle
                cx = float(parts[1])
                cy = float(parts[2])
                r  = float(parts[3])
                n = max(min(int(parts[4]), 64), 3)
                angle = 0
                if len(parts) == 6:
                    angle = np.deg2rad(float(parts[5])) * -1
                
                theta = np.linspace(0, -2 * np.pi, n + 1)
                
                x = r * np.cos(theta)
                y = r * np.sin(theta)

                # rotated & shifted polygon
                xr = x * np.cos(angle) - y * np.sin(angle) + cx
                yr = x * np.sin(angle) + y * np.cos(angle) + cy

                paths.append([xr, yr])
                pass
            elif parts[0].lower() == 'rec':
                # REC cx cy xhw yhw angle nx ny
                cx = float(parts[1])
                cy = float(parts[2])
                xh = float(parts[3])
                yh = float(parts[4])
                angle = 0
                if len(parts) == 6:
                    angle = np.deg2rad(float(parts[5])) * -1

                x = np.array([xh, xh, -xh, -xh, xh])
                y = np.array([yh, -yh, -yh, yh, yh])

                # rotated & shifted rectangle
                xr = x * np.cos(angle) - y * np.sin(angle) + cx
                yr = x * np.sin(angle) + y * np.cos(angle) + cy

                paths.append([xr, yr])
                pass
        
        # check if we have any `lin` or `arc` without calling a `brk`
        if len(arc_lin) > 0:
            arc_lin.append((arc_lin[0]))
            al_np = np.array(arc_lin)
            x = al_np[:, 0]
            y = al_np[:, 1]
            paths.append([x, y])


        # do not convert `paths` to numpy but rather make sure it's a numpy in the plotting
        return paths
    def step_ring_down(self, px, py, step_size=0.05):
        r = np.sqrt(px**2 + py**2) - step_size

        # get the rotation angle
        theta = np.atan2(py, px)

        # convert back to cartesian coordinates (passing back r so we don't have a runaway loop)
        return (r * np.cos(theta), r * np.sin(theta), r)
    
    def calculate_aperture(self, surf):
        # there will always be a circular CA, but there might be other defined apertures as well
        output = {}
        
        ad = self.zos.TheSystem.LDE.GetSurfaceAt(surf).ApertureData
        
        if (
            ad.CurrentType == Enum.Parse(self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes, 'None') or 
            ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.FloatingAperture
            ):
            # circular aperture with no offset, use LDE
            output.update(
                {'type': 'circular',
                 'size': (0, self.zos.TheSystem.LDE.GetSurfaceAt(surf).SemiDiameter), 
                 'offset': (0, 0)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.CircularAperture:
            output.update(
                {'type': 'circular',
                 'size': (ad.CurrentTypeSettings._S_CircularAperture.MinimumRadius, ad.CurrentTypeSettings._S_CircularAperture.MaximumRadius),
                 'offset': (ad.CurrentTypeSettings._S_CircularAperture.ApertureXDecenter , ad.CurrentTypeSettings._S_CircularAperture.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.CircularObscuration:
            output.update(
                {'type': 'circular', 
                 'size': (ad.CurrentTypeSettings._S_CircularObscuration.MinimumRadius, ad.CurrentTypeSettings._S_CircularObscuration.MaximumRadius),
                 'offset': (ad.CurrentTypeSettings._S_CircularObscuration.ApertureXDecenter , ad.CurrentTypeSettings._S_CircularObscuration.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.Spider:
            output.update(
                {'type': 'spider', 
                 'size': (
                     ad.CurrentTypeSettings._S_Spider.WidthOfArms, 
                     ad.CurrentTypeSettings._S_Spider.NumberOfArms,
                     self.zos.TheSystem.LDE.GetSurfaceAt(surf).SemiDiameter     # need to know the SD to draw the radius for each arm
                     ),
                 'offset': (ad.CurrentTypeSettings._S_Spider.ApertureXDecenter , ad.CurrentTypeSettings._S_Spider.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.RectangularAperture:
            output.update(
                {'type': 'rectangular', 
                 'size': (ad.CurrentTypeSettings._S_RectangularAperture.XHalfWidth, ad.CurrentTypeSettings._S_RectangularAperture.YHalfWidth),
                 'offset': (ad.CurrentTypeSettings._S_RectangularAperture.ApertureXDecenter , ad.CurrentTypeSettings._S_RectangularAperture.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.RectangularObscuration:
            output.update(
                {'type': 'rectangular', 
                 'size': (ad.CurrentTypeSettings._S_RectangularObscuration.XHalfWidth, ad.CurrentTypeSettings._S_RectangularObscuration.YHalfWidth),
                 'offset': (ad.CurrentTypeSettings._S_RectangularObscuration.ApertureXDecenter , ad.CurrentTypeSettings._S_RectangularObscuration.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.EllipticalAperture:
            output.update(
                {'type': 'elliptical', 
                 'size': (ad.CurrentTypeSettings._S_EllipticalAperture.XHalfWidth, ad.CurrentTypeSettings._S_EllipticalAperture.YHalfWidth),
                 'offset': (ad.CurrentTypeSettings._S_EllipticalAperture.ApertureXDecenter , ad.CurrentTypeSettings._S_EllipticalAperture.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.EllipticalObscuration:
            output.update(
                {'type': 'elliptical', 
                 'size': (ad.CurrentTypeSettings._S_EllipticalObscuration.XHalfWidth, ad.CurrentTypeSettings._S_EllipticalObscuration.YHalfWidth),
                 'offset': (ad.CurrentTypeSettings._S_EllipticalObscuration.ApertureXDecenter , ad.CurrentTypeSettings._S_EllipticalObscuration.ApertureYDecenter)
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.UserAperture:
            output.update(
                {'type': 'user', 
                 'size': (ad.CurrentTypeSettings._S_UserAperture.UDASCale),
                 'offset': (ad.CurrentTypeSettings._S_UserAperture.ApertureXDecenter , ad.CurrentTypeSettings._S_UserAperture.ApertureYDecenter),
                 'file': ad.CurrentTypeSettings._S_UserAperture.ApertureFile
                 })
        elif ad.CurrentType == self.zos.ZOSAPI.Editors.LDE.SurfaceApertureTypes.UserObscuration:
            output.update(
                {'type': 'user', 
                 'size': (ad.CurrentTypeSettings._S_UserObscuration.UDASCale),
                 'offset': (ad.CurrentTypeSettings._S_UserObscuration.ApertureXDecenter , ad.CurrentTypeSettings._S_UserObscuration.ApertureYDecenter),
                 'file': ad.CurrentTypeSettings._S_UserObscuration.ApertureFile
                 })

        return output
    def line_intersection(self, line1, line2):
        """
        Find the intersection of two lines defined by 2 points each.
        
        line1: array of shape (2, 2) → [[x1,y1], [x2,y2]]
        line2: array of shape (2, 2) → [[x3,y3], [x4,y4]]
        
        Returns: [x, y] intersection point, or None if lines are parallel.
        """
        p1, p2 = np.asarray(line1)
        p3, p4 = np.asarray(line2)

        d1 = p2 - p1  # direction vector of line 1
        d2 = p4 - p3  # direction vector of line 2

        cross = d1[0] * d2[1] - d1[1] * d2[0]  # 2D cross product

        if np.isclose(cross, 0):
            return None  # lines are parallel or coincident

        t = ((p3[0] - p1[0]) * d2[1] - (p3[1] - p1[1]) * d2[0]) / cross

        return p1 + t * d1  # [x, y] intersection point

    def draw_aperture(self, data, number_of_points = 360):
        path = []
        if data['type'] == 'circular':
            theta = np.linspace(0, 2 * np.pi, number_of_points)
            # inner radius
            x = data['offset'][0] + data['size'][0] * np.cos(theta)
            y = data['offset'][1] + data['size'][0] * np.sin(theta)
            path.append((x, y))
            
            # outer radius
            x = data['offset'][0] + data['size'][1] * np.cos(theta)
            y = data['offset'][1] + data['size'][1] * np.sin(theta)
            path.append((x, y))
            pass
        elif data['type'] == 'spider':
            # mrh: account for offsets
            aw = data['size'][0] / 2.0
            an = data['size'][1]
            al = data['size'][2]
            
            # make the first arm along the +x axis
            fo = np.asarray([[al, aw], [al, -aw]])
            fi = np.asarray([[aw, aw], [aw, -aw]])
            outer = []
            inner = []

            # rotate the arm
            angles = np.linspace(0, -2*np.pi, an, endpoint=False)
            for angle in angles:
                r11 = np.cos(angle)
                r12 = -np.sin(angle)
                r21 = np.sin(angle)
                r22 = np.cos(angle)

                for i in range(2):
                    outer.append([fo[i][0] * r11 + fo[i][1] * r12, fo[i][0] * r21 + fo[i][1] * r22])
                    inner.append([fi[i][0] * r11 + fi[i][1] * r12, fi[i][0] * r21 + fi[i][1] * r22])

            # connect the points into a polygon
            if an == 1:
                outer.append([0, -aw])
                outer.append([0, aw])
                outer.append(outer[0])      # always add the starting point
            elif an == 2:
                outer.append(outer[0])      # always add the starting point
            else:                           # find the arm intersect point
                connector = []

                indices = list(range(1, len(outer)))
                indices.append(0)

                for i in range(an):
                    idx = indices[2 * i + 0]
                    ip1 = indices[2 * i + 1]

                    connector.append(outer[idx])
                    connector.append(self.line_intersection([outer[idx], inner[idx]], [outer[ip1], inner[ip1]]))
                    connector.append(outer[ip1])

                outer = connector
                outer.append(outer[0])

            outer = np.asarray(outer)
            path.append((outer[:, 0].tolist(), outer[:, 1].tolist()))
            pass
        elif data['type'] == 'rectangular':
            rect = [
                [data['size'][0] + data['offset'][0], data['size'][1] + data['offset'][1]],
                [data['size'][0] + data['offset'][0], -data['size'][1] + data['offset'][1]],
                [-data['size'][0] + data['offset'][0], -data['size'][1] + data['offset'][1]],
                [-data['size'][0] + data['offset'][0], data['size'][1] + data['offset'][1]],
                [data['size'][0] + data['offset'][0], data['size'][1] + data['offset'][1]]
                ]
            rect = np.asarray(rect)
            
            path.append((rect[:, 0], rect[:, 1]))
        elif data['type'] == 'elliptical':
            theta = np.linspace(0, 2 * np.pi, number_of_points)
            x = data['offset'][0] + data['size'][0] * np.cos(theta)
            y = data['offset'][1] + data['size'][1] * np.sin(theta)
            path.append((x, y))
            pass
        elif data['type'] == 'user':
            path = self.get_uda(data['file'])
            for pdx, _ in enumerate(path):
                p = path[pdx]

                if not isinstance(p, np.ndarray):
                    p = np.array(p)
                
                # apply the scale factor then offset
                p[0, :] *= data['size']
                p[0, :] += data['offset'][0]
                p[1, :] *= data['size']
                p[1, :] += data['offset'][1]

                path[pdx] = p
            pass

        
        list_path = []
        for p in path:
            list_path.append((p[0].tolist(), p[1].tolist()))

            pass
        
        return list_path
    def trace(self, tool, hx, hy, px, py, wave, surf):
        # .NET constants for the overloaded (ambiguous) ray trace methods; required for `pythonnet`
        si = Int32(1)
        sd = Double(1.0)

        real = self.zos.ZOSAPI.Tools.RayTrace.RaysType.Real
        nsur = self.zos.TheSystem.LDE.NumberOfSurfaces - 1

        _, ec, _, xo, yo, *_ = tool.SingleRayNormUnpol(real, surf, wave, hx, hy, px, py, False, si, si, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd)

        if ec != 0: return False

        # trace the ray to the image plane to see if ANY surface vignettes
        _, ec, vc, *_ = tool.SingleRayNormUnpol(real, nsur, wave, hx, hy, px, py, False, si, si, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd)

        if ec != 0: return False

        return (vc, xo, yo)

    def run(self, 
            field=0, 
            surface=0,
            wavelength=0,
            ray_density=10,
            configuraion=0,
            delete_vignetted=True
            ):
        '''
        Mimics a Standard Spot Diagram and Through Focus Spot Diagram.
        
        There is no IA_ for the footprint diagram so this is recreated with the ZOS-API

            - Use `field` = 0 for `all`
            - Use `surface` = 0 for `image`
            - Use `wavelength` = 0 for `all`
            - Use `ray_density` = 0 for `ring` or `ray_density='ring'`
            - Use `configuration` = -1 for `all`, use `configuration` = 0 for `current`
        '''
        
        if surface == 0:
            surface = self.zos.TheSystem.LDE.NumberOfSurfaces - 1

        # ensure the settings are correct and get the values for the `for` loops
        fs = field if field > 0 else 1
        fe = field + 1 if field > 0 else self.zos.TheSystem.SystemData.Fields.NumberOfFields + 1

        surf = self.zos.TheSystem.LDE.NumberOfSurfaces - 1 if surface == 0 else surface

        ws = wavelength if wavelength > 0 else 1
        we = wavelength + 1 if wavelength > 0 else self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1

        if isinstance(ray_density, (int, float)) and ray_density > 0:
            ray_density = max(min(round(ray_density / 5) * 5, 200), 10)
        elif isinstance(ray_density, int) and ray_density == 0 or isinstance(ray_density, str):
            ray_density = 'ring'

        settings = {
            'window': 'FootprintDiagram',
            'field': field,
            'surface': surface,
            'ray_density': ray_density,
            'configuration': configuraion,
            'delete_vignetted': delete_vignetted
        }


        #get the pupil coordinates (only works for grid right now, need to figure out how to do a ring with vignetting...maybe just a single ray trace)
        if ray_density == 'ring':
            pupil = self.get_ring()
        else:
            pupil = self.get_square(ray_density=ray_density)
        
        # run an IBatchRayTrace (normalize, unpolarized)...running a single ray trace so we can properly handle the `ring` scenario
        tool = self.zos.TheSystem.Tools.OpenBatchRayTrace()
        
        # pupil = ([0.0], [-1])

        data = []
        for f in range(fs, fe):
            hx, hy = self.get_normalized_field_coordinates(f)
            for w in range(ws, we):
                coords = []
                vignetted = []
                for px, py in zip(*pupil):
                    vc, xo, yo = self.trace(tool, hx, hy, px, py, w, surf)

                    # append the coordinates
                    if not delete_vignetted:
                        coords.append([xo, yo])
                        vignetted.append(vc)
                    elif delete_vignetted:
                        # let's check if we're tracing a ring...if so, we need to get new coordinates
                        if ray_density == 'ring':
                            r = np.sqrt(px**2 + py**2)
                            while r > 1e-3 and vc != 0:
                                px, py, r = self.step_ring_down(px, py)
                                vc, xo, yo = self.trace(tool, hx, hy, px, py, w, surf)
                        
                        # now we should have the ray that actually passed the apertures for both grid and ring
                        if vc == 0:
                            coords.append([xo, yo])
                            vignetted.append(vc)
                    
                    

                    # the vigCode is not working as intended since we need to trace all the way to the image...this requires 2 ray traces
                    k = 1
                
                # we have one field/wave combo, save to output 
                data.append({'wave': w, 'field': f, 'coordinates': coords})


        # calculate the aperture path 
        aperture = self.calculate_aperture(surface)
        path = self.draw_aperture(data=aperture)

        # always close your tools
        tool.Close()
        k = 1

        return {'type': 'scatter', 'settings': settings, 'header': [], 'data': {'footprint': data, 'aperture': path}}

    def plot(self, res):
        colors = ['#0000ff', '#00ff00', '#ff0000', '#bfbf00', '#ff00ff', '#00ffff', '#7f7fff', '#7fff7f']

        # let's test if the vignetting is working
        for idx, data in enumerate(res['data']['footprint']):
            coords = np.asarray(data['coordinates'])
            if len(coords) > 0:
                plt.scatter(coords[:, 0], coords[:, 1], s=1, color=colors[idx % len(colors)])
        
        # plot the center of the lens
        plt.scatter(0, 0, marker='+', s=20, color='gray', linewidth=1)
        
        # there can be multiple apertures
        for aperture in res['data']['aperture']:

            plt.plot(aperture[0], aperture[1], c='gray', linewidth=1, alpha=0.5)
        
        plt.axis('equal')
        plt.show(block=True)
        pass


if __name__ == '__main__':
    pass
