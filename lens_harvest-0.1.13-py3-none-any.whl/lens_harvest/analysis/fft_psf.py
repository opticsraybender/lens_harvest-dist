# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class FftPsf(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            field=1,
            surface=0,
            wavelength=1,
            sample_size='psfs_64x64',
            output_size='psfs_128x128',
            rotation='cw0',
            image_delta=0.0,
            use_polarization=False,
            psf_type='none',
            normalize=True
            ):
        '''
        Runs a Wavefront Mapt analysis
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.FftPsf)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Field.SetFieldNumber(field)
        win_settings.Surface.UseImageSurface() if surface == 0 else win_settings.Surface.SetSurfaceNumber(surface)
        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.SampleSize = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Psf.PsfSampling, sample_size, 'psfs_64x64')[1]
        win_settings.OutputSize = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Psf.PsfSampling, output_size, 'psfs_128x128')[1]
        win_settings.Rotation = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Psf.PsfRotation, rotation, 'cw0')[1]
        win_settings.ImageDelta = image_delta
        win_settings.UsePolarization = use_polarization
        win_settings.Type = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Psf.FftPsfType, psf_type, 'linear')[1]
        win_settings.Normalize = normalize        

        win_settings.SampleSize = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Psf.PsfSampling, sample_size, 'psfs_32x32')[1]
        win_settings.OutputSize = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Psf.PsfSampling, output_size, 'psfs_32x32')[1]




        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'field': win_settings.Field.GetFieldNumber(),
            'surface': win_settings.Surface.GetSurfaceNumber(),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'sample_size': str(win_settings.SampleSize),
            'output_size': str(win_settings.OutputSize),
            'rotation': str(win_settings.Rotation),
            'image_delta': win_settings.ImageDelta,
            'use_polarization': win_settings.UsePolarization,
            'type': str(win_settings.Type),
            'normalize': win_settings.Normalize
        }

        data = []
        for grid in list(res.DataGrids):
            this_grid = self.zos.get_grid(grid)
            data.append(this_grid)

        # always close the analysis
        win.Close()

        return {'type': 'grid', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
