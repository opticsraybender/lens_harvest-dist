# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
# from zemax_dir import ZemaxDir

import numpy as np
import pandas as pd

import clr
from System import Enum

from pathlib import Path

class GeometricImageAnalysis(object):
    '''
    Class that connects & runs the Geometric Image Analysis

    Used only for Irradiance.  The `ShowAs = ZOSAPI.Analysis.GiaShowAsTypes.SpotDiagram` does not produce IAR_ results
        - Irradiance
    '''
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def get_normalized_field_coordinates(self, field_number=1):
        # determine maximum field values
        mx = 0
        my = 0
        for f in range(1, self.zos.TheSystem.SystemData.Fields.NumberOfFields + 1):
            field = self.zos.TheSystem.SystemData.Fields.GetField(f)
            if field.X > mx: mx = field.X
            if field.Y > my: my = field.Y
        
        # determine if radial or rectangular normalization
        if self.zos.TheSystem.SystemData.Fields.Normalization == self.zos.ZOSAPI.SystemData.FieldNormalizationType.Radial:
            my = (mx*mx + my*my)**0.5
            mx = my
        
        # get the field coordinates & normalized values
        field = self.zos.TheSystem.SystemData.Fields.GetField(field_number)
        hx = 0.0 if abs(mx) < 1e-10 else field.X / mx
        hy = 0.0 if abs(my) < 1e-10 else field.Y / my

        return (hx, hy)


    def get_available_files(self, folder=None):
        '''
        Returns all the available IMA files in the proper Zemax\IMAFiles folder

        note: IAS_GeometricImageAnalysis has `GetFileNames()`, but this doesn't expose the `IMAFiles`
              folder to create the `CIRCLE.IMA` if it doesn't exist, so we need a method like this
        '''

        zmxdir = Path(self.zos.TheApplication.ImagesDir)
        files = []
        for file in zmxdir.glob('*.ima'):
            files.append(file.name)

        return files
    def create_circle_img(self):
        '''
        Creates the `CIRCLE.IMA` if the `file` setting is not found
        '''
        zmxdir = Path(self.zos.TheApplication.ImagesDir)

        if zmxdir is None:
            return False        

        N = 99
        center = (N - 1) / 2  # = 49.0

        rows = []
        for row in range(N):
            line = ""
            for col in range(N):
                x = (col - center) / center  # normalized to [-1.0, 1.0]
                y = (row - center) / center
                line += "1" if x*x + y*y <= 1.0 else "0"
            rows.append(line)    
        
        with open(str(zmxdir / 'CIRCLE2.IMA'), 'w') as file:
            file.write(f"{N}\n")
            for row in rows:
                file.write(row + "\n")

        return True
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav
    
    def get_image_size(self, field=1, wave=1, surface=0, reference='chiefray', buffer = 1.5):
        # if field_number < 1, set it to 1...this happens with shared **kwargs
        if field < 1:
            field = 1
        
        hx, hy = self.get_normalized_field_coordinates(field_number=field)

        # get the surface if it is the image plane
        surf = surface
        if surf == 0:
            surf = self.zos.TheSystem.LDE.NumberOfSurfaces


        # get the reference point
        if reference == 'vertex':
            ref = (0.0, 0.0)
        elif reference == 'primarychief':
            wave = self.get_pwav()
            ref = (
                self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy, 0, 0, 0, 0),
                self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy, 0, 0, 0, 0)
            )
        elif reference == 'centroid':
            ref = (
                self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CENX, surf, wave, field, 0, 5, 0, 0, 0),
                self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CENY, surf, wave, field, 0, 5, 0, 0, 0)
            )
        else: # 'chiefray' and default

            ref = (
                self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy, 0, 0, 0, 0),
                self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy, 0, 0, 0, 0)
            )

        # calculate the 4 extreme marginal rays and the cheif ray
        points = [( 
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy,  0,  1, 0, 0),
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy,  0,  1, 0, 0)
        ), (
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy,  0, -1, 0, 0),
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy,  0, -1, 0, 0)
        ), (
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy,  1,  0, 0, 0),
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy,  1,  0, 0, 0)
        ), (
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy, -1,  0, 0, 0),
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy, -1,  0, 0, 0)
        ), (
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy,  0,  0, 0, 0),
            self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy,  0,  0, 0, 0)
        )]

        # find the maximum radial distance (we want 2x for the analysis)
        return max(((p[0] - ref[0])**2 + (p[1] - ref[1])**2)**0.5 for p in points) * 2 * buffer
    def run(self, 
            wavelength=0, 
            field=1,
            surface=0,
            field_size=0.0,
            image_size=-1.0,
            file='CIRCLE.IMA',
            rotation=0.0,
            rays_x_1000=10,
            source='uniform',
            number_of_pixels=100,
            na=0.0,
            total_watts=1.0,
            parity='even',
            reference='chiefray',
            use_polarization=False,
            remove_vignetting_factors=True,
            scatter_rays=False,
            delete_vignetted=False,
            use_pixel_interpolation=False,
            ):
        '''
        Runs a Geometric Image Analysis
            
            `ShowAs` is hard-coded to `ZOSAPI.Analysis.GiaShowAsTypes.FalseColor` to ensure we have a DataGrid output
        
            - wavelength : use `0` for all the wavelengths
            - surface    : use `0` for the Image surface
            - field_size : use `0` for a point source...ideal for a Spot Diagram
            - image_size : if `-1`, then the image size will be automatically calculated based on the `reference` and cheif+marginal rays

            Ignoring: [`SaveAsBIMFile`, `RowColumnNumber`]
        '''
        use_symbols=False
        
        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.GeometricImageAnalysis)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        # make sure the IMA file exists
        ima = Path(self.zos.TheApplication.ImagesDir)
        if not (ima / file).is_file():
            # user file doesn't exist, check if default IMA file exists
            if not (ima / 'CIRCLE.IMA').is_file():
                self.create_circle_img()
                file = 'CIRCLE.IMA'

        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.Field.SetFieldNumber(field)
        win_settings.Surface.UseImageSurface() if surface == 0 else win_settings.Surface.SetSurfaceNumber(surface)
        win_settings.FieldSize = field_size
        win_settings.ImageSize = image_size if image_size > 0 else self.get_image_size(field, wavelength, surface, reference)
        win_settings.File = file
        win_settings.Rotation = rotation
        win_settings.RaysX1000 = int(rays_x_1000)
        win_settings.ShowAs = self.zos.ZOSAPI.Analysis.GiaShowAsTypes.FalseColor
        win_settings.Source = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.SourceGia, source, 'uniform')[1]
        win_settings.NumberOfPixels = int(number_of_pixels)
        win_settings.NA = na
        win_settings.TotalWatts = total_watts
        win_settings.Parity = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Parity, parity, 'even')[1]
        win_settings.Reference = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.ReferenceGia, reference, 'chiefray')[1]
        win_settings.UseSymbols = use_symbols
        win_settings.UsePolarization = use_polarization
        win_settings.RemoveVignettingFactors = remove_vignetting_factors
        win_settings.ScatterRays = scatter_rays
        win_settings.DeleteVignetted = delete_vignetted
        win_settings.UsePixelInterpolation = use_pixel_interpolation

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'field': win_settings.Field.GetFieldNumber(),
            'surface': win_settings.Surface.GetSurfaceNumber(),
            'field_size': win_settings.FieldSize,
            'image_size': win_settings.ImageSize,
            'file': win_settings.File,
            'rotation': win_settings.Rotation,
            'rays_x_1000': win_settings.RaysX1000,
            'show_as': str(win_settings.ShowAs),
            'source': str(win_settings.Source),
            'number_of_pixels': str(win_settings.NumberOfPixels),
            'na': win_settings.NA,
            'total_watts': win_settings.TotalWatts,
            'parity': str(win_settings.Parity),
            'reference': str(win_settings.Reference),
            'use_symbols': win_settings.UseSymbols,
            'use_polarization': win_settings.UsePolarization,
            'remove_vignetting_factors': win_settings.RemoveVignettingFactors,
            'scatter_rays': win_settings.ScatterRays,
            'delete_vignetted': win_settings.DeleteVignetted,
            'use_pixel_interpolation': win_settings.UsePixelInterpolation
        }

        data = []
        for grid in list(res.DataGrids):
            this_grid = self.zos.get_grid(grid)
            data.append(this_grid)

        # always close the analysis
        win.Close()

        return {'type': 'grid', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
