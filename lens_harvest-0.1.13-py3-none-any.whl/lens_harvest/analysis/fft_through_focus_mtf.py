# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class FftThroughFocusMtf(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            field=0,
            wavelength=0,
            mtf_type='modulation',
            sample_size='s_64x64',
            use_polarization=False,
            delta_focus=0.1,
            frequency=50,
            number_of_steps=5
            ):
        '''
        Runs a FFT Through Focus MTF analysis

        `number_of_steps` must be odd and be between 5-97

        NOTES: 
            - `wavelength` does not allow for `polychromatic_only` or `all_no_polychromatic` (can maybe set it to `TheSystem.SystemData.Wavelength.NumberOfWavelengths + 1`)
            - `field_density` must be a multiple of 5 (max 100)
            - `ray_density` must be between 1 and 20
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.FftThroughFocusMtf)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Field.UseAllFields() if field == 0 else win_settings.Field.SetFieldNumber(field)
        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.Type = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Mtf.MtfTypes, mtf_type, 'modulation')[1]
        win_settings.SampleSize = self.zos.try_parse(self.zos.ZOSAPI.Analysis.SampleSizes, sample_size, 's_64x64')[1]
        win_settings.UsePolarization = use_polarization
        win_settings.DeltaFocus = delta_focus
        win_settings.Frequency = frequency
        win_settings.NumberOfSteps = min(max(int(number_of_steps) -1 if int(number_of_steps) % 2 == 0 else int(number_of_steps), 5), 97)

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'field': win_settings.Field.GetFieldNumber(),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'type': str(win_settings.Type),
            'sample_size': str(win_settings.SampleSize),
            'use_polarization': win_settings.UsePolarization,
            'delta_focus': win_settings.DeltaFocus,
            'frequency': win_settings.Frequency,
            'number_of_steps': win_settings.NumberOfSteps
        }

        data = []
        for series in list(res.DataSeries):
            this_series = self.zos.get_series(series)
            data.append(this_series)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
