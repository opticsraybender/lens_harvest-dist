# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class RayFan(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
        field=0, 
        surface=0, 
        wavelength=0, 
        number_of_rays=20, 
        check_apertures=True, 
        vignetted_pupil=True, 
        tangential='aberration_y', 
        sagittal='aberration_x'
        ):
        '''
        Runs a Ray Fan analysis

        Use `wavelength=0` for all wavelengths
        Use `field=0` for all fields
        Use `surface=0` for the Image surface
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.RayFan)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__
        win_settings.Field.UseAllFields() if field == 0 else win_settings.Field.SetFieldNumber(field)
        win_settings.Surface.UseImageSurface() if surface == 0 else win_settings.Surface.SetSurfaceNumber(surface)
        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.NumberOfRays = number_of_rays
        win_settings.CheckApertures = check_apertures
        win_settings.VignettedPupil = vignetted_pupil
        win_settings.Sagittal = Enum.Parse(self.zos.ZOSAPI.Analysis.Settings.Fans.SagittalAberrationComponent, sagittal, True)
        win_settings.Tangential = Enum.Parse(self.zos.ZOSAPI.Analysis.Settings.Fans.TangentialAberrationComponent, tangential, True)

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'field': win_settings.Field.GetFieldNumber(),
            'surface': win_settings.Surface.GetSurfaceNumber(),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'number_of_rays': win_settings.NumberOfRays,
            'check_apertures': win_settings.CheckApertures,
            'vignetted_pupil': win_settings.VignettedPupil,
            'sagittal': str(win_settings.Sagittal),
            'tangential': str(win_settings.Tangential)
        }

        data = []
        for series in list(res.DataSeries):
            this_series = self.zos.get_series(series)
            data.append(this_series)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
