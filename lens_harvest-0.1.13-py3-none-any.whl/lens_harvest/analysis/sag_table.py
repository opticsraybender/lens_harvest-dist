# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect

import pandas as pd

class SagTable(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
    
    def run(self, 
            density=50, 
            **kwargs):
        '''
        runs the sag map along the +y for all the surfaces.  

        will run "normalized" values with 50 data points going from p=0 to p=1
        (smaller diameters will be more dense)
        '''
        
        settings = {
            'window': 'SagTable',
            'density': density
        }

        data = []

        rho = ['-']
        for j in range(density + 1):
            rho.append(j / density)
        
        df = pd.DataFrame({
            'rho': rho
        })

        # ignore the image surface for regression purposes
        for i in range(1, self.zos.TheSystem.LDE.NumberOfSurfaces - 1):
            surf = [self.zos.TheSystem.LDE.GetSurfaceAt(i).SemiDiameter]
            for j in range(density + 1):
                rho = j / density
                y = rho * self.zos.TheSystem.LDE.GetSurfaceAt(i).SemiDiameter

                _, sag, _ = self.zos.TheSystem.LDE.GetSag(i, y, 0.0, 0.0)
                surf.append(sag)
            
            stop = '*' if i == self.zos.TheSystem.LDE.StopSurface else ''
            k = f's{i}{stop}'
            df[k] = surf
        
        # ugh = df.to_json(orient='records')
        # print(ugh)
        
        # return {'type': 'table', 'settings': settings, 'header': [], 'data': [df.to_json(orient='records')]}
        return {'type': 'table', 'settings': settings, 'header': [], 'data': [df.to_json(orient='records')]}

if __name__ == '__main__':
    pass
