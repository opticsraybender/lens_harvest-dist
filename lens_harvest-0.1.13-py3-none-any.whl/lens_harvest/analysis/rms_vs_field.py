# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class RmsVsField(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            wavelength=0, 
            settings='wavefront',
            field_density=15,
            ray_density=3,
            refer_to='centroid',
            method='gaussquad',
            orientation='plus_y',
            show_diffraction_limit=False,
            use_polarization=False,
            remove_vignetting_factors=True
            ):
        '''
        Runs a RMS vs Field analysis

        NOTES: 
            - `wavelength` does not allow for `polychromatic_only` or `all_no_polychromatic` (can maybe set it to `TheSystem.SystemData.Wavelength.NumberOfWavelengths + 1`)
            - `field_density` must be a multiple of 5 (max 100)
            - `ray_density` must be between 1 and 20
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.RMSField)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.Data = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.RMSField.DataType, settings, 'wavefront')[1]
        win_settings.FieldDensity = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.FieldDensities, f'FieldDens_{field_density}', 'FieldDens_15')[1]
        win_settings.RayDensity = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.RayDensities, f'RayDens_{ray_density}', 'RayDens_3')[1]
        win_settings.ReferTo = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.ReferTo, refer_to, 'centroid')[1]
        win_settings.Method = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.Method, method, 'gaussquad')[1]
        win_settings.Orientation = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.Orientations, orientation, 'plus_y')[1]
        win_settings.ShowDiffractionLimit = show_diffraction_limit
        win_settings.UsePolarization = use_polarization
        win_settings.RemoveVignettingFactors = remove_vignetting_factors

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'data': str(win_settings.Data),
            'field_density': str(win_settings.FieldDensity),
            'ray_density': str(win_settings.RayDensity),
            'refer_to': str(win_settings.ReferTo),
            'method': str(win_settings.Method),
            'orientation': str(win_settings.Orientation),
            'show_diffraction_limit': win_settings.ShowDiffractionLimit,
            'use_polarization': win_settings.UsePolarization,
            'remove_vignetting_factors': win_settings.RemoveVignettingFactors
        }

        data = []
        for series in list(res.DataSeries):
            this_series = self.zos.get_series(series)
            data.append(this_series)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
