# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class FieldCurvatureAndDistortion(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            wavelength=0,
            display_as='percent',
            distortion='f_tantheta',
            scan_type='plus_y',
            ignore_vignetting=True,
            maximum_curvature=0.0,
            maximum_distortion=0.0,
            reference_field=1,
            field_aspect_ratio=1.0
            ):
        '''
        Runs a Field Curvature and Distortion analysis
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.FieldCurvatureAndDistortion)

        if win is None:
            return False

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.DisplayAs = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Aberrations.DisplayAsTypes, display_as, 'percent')[1]
        win_settings.Distortion = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Aberrations.Distortions, distortion, 'f_tantheta')[1]
        win_settings.ScanType = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Aberrations.FieldScanDirections, scan_type, 'plus_y')[1]
        win_settings.IgnoreVignetting = ignore_vignetting
        win_settings.MaximumCurvature = maximum_curvature
        win_settings.MaximumDistortion = maximum_distortion
        win_settings.ReferenceField.SetFieldNumber(reference_field)
        win_settings.FieldAspectRatio = field_aspect_ratio

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'display_as': str(win_settings.DisplayAs),
            'distortion': str(win_settings.Distortion),
            'scan_type': str(win_settings.ScanType),
            'ignore_vignetting': str(win_settings.IgnoreVignetting),
            'maximum_curvature': win_settings.MaximumCurvature,
            'maximum_distortion': win_settings.MaximumDistortion,
            'reference_field': win_settings.ReferenceField.GetFieldNumber(),
            'field_aspect_ratio': win_settings.FieldAspectRatio
        }

        data = []
        for series in list(res.DataSeries):
            this_series = self.zos.get_series(series)
            data.append(this_series)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
