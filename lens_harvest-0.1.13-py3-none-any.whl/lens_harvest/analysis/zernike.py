# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd
import json

import clr
from System import Enum

# used for `GetTextFile` output
import os
import tempfile

class Zernike(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

        # turn off updates in the UI 
        self.ShowChangesInUI = self.zos.TheSystem.TheApplication.ShowChangesInUI
        self.zos.TheSystem.TheApplication.ShowChangesInUI = False
    def __del__(self):
        self.zos.TheSystem.TheApplication.ShowChangesInUI = self.ShowChangesInUI
    def _detect_encoding(self, filename):
        with open(filename, "rb") as f:
            raw = f.read()

        if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
            encoding = "utf-16"
        elif raw.startswith(b"\xef\xbb\xbf"):
            encoding = "utf-8-sig"
        else:
            encoding = "cp1252"  # common Windows default

        return encoding
    
    

    def run(self, 
        window='standard', 
        field=1, 
        surface=0, 
        wavelength=1, 
        sample_size='s_64x64', 
        reference_to_vertex=False, 
        max_terms=37, 
        obscuration=0.5
        ):
        '''
        Runs a Zernike Coefficient analysis via the MFE with the ZERN terms.  This provides F16 precision but there is no subaperture data
            window: 
                - annular [only analysis that uses `obscuration`]
                - fringe
                - standard

            
                referenceobdtovertex
        '''
        # dictionary to lookup the `window` settings so a user doesn't have to type in such a long window idm
        window_lookup = {'annular': 2, 'fringe': 0, 'standard': 1}
        
        type_ = window_lookup[window.lower()] if window.lower() in window_lookup else 1
        _, samp = self.zos.try_parse(self.zos.ZOSAPI.Analysis.SampleSizes, sample_size, default=2, to_int=True)    
        epsilon = obscuration if type_ == 2 else 0
        
        settings = {
            'window': next((k for k, v in window_lookup.items() if v == type_), None),
            'wavelength': wavelength,
            'field': field,
            'sampling': str(Enum.ToObject(self.zos.ZOSAPI.Analysis.SampleSizes, samp)),
            'reference_to_vertex': bool(reference_to_vertex),
            'surface': surface
        }
        if type_ == 2:
            settings.update({'obscuration': obscuration})


        # need to build up the MFE, so we'll make a copy of the system, clear the MFE, and then delete the copy
        copy = self.zos.TheSystem.CopySystem()
        copy.MFE.RemoveOperandsAt(1, copy.MFE.NumberOfOperands)      # this still preserves the CONF operand but sets it to `1` if this matters

        if surface > 0 and surface < self.zos.TheSystem.LDE.NumberOfSurfaces - 2:
            mo = copy.MFE.AddOperand()
            mo.ChangeType(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.IMSF)
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param1).IntegerValue = surface

        # get the fitting metrics
        header = []
        header_cols = {
            -8: 'pv_to_opd_centroid',
            -7: 'pv_to_opd_chief',
            -6: 'rms_to_zero_reference',
            -5: 'rms_to_chief',
            -4: 'rms_to_centroid',
            -3: 'variance',
            -2: 'strehl_ratio',
            -1: 'rms_fit_error',
            0 :  'maximum_single_point_fit_error',
        }
        for fit in range(0, -9, -1):
            mo = copy.MFE.AddOperand()
            mo.ChangeType(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.ZERN)
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param1).IntegerValue = fit
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param2).IntegerValue = wavelength
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param3).IntegerValue = samp
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param4).IntegerValue = field
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param5).IntegerValue = type_
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param6).DoubleValue = epsilon
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param7).IntegerValue = int(reference_to_vertex)

            header.append({
                'row'  : mo.OperandNumber,
                'data' : header_cols[fit]
            })

        zern = []
        for term in range(1, max_terms + 1):
            mo = copy.MFE.AddOperand()
            mo.ChangeType(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.ZERN)
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param1).IntegerValue = term
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param2).IntegerValue = wavelength
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param3).IntegerValue = samp
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param4).IntegerValue = field
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param5).IntegerValue = type_
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param6).DoubleValue = epsilon
            mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param7).IntegerValue = int(reference_to_vertex)


            zern.append({
                'row'  : mo.OperandNumber,
                'term' : mo.GetOperandCell(self.zos.ZOSAPI.Editors.MFE.MeritColumn.Param1).IntegerValue
            })
            pass

        
        # update the merit function
        copy.MFE.CalculateMeritFunction()

        # read the results (this would be quicker to save to disk and parse the TXT file but this will be fine for testing)
        actual_header = []
        actual_zern = []
        for f in header:
            # f.update({'val': copy.MFE.GetOperandAt(f['row']).Value})
            actual_header.append(f'{f['data'].ljust(30)} : {copy.MFE.GetOperandAt(f['row']).Value}')

        for zdx, z in enumerate(zern, start=1):
            # actual_zern.append(copy.MFE.GetOperandAt(z['row']).Value)
            actual_zern.append({f'Z{zdx}' : copy.MFE.GetOperandAt(z['row']).Value})
        # delete the copied system to free up memory
        copy.Close(False)

        # organize the settings/outputs
        return {'type': 'table', 'settings': settings, 'header': actual_header, 'data': [json.dumps(actual_zern)]}

    def run_text_only(self, window='standard', field=1, surface=0, wavelength=1, sample_size='s_64x64', reference_to_vertex=False, sx=0.0, sy=0.0, sr=0.0, max_terms=37, obscuration=0.5):
        '''
        THIS IS DEPRECATED AND DOES NOT USE STANDARD FORMAT FOR REPORTING

        Runs a Zernike Coefficient analysis as seen from the GUI.  The output is just a text file and only has F8 precision
            
            window: 
                - annular [only analysis that uses `obscuration`]
                - fringe
                - standard
        '''
        # dictionary to lookup the `window` settings so a user doesn't have to type in such a long window idm
        window_lookup = {'annular': 'ZernikeAnnularCoefficients', 'fringe': 'ZernikeFringeCoefficients', 'standard': 'ZernikeStandardCoefficients'}

        # open the analysis
        idm = 'ZernikeStandardCoefficients'
        if window.lower() in window_lookup:
            idm = window_lookup[window.lower()]
        
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(Enum.Parse(self.zos.ZOSAPI.Analysis.AnalysisIDM, idm))

        # apply all the settings so we have consistent outputs across computers
        # all settings for LA are display only
        settings = win.GetSettings().__implementation__
        settings.Field.SetFieldNumber(field)
        settings.Surface.UseImageSurface() if surface == 0 else settings.Surface.SetSurfaceNumber(surface)
        settings.Wavelength.SetWavelengthNumber(wavelength)
        settings.SampleSize = Enum.Parse(self.zos.ZOSAPI.Analysis.SampleSizes, sample_size, True)
        if hasattr(settings, 'ReferenceOBDToVertex'):
            settings.ReferenceOBDToVertex = reference_to_vertex
        elif hasattr(settings, 'ReferenceOPDToVertex'):
            settings.ReferenceOPDToVertex = reference_to_vertex
        settings.Sx = sx
        settings.Sy = sy
        settings.Sr = sr
        if str(win.AnalysisType) == 'ZernikeAnnularCoefficients':
            settings.Obscuration = obscuration

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()

        # it's always a good idea to save the input settings so we know how to recreate the data
        data = {
            'window': str(win.AnalysisType),
            'field': settings.Field.GetFieldNumber(),
            'surface': settings.Surface.GetSurfaceNumber(),
            'wavelength': settings.Wavelength.GetWavelengthNumber(),
            'sample_size': str(settings.SampleSize),
            'sx': settings.Sx,
            'sy': settings.Sy,
            'sr': settings.Sr
        }

        if hasattr(settings, 'ReferenceOBDToVertex'):
            data.update({'reference_obd_to_vertext': settings.ReferenceOBDToVertex})
        elif hasattr(settings, 'ReferenceOPDToVertex'):
            data.update({'reference_opd_to_vertext': settings.ReferenceOPDToVertex})

        if str(win.AnalysisType) == 'ZernikeAnnularCoefficients':
            data.update({'obscuration': settings.Obscuration})

        # the Zernike output is unstructured so Zemax never hooked it up...need to save & parse text data
        tmp = tempfile.NamedTemporaryFile(mode='w+', delete=False)
        tmp_fn = tmp.name
        tmp.close()         # need to close the temporary file after creation so Windows can properly delete it

        res.GetTextFile(tmp_fn)

        # detect the encoding (Zemax allows ANSI or Unicode)
        encoding = self._detect_encoding(tmp_fn)

        with open(tmp_fn, 'r', encoding=encoding) as f:
            output = f.read().splitlines()

        if os.path.exists(tmp_fn):
            os.remove(tmp_fn)

        # always close the analysis
        win.Close()

        return {'type': 'table', 'settings': data, 'output': output}


if __name__ == '__main__':
    pass
