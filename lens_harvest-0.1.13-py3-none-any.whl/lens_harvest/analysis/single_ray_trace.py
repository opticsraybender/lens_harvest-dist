# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

class SingleRayTrace(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
        
        # rotation matrices for each surface
        self.rotation = []
        
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav
    
    def _rotate(self, surf, xl, yl, zl, cosine_only = False):
        
        _, r11, r12, r13, r21, r22, r23, r31, r32, r33, xo, yo, zo = self.zos.TheSystem.LDE.GetGlobalMatrix(surf, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        
        xg = r11 * xl + r12 * yl + r13 * zl
        yg = r21 * xl + r22 * yl + r23 * zl
        zg = r31 * xl + r32 * yl + r33 * zl
        
        if not cosine_only:
            xg += xo
            yg += yo
            zg += zo

        return xg, yg, zg
    
    def run(self, 
            hx=0.0, 
            hy=0.0, 
            px=0.0, 
            py=0.0, 
            wavelength=0, 
            use_global=False, 
            **kwargs
            ):
        # m_todo: we should probably have an option to set the GCRS to the first surface
        
        # get the settings
        field = kwargs.get('field', 0)
        output_type = kwargs.get('type', 'direction_cosine')
        skip_paraxial = kwargs.get('skip_paraxial', False)
        
        # check for a valid wavelength and 
        if wavelength < 1 or wavelength > self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths:
            wave = self.get_pwav()
        else:
            wave = wavelength
        
        # the easiest way is probably just to use the MFE (this might be slower than an IBatchRayTrace but will be quick enough for a test)
        output = {}
        real = []
        paraxial = []
        last_opth = 0
        
        for surf in range(0, self.zos.TheSystem.LDE.NumberOfSurfaces):
            this_real = {}
            this_paraxial = {}
            
            comment = self.zos.TheSystem.LDE.GetSurfaceAt(surf).Comment
            
            
            # these operands use normalized coordinates
            x = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy, px, py, 0, 0)
            y = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy, px, py, 0, 0)
            z = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAZ, surf, wave, hx, hy, px, py, 0, 0)
            l = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAA, surf, wave, hx, hy, px, py, 0, 0)
            m = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAB, surf, wave, hx, hy, px, py, 0, 0)
            n = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAC, surf, wave, hx, hy, px, py, 0, 0)
            
            nx = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.NORX, surf, 0, x, y, 0, 0, 0, 0)
            ny = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.NORY, surf, 0, x, y, 0, 0, 0, 0)
            nz = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.NORZ, surf, 0, x, y, 0, 0, 0, 0)
            
            if use_global:
                x, y, z = self._rotate(surf, x, y, z)
                l, m, n = self._rotate(surf, l, m, n, True)
                nx, ny, nz = self._rotate(surf, nx, ny, nz, True)
                
            # update points and vectors
            this_real.update({'x': x})
            this_real.update({'y': y})
            this_real.update({'z': z})
            this_real.update({'l': l})
            this_real.update({'m': m})
            this_real.update({'n': n})
            this_real.update({'nx': nx})
            this_real.update({'ny': ny})
            this_real.update({'nz': nz})
            
            this_real.update({'aoi': self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAID, surf, wave, hx, hy, px, py, 0, 0)})
            
            # note we can't get the true path_length because the MFE always takes the `abs` of the path_length
            indx = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.INDX, surf - 1, wave, 0, 0, 0, 0, 0, 0)
            opth = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.OPTH, surf, wave, hx, hy, px, py, 0, 0)
            pl = 'nan'
            if surf == 0:
                pass
            else:
                pl =  (opth - last_opth) / indx
            last_opth = opth
                
            this_real.update({'pl': pl})
            
            # always update the comment last_opth
            this_real.update({'comment': comment})
            
            # save all the real data
            real.append(this_real)
            
            # paraxial data is always in local coordinates (thus why we need `_rotate` function)
            x = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARX, surf, wave, hx, hy, px, py, 0, 0)
            y = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARY, surf, wave, hx, hy, px, py, 0, 0)
            z = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARZ, surf, wave, hx, hy, px, py, 0, 0)
            l = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARA, surf, wave, hx, hy, px, py, 0, 0)
            m = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARB, surf, wave, hx, hy, px, py, 0, 0)
            n = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARC, surf, wave, hx, hy, px, py, 0, 0)
            
            
            if use_global:
                x, y, z = self._rotate(surf, x, y, z)
                l, m, n = self._rotate(surf, l, m, n, True)
            
            # update points and vectors
            this_paraxial.update({'x': x})
            this_paraxial.update({'y': y})
            this_paraxial.update({'z': z})
            this_paraxial.update({'l': l})
            this_paraxial.update({'m': m})
            this_paraxial.update({'n': n})
            this_paraxial.update({'comment': comment})
            
            paraxial.append(this_paraxial)
            

        settings = {
            'window': 'SingleRayTrace',
            'hx': hx, 
            'hy': hy, 
            'px': px, 
            'py': py, 
            'wavelength': wave,
            'global': use_global
            }
        header = []
        # data = [pd.DataFrame(real), pd.DataFrame(paraxial)]
        data = [
            pd.DataFrame(real).to_json(orient='records'), 
            pd.DataFrame(paraxial).to_json(orient='records')
        ]
        
        return {'type': 'table', 'settings': settings, 'header': header, 'data': data}
    
if __name__ == '__main__':
    pass
