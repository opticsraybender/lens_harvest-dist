# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class ChiefRayAngle(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            field_density=21,
            wavelength=1,
            ):
        '''
        Runs a Relative Illumination analysis
        '''

        # def GetCRA(self, number_of_xdata = 21, wave='pwav', remove_vignetting_factors = True):

        # the Incident Angle vs Image Height is not hooked up into ZOS-API
        # we need to implement this with RAID and Hy going from 0 to 1
        # NOTE: the analysis does not consider vignetted rays for upper and lower
        # rays, it only traces Py=-1 and Py=+1.  A more robust analysis will check for
        # vignetted rays at these values and slowly "walk" the ray towards the center
        # until the ray is no longer vignetted

        # for now, I'm implementing the easier version without a vignetting check
        
        norm_hy = list(np.linspace(0, 1, field_density))
        image = []
        lower = []
        chief = []
        upper = []
        ydata = []

        copy_sys = self.zos.TheSystem.CopySystem()
        copy_sys.LDE.GetSurfaceAt(copy_sys.LDE.NumberOfSurfaces - 1).Radius = float('inf')
        NSUR = copy_sys.LDE.NumberOfSurfaces - 1 
        wave = wavelength
        for hy in norm_hy:
            image.append(copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, NSUR, wave, 0, hy, 0, 0, 0, 0))

            # lower_sign = np.copysign(1.0, copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAGB, NSUR, wave, 0, hy, 0, -1, 0, 0))
            # chief_sign = np.copysign(1.0, copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAGB, NSUR, wave, 0, hy, 0, 0, 0, 0))
            # upper_sign = np.copysign(1.0, copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAGB, NSUR, wave, 0, hy, 0, +1, 0, 0))
            lower_sign = np.copysign(1.0, copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAB, NSUR, wave, 0, hy, 0, -1, 0, 0))
            chief_sign = np.copysign(1.0, copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAB, NSUR, wave, 0, hy, 0, 0, 0, 0))
            upper_sign = np.copysign(1.0, copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAB, NSUR, wave, 0, hy, 0, +1, 0, 0))


            lower.append(copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAID, NSUR, wave, 0, hy, 0, -1, 0, 0) * lower_sign)
            chief.append(copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAID, NSUR, wave, 0, hy, 0, 0, 0, 0) * chief_sign)
            upper.append(copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.RAID, NSUR, wave, 0, hy, 0, +1, 0, 0) * upper_sign)

            ydata.append(lower[-1])
            ydata.append(chief[-1])
            ydata.append(upper[-1])

        one_output = {}
        one_output.update({'description': 'incident angle vs image height'})
        one_output.update({'xlabel': f'Image Height in {str(copy_sys.SystemData.Units.LensUnits)}'})
        one_output.update({'xdata': image})
        one_output.update({'series_labels': ['Lower', 'Chief', 'Upper']})
        one_output.update({'num_series': 3})
        # one_output.update({'ydata': np.concatenate((np.asarray(lower), np.asarray(chief), np.asarray(upper))).tolist()})
        one_output.update({'ydata': ydata})

        copy_sys.Close(False)
        
        
        settings = {
            'window': 'IncidentAnglevsImageHeight',
            'field_density': field_density,
            'wavelength': wavelength
        }

        header = [
            f'Image height values are in {str(self.zos.TheSystem.SystemData.Units.LensUnits)}',
            'Lower, Chief, and Upper incident angle values are in degrees',
            f'Wavelength : {self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(wavelength).Wavelength:.4f} um'
            ]
        data = [one_output]

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
