# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import argparse
import json
import time
import threading
import webbrowser
from pathlib import Path

CONFIG_PATH = Path.home() / ".lens_harvest" / "config.json"


def _save_config(directory: str):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps({"last_directory": str(directory)}))


def _load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text())
        except Exception:
            pass
    return {}


def cmd_parse(args):
    from .run import RunAll

    directory = Path(args.directory)
    if not directory.is_dir():
        raise SystemExit(f"Error: Directory not found: {directory}")

    zmx_files = sorted(directory.glob("*.zmx"))
    if not zmx_files:
        raise SystemExit(f"Error: No .zmx files found in: {directory}")

    ra = RunAll()
    print(f"Parsing: {directory}")
    print(f"Found {len(zmx_files)} .zmx files")
    print("Connected to OpticStudio\n")

    total = len(zmx_files)
    start = time.perf_counter()

    def _fmt_time(s):
        h, r = divmod(s, 3600)
        m, s = divmod(r, 60)
        return f"{int(h):02d}:{int(m):02d}:{s:05.2f}"

    pad = len(str(total))
    for i, file in enumerate(zmx_files, 1):
        elapsed = time.perf_counter() - start
        if i > 1:
            avg = elapsed / (i - 1)
            remaining = avg * (total - i + 1)
            print(f"[{i:0{pad}d}/{total}]  Elapsed: {_fmt_time(elapsed)}  |  ETA: {_fmt_time(remaining)}  |  {file.name}")
        else:
            # pad the empty Elapsed/ETA columns so the filename lines up with later rows
            print(f"[{i:0{pad}d}/{total}]  {'':20}  |  {'':16}  |  {file.name}")
        ra.load_file(file)
        ra.all2()

    total_seconds = time.perf_counter() - start
    print(f"\nElapsed time: {_fmt_time(total_seconds)}")

    if ra.failed:
        print(f"\nFailed ({len(ra.failed)}):")
        for f in ra.failed:
            print(f"  {f}")
    else:
        print("\nAll files processed successfully.")

    _save_config(str(directory.resolve()))


def cmd_viewer(args):
    import pickle
    from .viewer import serve

    directory = args.directory
    if not directory:
        config = _load_config()
        directory = config.get("last_directory")

    if directory:
        directory = Path(directory)
        if not directory.is_dir():
            print(f"Warning: Directory not found: {directory}")
            directory = None

    host = args.host
    port = args.port

    url = f"http://{host}:{port}?theme=light"
    if directory:
        url += f"&dir={directory}"
        pkl_files = sorted(directory.glob("*.pkl"))
        if pkl_files:
            try:
                with open(pkl_files[0], "rb") as f:
                    data = pickle.load(f)
                if "lde" in data and "layout" in data:
                    url += "&layout=1x2&key=lde&key1=layout"
            except Exception:
                pass

    print(f"Starting viewer on {url}")

    threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    serve(host=host, port=port)


def main():
    parser = argparse.ArgumentParser(
        prog="lens_harvest",
        description="Zemax optical analysis toolkit — parse .zmx files or view .pkl results.",
        epilog="""examples:
  lens_harvest parse "C:\\path\\to\\zmx\\files"
  lens_harvest viewer
  lens_harvest viewer "C:\\path\\to\\pkl\\files"
  lens_harvest viewer --port 9000
  lens_harvest viewer --host 0.0.0.0 --port 8080
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # --- parse subcommand ---
    parse_parser = subparsers.add_parser(
        "parse",
        help="Run all analyses on .zmx files in a directory, outputting .pkl files.",
    )
    parse_parser.add_argument(
        "directory",
        type=str,
        help="Path to directory containing .zmx files",
    )

    # --- viewer subcommand ---
    viewer_parser = subparsers.add_parser(
        "viewer",
        help="Launch the web-based .pkl file viewer (use --port to change port, --host to change host).",
    )
    viewer_parser.add_argument(
        "directory",
        nargs="?",
        default=None,
        type=str,
        help="Optional path to directory containing .pkl files (can also be set in the UI)",
    )
    viewer_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind the server to (default: 127.0.0.1)",
    )
    viewer_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind the server to (default: 8000)",
    )

    args = parser.parse_args()

    if args.command == "parse":
        cmd_parse(args)
    elif args.command == "viewer":
        cmd_viewer(args)


if __name__ == "__main__":
    main()
