# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import numpy as np

import clr
from pathlib import Path

_zos = None

from System import Enum

class Connect(object):
    '''
    Connection to the ZOS-API.

    Due to limitations of how OpticStudio was installed, you need to pass in the install path

    By default this will run as an Extension but you can change it to Standalone for a test harness
    '''
    
    def __new__(cls, extension = False, zos_path = None, update_ui=False):
        # if already connected to OpticStudio, reuse the existing connection
        # instead of re-running _connect (which would re-validate zos_path
        # and silently fall back to the default install path)
        global _zos
        if _zos is not None:
            return _zos

        instance = super().__new__(cls)
        instance._connect(extension, zos_path, update_ui=update_ui)
        _zos = instance
        return instance

    def __init__(self, extension = False, zos_path = None, update_ui=False):
        # setup already happened in __new__, either for this instance or the
        # cached one being reused
        pass

    @classmethod
    def reset(cls):
        # drop the cached singleton so the next Connect(...) call establishes
        # a genuinely new connection instead of reusing a closed application
        global _zos
        _zos = None

    def _connect(self, extension, zos_path, update_ui):
        # check to make sure the user passed in a valid OpticStudio location...default to C:\Program Files
        if zos_path is None:
            zos_path = r"C:\Program Files\Zemax OpticStudio"
            
        # check to make sure the directory actually has the OpticStudio executible
        if zos_path is None or not (Path(zos_path) / 'OpticStudio.exe').is_file():
            raise FileNotFoundError('You need to provide a path to OpticStudio')
        
        # load the 
        clr.AddReference(str(Path(zos_path) / 'ZOSAPI.dll'))
        clr.AddReference(str(Path(zos_path) / 'ZOSAPI_Interfaces.dll'))
        import ZOSAPI

        # create a reference to the API namespace
        self.ZOSAPI = ZOSAPI

        # Create the initial connection class
        self.TheConnection = ZOSAPI.ZOSAPI_Connection()

        # determine connection type
        if extension:
            self.TheApplication = self.TheConnection.ConnectAsExtension(0)
        else:
            self.TheApplication = self.TheConnection.CreateNewApplication()

        # create reference to TheSystem
        self.TheSystem = self.TheApplication.PrimarySystem

        # turn off updates
        if not update_ui:
            self.TheApplication.ShowChangesInUI = False
        

    def __del__(self):
        if hasattr(self, 'TheApplication') and self.TheApplication is not None:
            # self.TheApplication.CloseApplication()
            self.TheApplication = None
        
        self.TheConnection = None

    def try_parse(self, enum, val, default=None, to_int=False):
        '''
        Performs a pythonnet safe `Enum.Parse`

            - default : return value if parsing fails
            - to_int  : converts to integer (useful for parsing enums for the Merit Function Editor)
        '''
        try:
            val = Enum.Parse(enum, val, True)
            if to_int:
                val = int(val)
            return True, val
        except:
            if default:
                try: 
                    val = Enum.Parse(enum, default, True)
                    if to_int:
                        val = int(val)
                    return True, val
                except: 
                    return False, None
            return False, None
    
    def detect_encoding(self, filename):
        with open(filename, "rb") as f:
            raw = f.read()

        if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
            encoding = "utf-16"
        elif raw.startswith(b"\xef\xbb\xbf"):
            encoding = "utf-8-sig"
        else:
            encoding = "cp1252"  # common Windows default

        return encoding
    
    def try_float(self, s):
        try:
            _ = float(s)
            return True
        except ValueError:
            return False
    
    def get_series(self, series):
        this_series = {
                'description': series.Description,
                'xlabel': '' if series.XLabel is None else series.XLabel,
                'xdata': [] if series.XData is None else list(series.XData.Data),
                'series_labels': [] if series.SeriesLabels is None else list(series.SeriesLabels),
                'num_series': series.NumSeries,
                'ydata': [] if series.YData is None else list(series.YData.Data)
            }
        
        return this_series

    def get_grid(self, grid):
        # convert `nan` to None for JSON serialization
        # data = np.flipud(np.asarray(grid.Values))
        data = np.asarray(grid.Values)
        data_obj = data.astype(object)
        data_obj[np.isnan(data)] = None

        data = data_obj.tolist()

        this_grid = {
            'description': grid.Description,
            'x_label': grid.XLabel,
            'y_label': grid.YLabel,
            'value_label': grid.ValueLabel,
            'nx': grid.Nx,
            'ny': grid.Ny,
            'dx': grid.Dx,
            'dy': grid.Dy,
            'min_x': grid.MinX,
            'min_y': grid.MinY,
            'values': data
        }
        return this_grid
    


            
    

if __name__ == '__main__':
    pass
