# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr


class LDE(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
    
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav
    
    def run(self):
        '''
        Places the basics from the LDE into a dataframe for simple read-only access
        '''
        colors = {
            '#ffd2d2': [
                'CoordinateBreak'
            ],
            '#d2d2ff': [
                'Gradient1', 
                'Gradient2', 
                'Gradient3', 
                'Gradient4',
                'Gradient5',
                'Gradient6',
                'Gradient7',
                'Gradient9',
                'Gradient10',
                'Gradient12',
                'Gradium'
            ],
            '#d2ffd2': [
                'Paraxial',
                'ParaxialXY'
            ]
        }

        # note: there is no `NoColor` enum, so can't fully capture all the colors
        zemax_color = {
            'Color1': '#bfbffe',
            'Color2': '#bffebf',
            'Color3': '#febfbf',
            'Color4': '#eeeebf',
            'Color5': '#febffe',
            'Color6': '#bffefe',
            'Color7': '#dedefe',
            'Color8': '#defede',
            'Color9': '#debfde',
            'Color10': '#febfce',
            'Color11': '#debffe',
            'Color12': '#fedede',
            'Color13': '#c3def9',
            'Color14': '#c8e0f4',
            'Color15': '#cde1f0',
            'Color16': '#d2e3eb',
            'Color17': '#d7e5e6',
            'Color18': '#dce6e1',
            'Color19': '#e1e8dc',
            'Color20': '#e6ead7',
            'Color21': '#ebebd2',
            'Color22': '#f0edcd',
            'Color23': '#f4eec8',
            'Color24': '#f9f0c3',
        }
        
        


        all_rows = []
        im1 = None
        for i in range(0, self.zos.TheSystem.LDE.NumberOfSurfaces):
            surf = self.zos.TheSystem.LDE.GetSurfaceAt(i)

            color = str(surf.TypeData.RowColor)

            if color == 'Default':
                surface = str(surf.Type)
                default_color = next((key for key, lst in colors.items() if surface in lst), None)

                # determine if a glass or a mirror
                index = self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.INDX, i, 1, 0, 0, 0, 0, 0, 0)

                if abs(index) > 1.0:
                    color = '#d2d2ff'
                elif surf.Material == 'MIRROR' and im1 is not None and abs(abs(im1) - 1.0) < 1e-10:
                    color ='#d7d7d7'
                else:
                    color = default_color
                if i > 0:
                    im1 = index
            else:
                color = zemax_color[color]
                

                
            

            this_row = {
                'type': str(surf.Type),
                'comment': surf.Comment,
                'radius': 'Infinity' if not np.isfinite(surf.Radius) else surf.Radius,
                'thickness': 'Infinity' if not np.isfinite(surf.Thickness) else surf.Thickness,
                'material': surf.Material,
                'coating': surf.Coating,
                'semi_diameter': surf.SemiDiameter,
                'chip_zone': surf.ChipZone,
                'mech_semi_diameter': surf.MechanicalSemiDiameter,
                'conic': surf.Conic,
                'tce': surf.TCE,
                'color': color
            }
        
            all_rows.append(this_row)

        
        
        settings = {
            'window': 'LDE'
        }

        header = []
        data = [pd.DataFrame(all_rows).to_json(orient='records'), ]

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
