# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect

import math
import numpy as np
import pandas as pd
import pyvista as pv
import os
import warnings

import clr
from System import Enum, Int32, Double

import json

import time

class Layout:
    def __init__(self, zos = None, settings_first = False, **kwargs):
        self.t0 = time.perf_counter()
        self.zos = zos

        if kwargs.get('screenshot') and os.path.exists(kwargs.get('filename')):
            self.plotter = pv.Plotter(off_screen=True)
        else:
            self.plotter = pv.Plotter()

        # set default plotter positions
        self.plotter.camera_position = [(-1, 0, 0), (0, 0, 0), (0, 1, 0)]        # make +y point up and +z point right
        if kwargs.get('show_orientation', True):
            self.plotter.show_axes()                                             # show indicator in bottom left
        self.plotter.camera.parallel_projection = True                           # make object/image parallel (remove perspective)
        self.plotter.reset_camera()                                              # reset camera (centers, zooms, and allows for correct rotation

        # common .net values for overloading commonly named functions
        self.int = Int32(1)
        self.dbl = Double(1.0)

        # colors for plotting rays
        self.colors = ['#0000FF', '#00FF00', '#FF0000', '#BFBF00',
                       '#FF00FF', '#00FFFF', '#7F7FFF', '#7FFF7F',
                       '#7F007F', '#FF003F', '#7F00FF', '#FF7F7F',
                       '#137EEB', '#2785D7', '#3A8BC4', '#4E92B0',
                       '#62989C', '#759F89', '#89A575', '#9CAC62',
                       '#B0B24E', '#C4B93A', '#D7BF27', '#EBC613']

        # let's check if it's sequential or non-sequential
        self.mode = self.zos.TheSystem.Mode

        if not settings_first:
            self.run(**kwargs)

        pass

    def _cross_section(self, mesh):
        '''
        converts a mesh into a YZ or XZ cross section for `3D Layout` view
        '''
        # use res[0] for YZ and res[0] for XZ
        return  mesh.slice_orthogonal(x = 0.0)
    
    def _view_xy(self):
        '''
        reorients camera position to XY plane
        '''
        self.plotter.camera_position = [(0, 0, 1), (0, 0, 0), (0, 1, 0)]
        self.plotter.update()
    def _view_yz(self):
        '''
        reorients camera position to YZ plane (default)
        '''
        self.plotter.camera_position = [(-1, 0, 0), (0, 0, 0), (0, 1, 0)]
        self.plotter.update()
    def _view_xz(self):
        '''
        reorients camera position to XZ plane
        '''
        self.plotter.camera_position = [(0, 1, 0), (0, 0, 0), (1, 0, 0)]
        self.plotter.update()
    
    def _planar_quad(self, pts):
        '''
        Reduce a dense planar point cloud (e.g. a detector tessellated to a 251x251
        grid) down to its 4 bounding corners as two triangles. Uses SVD to find the
        in-plane axes so it works for tilted/decentered objects. Returns
        (corner_pts Nx3, faces) in the same format as the rest of _get_surfaces, or
        None if the points aren't usable.
        '''
        pts = np.asarray(pts, dtype=float)
        if len(pts) < 4:
            return None
        c = pts.mean(axis=0)
        # principal axes of the (planar) point set; first two span the plane
        _, _, vt = np.linalg.svd(pts - c, full_matrices=False)
        e1, e2 = vt[0], vt[1]
        a = (pts - c) @ e1
        b = (pts - c) @ e2
        amin, amax, bmin, bmax = a.min(), a.max(), b.min(), b.max()
        corners = np.array([
            c + amin * e1 + bmin * e2,
            c + amax * e1 + bmin * e2,
            c + amax * e1 + bmax * e2,
            c + amin * e1 + bmax * e2,
        ])
        faces = np.array([3, 0, 1, 2, 3, 0, 2, 3])
        return corners, faces

    def _object_color_hex(self, nce, obj_num):
        '''
        Returns an NSC object's DrawData.ObjectColor as a hex string, or None.
        ObjectColor is a ZemaxColor enum: 'Color1'..'Color24' map onto the same 24
        colors used for the rays (self.colors); 'Default' (or anything else) -> None.
        '''
        if nce is None:
            return None
        try:
            color = str(nce.GetObjectAt(obj_num).DrawData.ObjectColor)
        except Exception:
            return None
        if color.startswith('Color'):
            try:
                idx = int(color[5:]) - 1        # Color1 -> index 0
            except ValueError:
                return None
            if 0 <= idx < len(self.colors):
                return self.colors[idx]
        return None

    def _get_surfaces(self, **kwargs) -> None:
        '''
        runs the `OpenShadedModelVisuzlizationExport` tool to get the trimesh.
        converts the XYZ values to the needed
        '''
        

        # list of lookup words
        list_start_surface = ['first_surface', 'start_surface', 'start', 'StartSurface']
        list_end_surface = ['last_surface', 'end_surface', 'end', 'EndSurface']

        start_surface = next((kwargs[k] for k in list_start_surface if k in kwargs), 1)
        end_surface = next((kwargs[k] for k in list_end_surface if k in kwargs), self.zos.TheSystem.LDE.NumberOfSurfaces - 1)

        # open shaded model export and get triangles
        tool = self.zos.TheSystem.Tools.OpenShadedModelVisualizationExport()
        tool.StartSurface = start_surface
        tool.EndSurface = end_surface

        # run the tool
        tool.RunAndWaitForCompletion()

        # get the export results
        tris = tool.GetResults()

        # always close your tools
        tool.Close()
        

        # get raw data from shaded model visualization
        self.x = np.array(tris.XCoords.Data)
        self.y = np.array(tris.YCoords.Data)
        self.z = np.array(tris.ZCoords.Data)
        self.surface_index = np.array(tris.SurfaceIndex.Data)
        self.object_index = np.array(tris.ObjectIndex.Data)

        self.surfaces =[]
        # parallel to self.surfaces, recorded per mesh group:
        #   surface_object  -> NSC object number (used to highlight a layout object
        #                      when its NCE row is clicked)
        #   surface_surface -> surface/face number (used for sequential highlight)
        #   surface_color   -> NSC object's DrawData.ObjectColor as hex (shaded view)
        self.surface_object = []
        self.surface_surface = []
        self.surface_color = []

        # NSC objects can be individually colored via DrawData.ObjectColor, returned
        # as a ZemaxColor enum (Color1..Color24, or Default). Map it to the same 24
        # hex colors used for the rays so a shaded layout matches. Only meaningful in
        # non-sequential mode.
        is_nsc = self.mode == self.zos.ZOSAPI.SystemType.NonSequential
        nce = self.zos.TheSystem.NCE if is_nsc else None

        # detector objects get tessellated to a huge (e.g. 251x251) grid by the
        # shaded-model export, which dominates the file size. A detector is a flat
        # rectangle, so we decimate those meshes to 4 corners. Look up which NSC
        # object numbers are detectors.
        detector_objs = set()
        if is_nsc:
            for i in range(1, nce.NumberOfObjects + 1):
                if str(nce.GetObjectAt(i).Type)[:8].lower() == 'detector':
                    detector_objs.add(i)

        # Group by the (surface, object) COMPOSITE, not surface alone. In NSC a
        # single surface_index (face index) is shared across every object, so
        # grouping by surface alone mixes multiple objects into one mesh and makes
        # per-object highlighting impossible. In sequential mode object_index is
        # constant, so this reduces to the original by-surface grouping (and
        # np.unique still sorts ascending, so mesh order is unchanged).
        keys = np.column_stack((self.surface_index, self.object_index))
        for s, o in np.unique(keys, axis=0):

            # convert the raw points to a PyVista structure
            mask = (self.surface_index == s) & (self.object_index == o)
            _x = self.x[mask]
            _y = self.y[mask]
            _z = self.z[mask]

            # record which surface & object this mesh group maps to
            self.surface_surface.append(int(s))
            self.surface_object.append(int(o))

            # record the NSC object's draw color (None in seq mode / on failure)
            self.surface_color.append(self._object_color_hex(nce, int(o)) if is_nsc else None)
            # pts = np.column_stack((self.x, self.y, self.z))
            pts = np.column_stack((_x, _y, _z))

            # detectors are flat rectangles tessellated into tens of thousands of
            # triangles; collapse them to a 4-corner quad to keep the file small
            quad = self._planar_quad(pts) if int(o) in detector_objs else None
            if quad is not None:
                unique_pts, faces = quad
            else:
                # step 1: find unique points and mapping
                unique_pts, indices = np.unique(pts, axis=0, return_inverse=True)

                # step 2: build faces array (each triangle has 3 points, face array format: [n_points, i0, i1, i2, ...])
                faces = []
                for i in range(0, len(indices), 3):
                    faces.append([3, indices[i], indices[i + 1], indices[i + 2]])
                faces = np.hstack(faces)

            # step 3: create pyvista mesh
            mesh = pv.PolyData(unique_pts, faces)

            # save the mesh for future plotting
            self.surfaces.append(mesh)

        

    def _get_pwav(self):
        '''
        Determines the primary wavelength of the currently loaded optical system
        '''
        for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
            if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                return i
        return None
    def _field_number_to_normalized_coordinates(self):
        fx = []
        fy = []
        for i in range(1, self.zos.TheSystem.SystemData.Fields.NumberOfFields + 1):
            f = self.zos.TheSystem.SystemData.Fields.GetField(i)
            if not f.Ignore:
                fx.append(f.X)
                fy.append(f.Y)
        
        if self.zos.TheSystem.SystemData.Fields.Normalization == self.zos.ZOSAPI.SystemData.FieldNormalizationType.Rectangular:
            max_x = max(fx)
            max_y = max(fy)

            if abs(max_x) < 1e-10:
                res_x = [0 for f in fx]
            else:
                res_x = [f / max_x for f in fx]
            if abs(max_y) < 1e-10:
                res_y = [0 for f in fy]
            else:
                res_y = [f / max_y for f in fy]

            return res_x, res_y
        else:
            # avoiding numpy due to overhead of initializing array
            # max index is 2025 elements and numpy excels with arrays over 100,000 elements
            # r = np.sqrt(np.asarray(fx)**2 + np.asarray(fy)**2).tolist()
            
            r = [math.sqrt(x**2 + y**2) for x, y in zip(fx, fy)]
            if abs(max(r)) < 1e-10:
                return [0 for f in fx], [0 for f in fy]
            else:
                return [f / max(r) for f in fx], [f / max(r) for f in fy]

        pass
    def _raytrace_local_to_global(self, surface, x, y, z):
        success, r11, r12, r13, r21, r22, r23, r31, r32, r33, xo, yo, zo = self.zos.TheSystem.LDE.GetGlobalMatrix(
            surface,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl,
            self.dbl
        )

        
        if all(isinstance(i, list) for i in (x, y, z)) and len(x) == len(y) == len(z):
            xg = []
            yg = []
            zg = []
            for xl, yl, zl in zip(x, y, z):
                xg.append(r11 * xl + r12 * yl + r13 * zl + xo)
                yg.append(r21 * xl + r22 * yl + r23 * zl + yo)
                zg.append(r31 * xl + r32 * yl + r33 * zl + zo)
            return xg, yg, zg
        else:
            xg = r11 * x + r12 * y + r13 * z + xo
            yg = r21 * x + r22 * y + r23 * z + yo
            zg = r31 * x + r32 * y + r33 * z + zo
            return xg, yg, zg
            
        

        pass
    def _raytrace_ray_pattern(self, **kwargs):
        list_pattern = ['pattern', 'ray_pattern']
        pattern = next((kwargs[k] for k in list_pattern if k in kwargs), 'yfan')
        
        number_of_rays = kwargs.get('number_of_rays', 7)

        
        px = []
        py = []
        match pattern:
            case 'yfan':
                px = np.linspace(0, 0, number_of_rays).tolist()
                py = np.linspace(-1, 1, number_of_rays).tolist()
                return px, py
            case 'xfan':
                px = np.linspace(-1, 1, number_of_rays).tolist()
                py = np.linspace(0, 0, number_of_rays).tolist()
                return px, py
            case 'xyfan':
                px1 = np.linspace(0, 0, number_of_rays).tolist()
                py1 = np.linspace(-1, 1, number_of_rays).tolist()

                px2 = np.linspace(-1, 1, number_of_rays).tolist()
                py2 = np.linspace(0, 0, number_of_rays).tolist()
                return px1 + px2, py1 + py2
            case 'ring':
                # we need to +1 so the starting & ending coordinates are the same...then delete the last element
                theta = np.linspace(-np.pi, np.pi, number_of_rays + 1)

                px = 1.0 * np.cos(theta)
                py = 1.0 * np.sin(theta)
                
                px = np.delete(px, -1)
                py = np.delete(py, -1)
                
                return px.tolist(), py.tolist()
            case 'list':
                # open the `raylist.txt` file
                # M_TODO: right now we are only testing for normalized coordinates...need to check for DIRECT keyword
                raylist = os.path.join(os.path.sep, self.zos.TheSystem.TheApplication.ZemaxDataDir, r'Miscellaneous\RAYLIST.txt')
                
                if os.path.exists(raylist):
                    px = []
                    py = []
                    with open(raylist, 'r') as file:
                        for line in file:
                            parts = line.split()
                            if len(parts) == 2:
                                px.append(float(parts[0]))
                                py.append(float(parts[1]))

                    if len(px) == 0 or len(py) == 0:
                        # failure to read the `raylist.txt` file, default to standard values
                        px = [0, 0, 0, 0]
                        py = [0.1, 0.2, 0.3, 0.8]
                else:
                    # if there is no defined raylist, the default is 4 pupil rays
                    px = [0, 0, 0, 0]
                    py = [0.1, 0.2, 0.3, 0.8]
 
                return px, py
            case 'random':
                # convert to polar to make sure we are always inside the unit circle
                r = np.sqrt(np.random.uniform(0, 1, number_of_rays))
                theta = np.random.uniform(0, 2*np.pi, number_of_rays)

                px = r * np.cos(theta)
                py = r * np.sin(theta)

                
                return px.tolist(), py.tolist()
            case 'grid':
                px = np.linspace(-1, 1, number_of_rays)
                py = np.linspace(-1, 1, number_of_rays)

                X, Y = np.meshgrid(px, py)

                mask = X**2 + Y**2 <= 1

                x_inside = X[mask]
                y_inside = Y[mask]

                stacked = np.column_stack((x_inside, y_inside))
                return stacked[:, 0], stacked[:, 1]
        return px, py
        pass
    def _max_defined_layout_rays(self, default=20):
        '''
        Largest '# Layout Rays' (Par1) defined across all source objects in the NCE.
        Used to set MaxRays so we draw min(defined rays, cap) rather than a flat cap.
        '''
        nce = self.zos.TheSystem.NCE
        ObjectColumn = self.zos.ZOSAPI.Editors.NCE.ObjectColumn
        max_rays = 0
        for i in range(1, nce.NumberOfObjects + 1):     # NCE is 1-based, like the MFE
            obj = nce.GetObjectAt(i)
            if str(obj.Type)[:6].lower() != 'source':
                continue
            cell = obj.GetObjectCell(ObjectColumn.Par1)
            max_rays = max(max_rays, int(cell.IntegerValue))
        return max_rays if max_rays > 0 else default

    def _source_ray_counts(self):
        '''
        [(object_number, layout_ray_count), ...] for every source object, in NCE
        editor order. The launch-ray count is each source's '# Layout Rays' (Par1).
        '''
        nce = self.zos.TheSystem.NCE
        ObjectColumn = self.zos.ZOSAPI.Editors.NCE.ObjectColumn
        sources = []
        for i in range(1, nce.NumberOfObjects + 1):     # NCE is 1-based, like the MFE
            obj = nce.GetObjectAt(i)
            if str(obj.Type)[:6].lower() != 'source':
                continue
            count = int(obj.GetObjectCell(ObjectColumn.Par1).IntegerValue)
            sources.append((i, count))
        return sources

    def _source_object_numbers(self):
        '''NCE object numbers of every source object, in editor order.'''
        nce = self.zos.TheSystem.NCE
        out = []
        for i in range(1, nce.NumberOfObjects + 1):     # NCE is 1-based, like the MFE
            if str(nce.GetObjectAt(i).Type)[:6].lower() == 'source':
                out.append(i)
        return out

    def _set_analysis_rays(self, obj_num, value):
        '''set a source object's # Analysis Rays (Par2), fetching the cell fresh.'''
        ObjectColumn = self.zos.ZOSAPI.Editors.NCE.ObjectColumn
        obj = self.zos.TheSystem.NCE.GetObjectAt(obj_num)
        obj.GetObjectCell(ObjectColumn.Par2).IntegerValue = int(value)

    def _get_analysis_rays(self, obj_num):
        '''read a source object's # Analysis Rays (Par2), fetching the cell fresh.'''
        ObjectColumn = self.zos.ZOSAPI.Editors.NCE.ObjectColumn
        obj = self.zos.TheSystem.NCE.GetObjectAt(obj_num)
        return int(obj.GetObjectCell(ObjectColumn.Par2).IntegerValue)

    def _raytrace_nonsequential(self, **kwargs):
        use_polarization = kwargs.get('use_polarization', False)
        split_rays = kwargs.get('split_rays', False)
        scatter_rays = kwargs.get('scatter_rays', False)


        if use_polarization and not split_rays and not scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UsePolarization
        elif use_polarization and split_rays and not scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UsePolarizationSplitting
        elif use_polarization and not split_rays and scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UsePolarizationScattering
        elif use_polarization and split_rays and scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UsePolarizationSplittingScattering
        elif not use_polarization and split_rays and not scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UseSplitting
        elif not use_polarization and not split_rays and scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UseScattering
        elif not use_polarization and split_rays and scatter_rays:
            options = self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions.UseSplittingScattering
        else:
            options = Enum.Parse(self.zos.ZOSAPI.Tools.RayTrace.NSCTraceOptions, 'None')

        # build up all the data in a list first and then convert to a dataframe
        rays = []

        max_segments = 100
        coherence_length = 0

        ObjectColumn = self.zos.ZOSAPI.Editors.NCE.ObjectColumn
        ObjectType = self.zos.ZOSAPI.Editors.NCE.ObjectType
        sources = self._source_object_numbers()

        # Trace one source at a time. The ZOS-API does NOT honor turning a source off
        # (UseSingleSource / Source / ray counts are all ignored), so instead we work
        # on a throwaway COPY of the system: convert every source except the active
        # one into a NullObject, leaving exactly one emitter. Each ray is tagged with
        # its source. The copy is closed (discarded) each iteration, so the real
        # system is never modified -- no snapshot/restore needed.
        for src in sources:
            cpy = self.zos.TheSystem.CopySystem()
            cpy_nce = cpy.NCE

            # null out every other source so only `src` emits rays in this copy
            for s in sources:
                if s == src:
                    continue
                obj = cpy_nce.GetObjectAt(s)
                obj.ChangeType(obj.GetObjectTypeSettings(ObjectType.NullObject))

            # limit the surviving source: no layout rays, 10 analysis rays
            src_obj = cpy_nce.GetObjectAt(src)
            src_obj.GetObjectCell(ObjectColumn.Par1).IntegerValue = 0     # # Layout Rays
            src_obj.GetObjectCell(ObjectColumn.Par2).IntegerValue = 10    # # Analysis Rays

            tool = cpy.Tools.OpenBatchRayTrace()
            nsc = tool.CreateNSCSourceData(max_segments, coherence_length)
            nsc.UseAnyWavelength()
            nsc.UseSingleSource = False
            nsc.MaxRays = 10
            nsc.TraceOptions = options

            tool.RunAndWaitForCompletion()
            nsc.StartReadingResults()

            success_ray, rn, ec, wave, num_seg = nsc.ReadNextResult(self.int, self.int, self.int, self.int)
            while success_ray:
                success_seg, seg_level, seg_parent, hitObj, insideOf, x, y, z, l, m, n, _, _, _, _, _, _, _, _ = nsc.ReadNextSegment(
                    self.int,
                    self.int,
                    self.int,
                    self.int,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl,
                    self.dbl
                )
                while success_seg:
                    # add ray data here (tagged with the source object number)
                    row = {
                        'source': int(src),
                        'ray': rn,
                        'wave': wave,
                        'level': seg_level,
                        'parent': seg_parent,
                        'hit': hitObj,
                        'x': x,
                        'y': y,
                        'z': z,
                        'l': l,
                        'm': m,
                        'n': n
                    }

                    rays.append(row)

                    success_seg, seg_level, seg_parent, hitObj, insideOf, x, y, z, l, m, n, _, _, _, _, _, _, _, _ = nsc.ReadNextSegment(
                        self.int,
                        self.int,
                        self.int,
                        self.int,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl,
                        self.dbl
                    )
                    # add to list
                success_ray, rn, ec, wave, num_seg = nsc.ReadNextResult(self.int, self.int, self.int, self.int)

            # close this source's tool and discard the copy system before the next
            tool.Close()
            cpy.Close(False)

        # build up dataframe
        return pd.DataFrame(rays)

        pass
    def _raytrace_norm_unpol_single(self, **kwargs):
        # check for finite object distances (only look at S0, so if S0=1 but S1=Inf we don't capture this)
        ss = 0 if math.isfinite(self.zos.TheSystem.LDE.GetSurfaceAt(0).Thickness) else 1

        first_surface = kwargs.get('first_surface', ss)
        last_surface = kwargs.get('last_surface', self.zos.TheSystem.LDE.NumberOfSurfaces - 1)

        # we'll always use real rays since we're showing a layout
        fields = self._raytrace_parse_fields(**kwargs)
        hx, hy = self._field_number_to_normalized_coordinates()
        wavelengths = self._raytrace_parse_wavelengths(**kwargs)

        # get pupil rays
        pupils = self._raytrace_ray_pattern(**kwargs)

        # open batchraytrace tool
        tool = self.zos.TheSystem.Tools.OpenBatchRayTrace()

        # build up all the data in a list first and then convert to a dataframe
        rays = []
        
        # list of surfaces that we always ignore in ray tracing, even if the `TypeData.IgnoreThisSurface` is False
        skip_surfaces = ['CoordinateBreak']

        # loop through all the sequential 
        for wave in wavelengths:
            for field in [f - 1 for f in fields]:
                for pdx, (px, py) in enumerate(zip(*pupils)):
                    for surf in range(first_surface, last_surface + 1):
                        # M_TODO: 
                        #   - account for non-sequential component
                        #   - account for GRIN materials
                        #   - account for DIRECT ray
                        if (self.zos.TheSystem.LDE.GetSurfaceAt(surf).DrawData.SkipRaysToThisSurface or 
                            str(self.zos.TheSystem.LDE.GetSurfaceAt(surf).Type) in skip_surfaces):
                            continue
                        success, ec, vc, xo, yo, zo, *_ = tool.SingleRayNormUnpol(
                            self.zos.ZOSAPI.Tools.RayTrace.RaysType.Real,
                            surf,
                            wave,
                            hx[field], 
                            hy[field], 
                            px, 
                            py,
                            False,
                            self.int,
                            self.int,
                            self.dbl,
                            self.dbl,
                            self.dbl, 
                            self.dbl, 
                            self.dbl, 
                            self.dbl, 
                            self.dbl, 
                            self.dbl, 
                            self.dbl, 
                            self.dbl, 
                            self.dbl
                        )
                        xg, yg, zg = self._raytrace_local_to_global(surf, xo, yo, zo)  # this is probably not efficient since we need to get the GCRM each time
                        row = {
                            'surf': surf,
                            'wave': wave,
                            'fdx': field,
                            'pdx': pdx,
                            'hx': hx[field],
                            'hy': hy[field],
                            'px': px,
                            'py': py,
                            'xl': xo,
                            'yl': yo,
                            'zl': zo,
                            'xg': xg,
                            'yg': yg,
                            'zg': zg,
                            'ec': ec,
                            'vc': vc,
                            'seg': 0        # the segment will be used for GRIN ray tracing in the future
                        }
                        rays.append(row)
                        pass
        
        # always close your tool
        tool.Close()

        # build up dataframe
        return pd.DataFrame(rays)
   
    
    def _raytrace_parse_wavelengths(self, **kwargs):
        wavelength = kwargs.get('wavelength', 'pwav')

        # convert the `wavelength` input to the appropriate list of values
        if type(wavelength) is str:
            if wavelength.lower() == 'all':
                return list(range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1))
            elif wavelength.lower() == 'pwav':
                return [int(self._get_pwav())]
            else:
                return [int(wavelength)]
        elif type(wavelength) is int:
            return [wavelength]
        else:
            raise ValueError('could not determine the wavelengths') 
    def _raytrace_parse_fields(self, **kwargs):
         # (fields will be ignored for direct ray trace but logic is same as wavelengths so check here)
        field = kwargs.get('field', 1)

        # convert the `field` input to the appropriate list of values
        if type(field) is str:
            if field.lower() == 'all':
                return list(range(1, min(self.zos.TheSystem.SystemData.Fields.NumberOfFields + 1, 13)))
            else:
                return list(int(field))
        elif type(field) is int:
            return [field]
        else:
            raise ValueError('could not determine the fields')
    # explicit ray colors per source, in source (editor) order: O1 blue, O2 red, O3 green
    NSC_SOURCE_COLORS = ['#0000FF', '#FF0000', '#00FF00', '#BFBF00',
                         '#FF00FF', '#00FFFF', '#7F7FFF', '#7FFF7F']

    def _get_nsc_rays(self, **kwargs):
        # _raytrace_nonsequential traces each source on its own and tags every row
        # with its 'source' object number. Group the rays by that column and emit one
        # colored mesh per source so the viewer colors each source independently.
        meshes = []

        rays = self._raytrace_nonsequential(**kwargs)
        if rays.empty:
            self._rays = meshes
            return

        for sdx, src in enumerate(rays['source'].unique().tolist()):
            src_df = rays[rays['source'] == src]

            ray_list = []
            for ray in src_df['ray'].unique().tolist():
                df = src_df[src_df['ray'] == ray]
                ray_list.append(pv.lines_from_points(
                    np.vstack(np.column_stack([df['x'], df['y'], df['z']]))
                ))

            if ray_list:
                meshes.append({
                    'wave': 1,
                    'field': sdx + 1,
                    'source': int(src),     # NCE object number -> Sn
                    'color': self.NSC_SOURCE_COLORS[sdx % len(self.NSC_SOURCE_COLORS)],
                    'mesh': pv.merge(ray_list)
                })

        self._rays = meshes

    def _get_rays(self, **kwargs):
        '''
        runs an ibatchraytrace based on filetype and layout settings
        '''
        use_direct = kwargs.get('use_direct', False)
        to_surface = kwargs.get('to_surface', self.zos.TheSystem.LDE.NumberOfSurfaces - 1)

        # open reference to the tool
        
        # so we don't actually need most `direct` and no `pol` ray tracing for layouts
        # the only time we need direct ray tracing is if we use `list` and `DIRECT` is found
        if use_direct:
            # check if ray aiming...provide warning
            if self.zos.TheSystem.SystemData.RayAiming.RayAiming != self.zos.ZOSAPI.SystemData.RayAimingMethod.Off:
                warnings.warn('RayAiming will be overriden using direct ray trace')
        else:
            rays = self._raytrace_norm_unpol_single(**kwargs)
                
        
        # convert the rays from dataframe to mesh
        uw = rays['wave'].unique().tolist()
        uf = rays['fdx'].unique().tolist()
        up = rays['pdx'].unique().tolist()

        meshes = []

        for wave in uw:
            for field in uf:
                
                df = rays[(rays['wave'] == wave) & (rays['fdx'] == field)]
                ray = []
                for pupil in up:
                    this_ray = df[(df['pdx'] == pupil)]
                    ray.append(pv.lines_from_points(
                        np.vstack(np.column_stack([
                            this_ray['xg'],
                            this_ray['yg'],
                            this_ray['zg']
                    ]))))
                    pass
                meshes.append({
                    'wave': wave,
                    'field': field,
                    'mesh': pv.merge(ray)
                })

        self._rays = meshes
        
        
    
    def plot(self, all_meshes = None, **kwargs):
        '''
        plots all the meshes in a layout plot.  
        if `all_meshes = None`, then the default 3D Layout with YZ fan is plotted
        '''

        # add rays (make sure this is first so the cross-section looks appropriate)
        num_rays = kwargs.get('number_of_rays')
        if num_rays is not None and num_rays > 0:
            for idx, ray in enumerate(self._rays):
                self.plotter.add_mesh(ray['mesh'], color=self.colors[idx % len(self.colors)], line_width=1.5)

        list_shaded_model = ['layout']
        shaded_model = next((kwargs[k] for k in list_shaded_model if k in kwargs), 'cross')

        # add surfaces
        if all_meshes == None:
            # this is the default 
            if shaded_model == 'shaded':
                self.plotter.add_mesh(self.surfaces, opacity=0.5)
            else:
                multi = pv.MultiBlock(self.surfaces)

                cross = self._cross_section(pv.MultiBlock(self.surfaces))
                # self.plotter.add_mesh(cross[0], color='black', line_width=1.5, show_edges=True)
                for idx, c in enumerate(cross):
                    # colors any surface listed in the `color_surfaces` kwargs to orange, otherwise the surface will be black
                    # ccc = 'orange' if (idx + 1) in kwargs.get('color_surfaces') else 'black'
                    ccc = 'black'
                    self.plotter.add_mesh(c[0], color=ccc, line_width=1.5, show_edges=True)
                    # make all surfaces black (we could pass in an array of colored )
                    # self.plotter.add_mesh(c[0], color='black', line_width=1.5, show_edges=True)
                    if kwargs.get('xbars'):
                        self.plotter.add_mesh(c[1], color='black', line_width=1.5)
                # if kwargs.get('xbars'):
                #     self.plotter.add_mesh(cross[1], color='black', line_width=1.5)
        else:
            for mesh in all_meshes:
                self.plotter.add_mesh(mesh)
                # plotter.add_mesh(mesh, opacity=0.5)
        
        if kwargs.get('title'):
            self.plotter.add_title(kwargs.get('title'))
        
        # self.plotter.add_axes(interactive=True)  # interactive 3D axes

        if os.path.exists(kwargs.get('logo', '')):
            self.plotter.add_logo_widget(
                logo=kwargs.get('logo'),
                position=(0.85, 0.05),
                size=(0.1, 0.1),
                opacity=1.0
                )

        self.plotter.reset_camera()     # always reset the camera
        
        if kwargs.get('screenshot') and os.path.exists(kwargs.get('filename')):
            self.plotter.screenshot(kwargs.get('filename'))
        else:
            self.plotter.show()
        pass
    def save(self):

        pass
    def run(self, **kwargs):
        # run the shaded model tool
        self._get_surfaces(**kwargs)

        
        # get the rays (good for both seq & nsc modes)
        num_rays = kwargs.get('number_of_rays')
        if num_rays is not None and num_rays > 0:
            if self.mode == self.zos.ZOSAPI.SystemType.NonSequential:
                self._get_nsc_rays(**kwargs)
            else:
                self._get_rays(**kwargs)
        
        t1 = time.perf_counter()
        

        # plot results
        if not kwargs.get('skip_plot'):
            self.plot(**kwargs)

        cross = self._cross_section(pv.MultiBlock(self.surfaces))
        
        # save to JSON for three.js
        # In PyVista/VTK, lines = [n1, i0, i1, ..., n2, j0, j1, j2, ...]
        # where n1 = number of points in first line, etc.
        # Let’s parse that into easier JSON format
        json_rays = []
        for ray_set in self._rays:
            lines = ray_set['mesh'].lines.tolist()
            parsed_lines = []
            i = 0
            while i < len(lines):
                n = lines[i]
                ids = lines[i+1:i+1+n]
                parsed_lines.append(ids)
                i += n + 1
            json_rays.append({
                'points': ray_set['mesh'].points.astype(np.float32),
                'lines': parsed_lines,
                'color': ray_set.get('color'),      # explicit per-source ray color (None -> viewer palette)
                'source': ray_set.get('source')
            })
        
        multi = pv.MultiBlock(self.surfaces)

        # Keep geometry as compact numpy arrays (float32 for points, int32 for the
        # face/line index arrays) instead of nested Python float lists. Pickled
        # ndarrays are far smaller than list[list[float]] and the viewer's
        # make_json_safe converts ndarrays to lists when serving the data as JSON.
        mesh_points = []
        mesh_faces = []
        xz_cross_points = []
        xz_cross_lines = []
        yz_cross_points = []
        yz_cross_lines = []
        for m in multi:
            mesh_points.append(m.points.astype(np.float32))
            mesh_faces.append(m.faces.astype(np.int32))

            cross = self._cross_section(m)

            xz_cross_points.append(cross[1].points.astype(np.float32))
            xz_cross_lines.append(cross[1].lines.reshape(-1, 3)[:, 1:].astype(np.int32))

            yz_cross_points.append(cross[0].points.astype(np.float32))
            yz_cross_lines.append(cross[0].lines.reshape(-1, 3)[:, 1:].astype(np.int32))
            
        data = {
            # NOTE: the old per-triangle 'surfaces' index array was dropped -- it was
            # unused by the viewer and was ~half the NSC file size.
            # per-mesh-group arrays, parallel to mesh/xz_cross/yz_cross:
            #   objects        -> NSC object number (non-sequential highlight)
            #   surface_groups -> surface/face number (sequential highlight)
            #   object_colors  -> NSC object draw color hex (shaded view; None -> default)
            'objects': self.surface_object,
            'surface_groups': self.surface_surface,
            'object_colors': self.surface_color,
            'mesh':{
                'points': mesh_points,
                'faces': mesh_faces
            },
            'xz_cross': {
                'points': xz_cross_points,
                'lines': xz_cross_lines
            },
            'yz_cross': {
                'points': yz_cross_points,
                'lines': yz_cross_lines
            },
            'rays': json_rays
        }

        if kwargs.get('save_json'):
            json_file = os.path.splitext(self.zos.TheSystem.SystemFile)[0] + '.json'
            with open(json_file, 'w') as file:
                # geometry is stored as ndarrays; convert them for the JSON dump
                json.dump(data, file, default=lambda o: o.tolist() if isinstance(o, np.ndarray) else o)
        
        return data
        

        pass



if __name__ == '__main__':

    # connect to OpticStudio
    zos = Connect()

    # load the double gauss sample file
    zos.TheSystem.LoadFile(os.path.join(os.path.sep, zos.TheApplication.SamplesDir, r'Sequential\Objectives\Double Gauss 28 degree field.zmx'), False)


    this_dir = os.path.dirname(__file__)

    # run the layout
    layout = Layout(
        zos,
        screenshot = False,
        filename = os.path.join(this_dir, 'layout.png'),
        show_orientation = True,
        layout='cross',
        xbars = False,
        color_surfaces = [4, 5],
        settings_first = False, 
        # last_surface = -1,
        field = 'all', 
        wave = 'all',
        number_of_rays = 7,
        pattern = 'xyfan',
        title=None,
        logo=os.path.join(this_dir, 'zemax.jpg'),
        skip_plot = False)
