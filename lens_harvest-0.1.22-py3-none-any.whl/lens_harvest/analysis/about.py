# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect

from datetime import datetime, timezone
from pathlib import Path


import math

class About(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()

        # helper variable for copy & paste code from another file
        self.TheSystem = self.zos.TheSystem.CopySystem()

        # convert to millimeters so things like EFFL and TOTR are consisten
        tool = self.TheSystem.Tools.OpenScale()
        tool.ScaleByUnits = True
        tool.ScaleToUnit = self.zos.ZOSAPI.Tools.General.ScaleToUnits.Millimeters
        tool.RunAndWaitForCompletion()
        tool.Close()


        self.ZOSAPI = self.zos.ZOSAPI


        self.maximum_angle_x = None
        self.maximum_angle_y = None
        self.radial_angle = None
    def GetGeneralInfo(self):
        '''
        Returns general non-optics information about the currently loaded system
        '''
        this_output = {}
        # general information

        this_output['title'] = self.TheSystem.SystemData.TitleNotes.Title.strip()
        this_output['notes'] = self.TheSystem.SystemData.TitleNotes.Notes.strip()
        this_output['author'] = self.TheSystem.SystemData.TitleNotes.Author.strip()

        # this is the only place where we should be using `self.zos.TheSystem` rather than `self.TheSystem`
        this_output['units'] = str(self.zos.TheSystem.SystemData.Units.LensUnits)
        this_output['afocalmode'] = self.TheSystem.SystemData.Aperture.AFocalImageSpace
        this_output['telecentric'] = self.TheSystem.SystemData.Aperture.TelecentricObjectSpace
        this_output['rayaiming'] = str(self.TheSystem.SystemData.RayAiming.RayAiming)
        this_output['stopsurface'] = self.TheSystem.LDE.StopSurface
        this_output['temperature'] = self.TheSystem.SystemData.Environment.Temperature
        this_output['pressure'] = self.TheSystem.SystemData.Environment.Pressure
        this_output['referenceopd'] = str(self.TheSystem.SystemData.Advanced.ReferenceOPD)
        catalogs = list(self.TheSystem.SystemData.MaterialCatalogs.GetCatalogsInUse())
        this_output['catalogs'] = [x for x in catalogs if x]

        return this_output

    def GetWavelengthInfo(self) -> dict:
        '''
        Returns information about the wavelength range, number of wavelengths,
            and primary wavelength
        '''
        this_output = {}
        
        # wavelength information
        wave_min = None
        wave_max = None
        wave_prim_float = None
        wave_prim_int = None
        all_waves = []

        for i in range(1, self.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
            this_wave = self.TheSystem.SystemData.Wavelengths.GetWavelength(i)

            if wave_min is None or this_wave.Wavelength < wave_min:
                wave_min = this_wave.Wavelength
            if wave_max is None or this_wave.Wavelength > wave_max:
                wave_max = this_wave.Wavelength
            if this_wave.IsPrimary:
                wave_prim_float = this_wave.Wavelength
                wave_prim_int = i
            
            # add the complete mapping to the `about` section
            all_waves.append({'number': i, 'value': this_wave.Wavelength})
        
        
        
        

        this_output.update({'number_of_wavelengths': self.TheSystem.SystemData.Wavelengths.NumberOfWavelengths})
        this_output.update({'mapping': all_waves})
        this_output.update({'minimum_wavelength': wave_min})
        this_output.update({'maximum_wavelength': wave_max})
        this_output.update({'primary_wavelength': wave_prim_float})
        this_output.update({'primary_index': wave_prim_int})



        return this_output

    def GetPWAV(self):
        '''
        Determines the primary wavelength of the currently loaded optical system
        '''
        for i in range(1, self.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
            if self.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                return i
        return None
    
    def GetFieldInfo(self) -> dict:
        '''
        Returns information about the fields range, number of fields,
            and maximum object space angle
        '''
        this_output = {}
        
        # field information
        field_min = {'x': 9e9, 'y': 9e9, 'w': 1, 'x_num': None, 'y_num': None}
        field_max = {'x': 0, 'y': 0, 'w': 1, 'x_num': None, 'y_num': None}

        field_normalization = self.TheSystem.SystemData.Fields.Normalization
        for i in range(1, self.TheSystem.SystemData.Fields.NumberOfFields + 1):
            this_field = self.TheSystem.SystemData.Fields.GetField(i)
            fx = this_field.X
            fy = this_field.Y

            if field_normalization == self.ZOSAPI.SystemData.FieldNormalizationType.Rectangular:
                fxa = abs(fx)
                fya = abs(fy)

                if fxa < abs(field_min['x']):
                    field_min['x'] = fx
                    field_min['x_num'] = i
                if fya < abs(field_min['y']):
                    field_min['y'] = fy
                    field_min['y_num'] = i
                if fxa > abs(field_max['x']):
                    field_max['x'] = fx
                    field_max['x_num'] = i
                if fya > abs(field_max['y']):
                    field_max['y'] = fy
                    field_max['y_num'] = i
                
            elif field_normalization == self.ZOSAPI.SystemData.FieldNormalizationType.Radial:
                r = math.sqrt(fx*fx + fy*fy)
                r_min = math.sqrt(field_min['x']**2 + field_min['y']**2)
                r_max = math.sqrt(field_max['x']**2 + field_max['y']**2)
                
                if r < r_min:
                    field_min = {'x': fx, 'y': fy, 'x_num': i, 'y_num': i}
                if r > r_max:
                    field_max = {'x': fx, 'y': fy, 'x_num': i, 'y_num': i}
        
        this_output.update({'field_type': str(self.TheSystem.SystemData.Fields.GetFieldType())})
        this_output.update({'number_of_fields': self.TheSystem.SystemData.Fields.NumberOfFields})
        this_output.update({'normalization': str(self.TheSystem.SystemData.Fields.Normalization)})
        this_output.update({'field_min': field_min})
        this_output.update({'field_max': field_max})

        # scalar radial field of view, used by the "Field of View" search filter
        self.radial_angle = math.sqrt(field_max['x']**2 + field_max['y']**2)
        this_output.update({'radial_angle': self.radial_angle})

        return this_output
    def GetPrescriptionInfo(self) -> dict:
        '''
        Returns first-order prescription data
        '''
        this_output = {}
        
        pwav = self.GetPWAV()
        nsur = self.TheSystem.LDE.NumberOfSurfaces - 1

        # basic first order prescription data 
        this_output.update({'EPDI': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.EPDI, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'ENPP': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.ENPP, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'EXPD': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.EXPD, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'EXPP': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.EXPP, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'EFFL': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.EFFL, 0, pwav, 0, 0, 0, 0, 0, 0)})
        this_output.update({'LINV': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.LINV, 0, pwav, 0, 0, 0, 0, 0, 0)})
        this_output.update({'TOTR': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.TOTR, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'WFNO': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.WFNO, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'CODA': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.CODA, nsur, pwav, 1, 0, 0, 0, 0, 0)})
        this_output.update({'OBSN': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.OBSN, 0, 0, 0, 0, 0, 0, 0, 0)})
        this_output.update({'ISNA': self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.ISNA, 0, 0, 0, 0, 0, 0, 0, 0)})


        # get the back working distance.  This is a little tricky because most camera designs include the IRCF for aberration 
        # modeling but this is typically part of the sensor module, not the camera module
        
        
        
        image_index = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, self.TheSystem.LDE.NumberOfSurfaces - 1, 1, 0, 0, 0, 0, 0, 0)
        backworkingdistance = 0
        for i in range(self.TheSystem.LDE.NumberOfSurfaces - 1, 0, -1):
            surf = self.TheSystem.LDE.GetSurfaceAt(i)
            surf_index = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, i, 1, 0, 0, 0, 0, 0, 0)
            if image_index != surf_index:
                # we have changed refractive index...let's check if we have power at the surface
                sp1 = self.TheSystem.LDE.GetSurfaceAt(i + 1)
                if surf.Radius == float('inf') and sp1.Radius == float('inf'):
                    continue
                
                # we have the last powered surface...let's get the physical path distance of the gut ray (not perfect but consistent)
                #   we could use GLCZ but this won't work for folded systems.  
                #   this fails if we have a phase surface or UDS in image space
                if False:
                    # this doesn't work for afocal systems with a dummy surface (like C_001a.zmx)
                    for j in range(i + 1, self.TheSystem.LDE.NumberOfSurfaces - 1):
                        plen = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.PLEN, j, j + 1, 0, 0, 0, 0, 0, 0)
                        indx = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, j, pwav, 0, 0, 0, 0, 0, 0)
                        backworkingdistance += plen / indx
                else:
                    glcz1 = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.GLCZ, i + 1, 0, 0, 0, 0, 0, 0, 0)
                    glcz2 = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.GLCZ, self.TheSystem.LDE.NumberOfSurfaces - 1, 0, 0, 0, 0, 0, 0, 0)
                    backworkingdistance = glcz2 - glcz1

                break
        this_output.update({'back_workingdistance': backworkingdistance})

        return this_output
    def GetSystemInfo(self) -> dict:
        '''
        Returns information about the wavelength range, number of wavelengths,
            and primary wavelength
        '''
        this_output = {}

        # get the number of glasses & mirrors in the system
        glasses = 0     # material surrounded by air
        mirrors = 0     # MIRROR in the material surrounded by air
        prisms  = 0     # MIRROR surrounded by glass
        material = set()

        # M_TODO: we should check for double pass systems
        for i in range(1, self.TheSystem.LDE.NumberOfSurfaces - 1):

            sm1 = self.TheSystem.LDE.GetSurfaceAt(i - 1)
            surf = self.TheSystem.LDE.GetSurfaceAt(i)
            sp1 = self.TheSystem.LDE.GetSurfaceAt(i + 1)

            im1 = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, i - 1, 1, 0, 0, 0, 0, 0, 0)
            ie1 = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, i, 1, 0, 0, 0, 0, 0, 0)
            ip1 = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, i + 1, 1, 0, 0, 0, 0, 0, 0)

            if surf.Material == 'MIRROR':
                # check for prims vs mirror
                if im1 == 1:
                    mirrors += 1
                else:
                    # this should also check to see if the surface after is glass but if it isn't then the model is incorrect anyways
                    prisms += 1
            elif abs(ie1) > 1.0:
                glasses += 1
                material.add(self.TheSystem.LDE.GetSurfaceAt(i).Material)

        # get object distance including any dummy surfaces in from of the first element
        object_distance = float(self.TheSystem.LDE.GetSurfaceAt(0).Thickness)
        object_index = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, 0, 1, 0, 0, 0, 0, 0, 0)
        for i in range(1, self.TheSystem.LDE.NumberOfSurfaces):
            indx = self.TheSystem.MFE.GetOperandValue(self.ZOSAPI.Editors.MFE.MeritOperandType.INDX, i, 1, 0, 0, 0, 0, 0, 0)

            if object_index == indx:
                object_distance += float(self.TheSystem.LDE.GetSurfaceAt(i).Thickness)
            else:
                break
        
        material = list(material)
        material.sort()
        this_output.update({'materials': {'glasses': glasses, 'mirrors': mirrors, 'prisms': prisms, 'glass_types': material}})
        this_output.update({'object_distance': object_distance})
        this_output.update({'number_of_surfaces': self.TheSystem.LDE.NumberOfSurfaces})

        return this_output
    
    def run(self):
        '''
        Returns common data about individual settings from the file.

        Some data is simply parsed from the ZMX but some require OpticStudio calculation
        '''

        res = {}

        res.update({'system_name': Path(self.zos.TheSystem.SystemFile).name})
        res.update({'title': self.zos.TheSystem.SystemName})
        res.update({'timestamp': datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S %Z")})
        res.update({'version': f'{self.zos.TheApplication.ZOSMajorVersion}.{self.zos.TheApplication.ZOSMinorVersion}.{self.zos.TheApplication.ZOSSPVersion}'})

        data = {}

        for key, val in self.GetGeneralInfo().items():
            data.update({key: val})
        
        for key, val in self.GetWavelengthInfo().items():
            data.update({key: val})

        for key, val in self.GetFieldInfo().items():
            data.update({key: val})
        
        for key, val in self.GetPrescriptionInfo().items():
            data.update({key: val})
        
        for key, val in self.GetSystemInfo().items():
            data.update({key: val})

        res.update({'data': data})
        return res
