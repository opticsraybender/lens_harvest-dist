# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class RelativeIllumination(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            wavelength=1,
            scan_type='plus_y',
            ray_density=10,
            field_density=20,
            use_polarization=False,
            log_scale=False,
            remove_vignetting_factors=True
            ):
        '''
        Runs a Relative Illumination analysis
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.RelativeIllumination)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.ScanType = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.ScanTypes, scan_type, 'plus_y')[1]
        win_settings.RayDensity = max(min(int(ray_density), 50), 5)
        win_settings.FieldDensity = max(min(int(field_density), 100), 5)
        win_settings.UsePolarization = use_polarization
        win_settings.LogScale = log_scale
        win_settings.RemoveVignettingFactors = remove_vignetting_factors

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'scan_type': str(win_settings.ScanType),
            'ray_density': win_settings.RayDensity,
            'field_density': win_settings.FieldDensity,
            'use_polarization': win_settings.UsePolarization,
            'log_scale': win_settings.LogScale,
            'remove_vignetting_factors': win_settings.RemoveVignettingFactors
        }

        data = []
        for series in list(res.DataSeries):
            this_grid = self.zos.get_series(series)
            data.append(this_grid)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    mtf = RelativeIllumination()
    res = mtf.run()

    print(f'settings : {res['settings']}')
    print(f'header   : {res['header']}')
