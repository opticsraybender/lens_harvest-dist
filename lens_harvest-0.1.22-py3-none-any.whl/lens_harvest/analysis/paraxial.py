# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect

import json

class Paraxial(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
        
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav
    
    def get_efl(self, wavelength = 0):
        if wavelength < 1 or wavelength > self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths:
            wave = self.get_pwav()
        else:
            wave = wavelength
        
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.EFFL, 0, wave, 0, 0, 0, 0, 0, 0)
        
    def get_bfl(self):
        # bfl requires the paraxial focal distance
        
        copy_system = self.zos.TheSystem.CopySystem()
        # set the paraxial focus
        surf = copy_system.LDE.GetSurfaceAt(copy_system.LDE.NumberOfSurfaces - 2)
        solver = surf.ThicknessCell.CreateSolveType(self.zos.ZOSAPI.Editors.SolveType.MarginalRayHeight)
        solver._S_MarginalRayHeight.Height = 0.0
        solver._S_MarginalRayHeight.PupilZone = 0.0
        surf.ThicknessCell.SetSolveData(solver)
        
        # now calculate the 
        bfl = 0
        for i in range(copy_system.LDE.NumberOfSurfaces - 2, 0, -1):
            surf = copy_system.LDE.GetSurfaceAt(i)
            # there is no universal way of calculating this.  Need to check for material string length, MIRROR, and refractive index
            if len(str(surf.Material)) == 0:
                bfl += surf.Thickness
            else:
                break
        
        copy_system.Close(False)
        
        return bfl
    
    def _card(self, wavelength, data):
        if wavelength < 1 or wavelength > self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths:
            wave = self.get_pwav()
        else:
            wave = wavelength
        
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CARD, 1, self.zos.TheSystem.LDE.NumberOfSurfaces - 1, wave, 0, data, 0, 0, 0)
    def get_ffl(self, wavelength = 0):
        return self._card(wavelength, 0)
    def get_epp(self):
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.ENPP, 0, 0, 0, 0, 0, 0, 0, 0)
    def get_epd(self):
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.EPDI, 0, 0, 0, 0, 0, 0, 0, 0)
    def get_xpp(self):
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.EXPP, 0, 0, 0, 0, 0, 0, 0, 0)
    def get_xpd(self):
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.EXPD, 0, 0, 0, 0, 0, 0, 0, 0)
    def get_fno(self, f_type = 0):
        # common f-numbers are: ['WFNO', 'ISFN', 'EFNO']
        if f_type == 1:
            return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.ISFN, 0, 0, 0, 0, 0, 0, 0, 0)
        else:
            return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.WFNO, 0, 0, 0, 0, 0, 0, 0, 0)
    def get_na(self):
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.ISNA, 0, 0, 0, 0, 0, 0, 0, 0)
    def get_mag(self):
        return self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PMAG, 0, 0, 0, 0, 0, 0, 0, 0)
    def run(self, **kwargs):
        '''
        runs the paraxial data and returns the dictionary
        '''
        
        settings = {
            'window': 'Paraxial'
        }
        
        efl = self.get_efl()
        bfl = self.get_bfl()
        ffl = self.get_ffl()
        epp = self.get_epp()
        epd = self.get_epd()
        xpp = self.get_xpp()
        xpd = self.get_xpd()
        fno = self.get_fno()
        na  = self.get_na()
        mag = self.get_mag()
        
        data = []
        
        data.append({'effective_focal_length': efl})
        data.append({'back_focal_length': bfl})
        data.append({'front_focal_length': ffl})
        data.append({'entrance_pupil_position': epp})
        data.append({'entrance_pupil_diameter': epd})
        data.append({'exit_pupil_position': xpp})
        data.append({'exit_pupil_diameter': xpd})
        data.append({'f_number': fno})
        data.append({'numerical_aperture': na})
        data.append({'magnification': mag})

        # data = {
        #     'effective_focal_length': efl,
        #     'back_focal_length': bfl,
        #     'front_focal_length': ffl,
        #     'entrance_pupil_position': epp,
        #     'entrance_pupil_diameter': epd,
        #     'exit_pupil_position': xpp,
        #     'exit_pupil_diameter': xpd,
        #     'f_number': fno,
        #     'numerical_aperture': na,
        #     'magnification': mag
        # }
        
        
        return {'type': 'table', 'settings': settings, 'header': [], 'data': [json.dumps(data)]}

if __name__ == '__main__':
    
    paraxial = Paraxial()    
    res = paraxial.run()
    
    print(res)
    