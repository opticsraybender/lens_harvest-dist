# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class Y_YBar(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
    
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav

    def run(self, 
            wavelength=0, 
            first_surface=1,
            last_surface=0
            ):
        '''
        Runs a Y-YBar analysis

        Use `last_surface=0` for the Image surface
        '''
        
        # validate the settings
        wave = self.get_pwav() if wavelength == 0 else wavelength
        fs = first_surface
        ls = last_surface + 1 if last_surface > 0 else self.zos.TheSystem.LDE.NumberOfSurfaces + 1
        
        # get the operand values
        y = []
        ybar = []
        for surf in range(fs, ls):
            y.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARY, surf, wave, 0, 1, 0, 0, 0, 0))
            ybar.append(self.zos.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.PARY, surf, wave, 0, 0, 0, 1, 0, 0))

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': 'YYBar',
            'wavelength': wave,
            'first_surface': first_surface,
            'last_surface': last_surface
        }

        data = [{
                'description': 'Listing of Y-Ybar Data',
                'xlabel': 'Y-Bar',
                'xdata': y,
                'series_labels': [],
                'num_series': 1,
                'ydata': ybar
            }]
        
        header = [
            f'First Surface : {fs}',
            f'Last Surface  : {ls}',
            f'Wavelength    : {self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(wave).Wavelength}'
            ]
        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    yyb = Y_YBar()
    res = yyb.run(wavelength=1)

    print(f'settings : {res['settings']}')
    print(f'header   : {res['header']}')

    print(res['data'])
    