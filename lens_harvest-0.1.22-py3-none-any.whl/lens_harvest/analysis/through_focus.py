# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class ThroughFocus(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self,
            wavelength=1,
            ray_density=3,
            focus_density=15,
            data='strehlratio',
            refer_to='centroid',
            method='gaussquad',
            show_diffraction_limit=False,
            use_polarization=False,
            minimum_focus=-0.01,
            maximum_focus=0.01
            ):
        '''
        Runs a Relative Illumination analysis
        '''

        # fix misspelled enum
        if data.lower() == 'strehlratio' and Enum.IsDefined(self.zos.ZOSAPI.Analysis.Settings.RMS.RMSField.DataType, 'StrehlRation'):
            data = 'strehlration'
        # make sure they don't remove `strehlration` in future versions
        if data.lower() == 'strehlration' and not Enum.IsDefined(self.zos.ZOSAPI.Analysis.Settings.RMS.RMSField.DataType, 'StrehlRation'):
            data = 'strehlratio'

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.RMSFocus)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        # win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.RayDensity = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.RayDensities, f'RayDens_{max(min(int(ray_density), 20), 1)}', 'RayDens_3')[1] 
        # note that Zemax overloaded the `enum` so there are 2 strings (`RayDens_3` and `RayDens_128x128` that map to 3)
        win_settings.FocusDensity = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.FocusDensities, f'FocusDens_{max(min(round(focus_density / 5) * 5, 100), 5)}', 'FocusDens_15')[1] 
        win_settings.Data = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.RMSField.DataType, data, 'wavefront')[1]
        win_settings.ReferTo = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.ReferTo, refer_to, 'centroid')[1]
        win_settings.Method = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.RMS.Method, method, 'gaussquad')[1]
        win_settings.ShowDiffractionLimit = show_diffraction_limit
        win_settings.UsePolarization = use_polarization
        win_settings.MinimumFocus = minimum_focus
        win_settings.MaximumFocus = maximum_focus

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'ray_density': str(win_settings.RayDensity),
            'focus_density': str(win_settings.FocusDensity),
            'data': str(win_settings.Data),
            'refer_to': str(win_settings.ReferTo),
            'method': str(win_settings.Method),
            'show_diffraction_limit': win_settings.ShowDiffractionLimit,
            'use_polarization': win_settings.UsePolarization,
            'minimum_focus': win_settings.MinimumFocus,
            'maximum_focus': win_settings.MaximumFocus
        }

        data = []
        for series in list(res.DataSeries):
            this_series = self.zos.get_series(series)
            data.append(this_series)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    tf = ThroughFocus()
    res = tf.run()

    print(f'settings : {res['settings']}')
    print(f'header   : {res['header']}')
