# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum


class NCE(object):
    '''
    Read-only snapshot of the Non-Sequential Component Editor, the NSC analog of
    the LDE class. Mirrors lde.py so the viewer can treat it the same way.

    Unlike the LDE, NCE columns are ragged: the first 10 are common to every
    object, but the remaining parameter columns (and their header names) change
    per object type. We therefore grab the common columns from direct object
    properties and resolve the type-specific columns by matching the parameter
    cell headers one-by-one.
    '''

    # candidate header names per object category (matched case-insensitively).
    # a list allows for headers that differ by aperture/mode, e.g. "Clear 1" vs "Edge 1".
    SOURCE_COLUMNS = [
        ('layout_rays',   ['# Layout Rays']),
        ('analysis_rays', ['# Analysis Rays']),
        ('power_watts',   ['Power(Watts)', 'Power (Watts)']),
    ]
    DETECTOR_COLUMNS = [
        ('x_half_width', ['X Half Width']),
        ('y_half_width', ['Y Half Width']),
        ('x_pixels',     ['# X Pixels']),
        ('y_pixels',     ['# Y Pixels']),
    ]
    OTHER_COLUMNS = [
        ('radius_1',     ['Radius 1']),
        ('clear_edge_1', ['Clear 1', 'Edge 1']),     # whichever the object exposes
        ('thickness',    ['Thickness']),
        ('radius_2',     ['Radius 2']),
        ('clear_edge_2', ['Clear 2', 'Edge 2']),
    ]

    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()

    def _param_map(self, obj, max_params=300):
        '''
        Build a {header(lowercased): cell} map for an object's parameter columns
        so type-specific values can be looked up by name.
        '''
        ObjectColumn = self.zos.ZOSAPI.Editors.NCE.ObjectColumn

        out = {}
        for k in range(1, max_params + 1):
            try:
                col = Enum.Parse(ObjectColumn, f'Par{k}')
            except Exception:
                break                       # ran past the last defined ParN enum
            cell = obj.GetObjectCell(col)
            if cell is None:
                continue
            header = str(cell.Header).strip()
            if header:
                out[header.lower()] = cell
        return out

    def _pick(self, pmap, names):
        '''return the first parameter cell whose header matches one of `names`'''
        for n in names:
            cell = pmap.get(n.lower())
            if cell is not None:
                return cell
        return None

    def _num(self, cell):
        return None if cell is None else cell.DoubleValue

    def _int(self, cell):
        return None if cell is None else int(cell.IntegerValue)

    def _row_color(self, type_str, material):
        '''default NCE row colors by object category / material'''
        if type_str == 'NullObject':
            return None
        if type_str.startswith('Source'):
            return '#e6e620'
        if type_str.startswith('Detector'):
            return '#dcc3b9'
        if material == 'MIRROR':
            return '#d7d7d7'
        if material == 'ABSORB':
            return '#b9b9b9'
        if material:                        # any non-empty glass catalog material
            return '#d2d2ff'
        return None

    def run(self):
        '''
        Places the basics from the NCE into a dataframe for simple read-only access
        '''
        nce = self.zos.TheSystem.NCE

        all_rows = []
        for i in range(1, nce.NumberOfObjects + 1):     # NCE is 1-based, like the MFE
            obj = nce.GetObjectAt(i)

            type_str = str(obj.Type)
            material = obj.Material

            # --- first 10 columns: common to every object ---
            row = {
                'object': i,
                'type': type_str,
                'comment': obj.Comment,
                'ref_object': obj.RefObject,
                'inside_of': obj.InsideOf,
                'x_position': obj.XPosition,
                'y_position': obj.YPosition,
                'z_position': obj.ZPosition,
                'tilt_about_x': obj.TiltAboutX,
                'tilt_about_y': obj.TiltAboutY,
                'tilt_about_z': obj.TiltAboutZ,
            }

            # --- type-specific columns: resolved by parameter-cell header ---
            pmap = self._param_map(obj)

            if type_str.startswith('Source'):
                for key, names in self.SOURCE_COLUMNS:
                    cell = self._pick(pmap, names)
                    # counts are integers; power is a double
                    row[key] = self._int(cell) if key.endswith('rays') else self._num(cell)
            elif type_str.startswith('Detector'):
                for key, names in self.DETECTOR_COLUMNS:
                    cell = self._pick(pmap, names)
                    row[key] = self._int(cell) if key.endswith('pixels') else self._num(cell)
            else:
                row['material'] = material
                for key, names in self.OTHER_COLUMNS:
                    row[key] = self._num(self._pick(pmap, names))

            # --- default row color ---
            row['color'] = self._row_color(type_str, material)

            all_rows.append(row)

        settings = {
            'window': 'NCE'
        }

        header = []
        data = [pd.DataFrame(all_rows).to_json(orient='records'), ]

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    pass
