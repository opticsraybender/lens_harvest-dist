# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import json
import numpy as np
import pandas as pd

import clr
from System import Enum

from .spot_diagram import SpotDiagram

class SpotDiagramThroughFocus(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
    
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav

    def run(self, 
            field=0, 
            surface=0,
            wavelength=0,
            pattern='hexapolar',
            refer_to='chiefray',
            ray_density=6,
            show_airy_disk=False,
            focus_delta_um=50,
            # focus_steps=10,
            config_number = 1
            ):
        '''
        Inherits the Spot Diagram and performss a 5 step routine

        Use `last_surface=0` for the Image surface
        '''

        focii = [-2 * focus_delta_um / 1000, -1 * focus_delta_um / 1000, 0, 1 * focus_delta_um / 1000, 2 * focus_delta_um / 1000 ]
        
        # create copy of system & then modify the last thickness to mimic through focus
        copy_system = self.zos.TheSystem.CopySystem()
        copy_system.LDE.InsertNewSurfaceAt(copy_system.LDE.NumberOfSurfaces)

        sd = None

        header = []
        data = []
        for focus in focii:
            
            # defocus the system
            copy_system.LDE.GetSurfaceAt(copy_system.LDE.NumberOfSurfaces - 2).Thickness = focus

            # initialize the SpotDiagram class so it accepts the new defocus
            sd = SpotDiagram(copy_system)

            res = sd.run(
                field=field,
                surface=surface,
                wavelength=wavelength,
                pattern=pattern,
                refer_to=refer_to,
                ray_density=ray_density,
                show_airy_disk=show_airy_disk,
                config_number=config_number
            )

            # update the header with the delta focus
            # h = json.loads(res['header'][-1])
            # h.update({'delta_focus': focus})
            # header.append(json.dumps(h))
            # res['header'] = [f'delta_focus : {focus}'] + res['header']
            header.append(f'delta_focus : {focus}')
            header.extend(res['header'])

            # append the dataframe
            data.append(res['data'])


            # copy_system.Close(False)

            # # delete the SpotDiagram so we close the extra system
            # del sd

        if sd:
            del sd

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': 'SpotDiagramThroughFocus',
            'field': field,
            'surface': surface,
            'wavelength': wavelength,
            'pattern': pattern,
            'refer_to': refer_to,
            'ray_density': ray_density,
            'show_airy_disk': show_airy_disk,
            'focus_delta_um': focus_delta_um
        }
        
        
        # delete system copy
        if copy_system:
            copy_system.Close(False)
        return {'type': 'scatter', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    tf = SpotDiagramThroughFocus()
    res = tf.run(wavelength=1)

    print(f'settings : {res['settings']}')
    import pprint
    pprint.pprint(f'header   : {res['header']}')

    # print(res['data'])
    