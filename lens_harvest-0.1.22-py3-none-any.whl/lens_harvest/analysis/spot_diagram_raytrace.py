# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# commmon imports across all files
from ..connect import Connect
import numpy as np
import pandas as pd

# enum parsing for `ZOSAPI` namespace
import clr
from System import Enum, Int32, Double

# plotting
import matplotlib.pyplot as plt

class SpotDiagramRayTrace(object):
    '''
    A "first-class" Standard Spot Diagram built directly from the `IBatchRayTrace`
    interface (`SingleRayNormUnpol` is used by `footprint_diagram.py`; this uses the
    much faster batch path `CreateNormUnpol` / `AddRay` / `ReadNextResult`).

    The native ZOS-API does not expose ray-by-ray spot data, so the standard
    `spot_diagram.py` infers the points from REAX/REAY merit operands written to a
    `.mf` file.  This class instead traces the pupil grid itself, so the returned
    coordinates are the genuine ray intercepts rather than a merit-function
    interpretation.

    Every setting on the `IAS_Spot` interface
    (`ZOSAPI.Analysis.Settings.Spot.IAS_Spot`) is mirrored as a `run()` argument:

        IAS_Spot property      ->  run() argument        notes
        ---------------------------------------------------------------------------
        Field                  ->  field                 0 = all fields
        Surface                ->  surface               0 = image surface
        Wavelength             ->  wavelength            0 = all wavelengths
        Pattern                ->  pattern               'square'|'hexapolar'|'dithered'
        ReferTo                ->  refer_to              'chiefray'|'centroid'|'middle'|'vertex'
        ShowScale              ->  show_scale            'scalebar'|'box'|'cross'|'circle'
        ColorRaysBy            ->  color_rays_by         'fields'|'waves'|'config'|'wavelength'
        RayDensity             ->  ray_density           grid/ring density
        Configuration          ->  configuration         1-based; 0 = current
        DirectionCosines       ->  direction_cosines
        UseSymbols             ->  use_symbols
        UsePolarization        ->  use_polarization      (not traced; see notes)
        ScatterRays            ->  scatter_rays          (not traced; see notes)
        ShowAiryDisk           ->  show_airy_disk
        IgnoreLateralColor     ->  ignore_lateral_color
        PlotScale              ->  plot_scale
        DeltaFocus             ->  delta_focus           through-focus shift (lens units)
        Exaggerate             ->  exaggerate

    Settings that change the data Zemax computes but are NOT reproduced by an
    unpolarized geometric trace (`use_polarization`, `scatter_rays`) are accepted,
    recorded in the returned `settings`, and otherwise ignored, exactly as
    `spot_diagram.py` documents for its own un-implemented settings.
    '''

    # IAS_Spot enum value -> ordinal (ZOS-API ZOSAPI.Analysis.Settings.Spot.*).
    # Kept as plain strings so callers never need to import the ZOSAPI namespace.
    PATTERNS = ('square', 'hexapolar', 'dithered')
    REFERENCES = ('chiefray', 'centroid', 'middle', 'vertex')
    SHOW_SCALES = ('scalebar', 'box', 'cross', 'circle')
    COLOR_RAYS_BY = ('fields', 'waves', 'config', 'wavelength')

    def __init__(self, mod_sys=None):
        # connect to OpticStudio
        self.zos = Connect()

        # like SpotDiagram, run against a copy so a DeltaFocus / multi-config sweep
        # never mutates the user's primary system
        if mod_sys:
            self.TheSystem = mod_sys
        else:
            self.TheSystem = self.zos.TheSystem.CopySystem()

        # constants for the system
        self.pwav = None

    def __del__(self):
        # mirror SpotDiagram: leave the copied system alone here; the caller that
        # owns the copy (e.g. a through-focus loop) is responsible for closing it
        pass

    def get_pwav(self):
        '''gets the primary wavelength number'''
        if self.pwav is None:
            for i in range(1, self.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav

    def get_normalized_field_coordinates(self, field_number=1):
        if field_number < 1:
            field_number = 1
        if field_number > self.TheSystem.SystemData.Fields.NumberOfFields:
            field_number = self.TheSystem.SystemData.Fields.NumberOfFields

        # determine maximum field values
        mx = 0
        my = 0
        for f in range(1, self.TheSystem.SystemData.Fields.NumberOfFields + 1):
            field = self.TheSystem.SystemData.Fields.GetField(f)
            if field.X > mx: mx = field.X
            if field.Y > my: my = field.Y

        # determine if radial or rectangular normalization
        if self.TheSystem.SystemData.Fields.Normalization == self.zos.ZOSAPI.SystemData.FieldNormalizationType.Radial:
            my = (mx*mx + my*my)**0.5
            mx = my

        # get the field coordinates & normalized values
        field = self.TheSystem.SystemData.Fields.GetField(field_number)
        hx = 0.0 if abs(mx) < 1e-10 else field.X / mx
        hy = 0.0 if abs(my) < 1e-10 else field.Y / my

        return (hx, hy)

    # ---- pupil sampling patterns (mirror IAS_Spot.Pattern) -------------------
    def _get_hexapolar(self, ray_density):
        # identical ring layout to SpotDiagram._get_hexapolar (chief ray + rings)
        px = [
            (r / ray_density) * np.cos(np.deg2rad(60 - (60 / r) * a))
            for r in range(1, ray_density + 1)
            for a in range(6 * r)
        ]
        py = [
            (r / ray_density) * np.sin(np.deg2rad(60 - (60 / r) * a))
            for r in range(1, ray_density + 1)
            for a in range(6 * r)
        ]
        px.insert(0, 0)
        py.insert(0, 0)
        return (px, py)

    def _get_square(self, ray_density):
        step = 1 / ray_density
        coords = np.arange(-1.0, 1.0 + step, step)
        px = [x for x in coords for y in coords if x**2 + y**2 <= 1]
        py = [y for x in coords for y in coords if x**2 + y**2 <= 1]
        return (px, py)

    def _get_dithered(self, ray_density):
        # deterministic dither: a square grid jittered by a fixed (seeded) offset so
        # results are reproducible run-to-run (matches the SpotDiagram intent that a
        # dithered pattern not be truly random for optimizer stability)
        px, py = self._get_square(ray_density)
        rng = np.random.default_rng(12345)
        d = (1.0 / ray_density) * 0.5
        out_px = []
        out_py = []
        for x, y in zip(px, py):
            jx = x + d * (2.0 * rng.random() - 1.0)
            jy = y + d * (2.0 * rng.random() - 1.0)
            if jx*jx + jy*jy <= 1.0:
                out_px.append(jx)
                out_py.append(jy)
        return (out_px, out_py)

    def _get_pupil(self, pattern, ray_density):
        p = pattern.lower()
        if p == 'hexapolar':
            return self._get_hexapolar(ray_density)
        elif p == 'dithered':
            return self._get_dithered(ray_density)
        else:   # 'square' and default
            return self._get_square(ray_density)

    # ---- reference point (mirror IAS_Spot.ReferTo) --------------------------
    def _reference_point(self, refer_to, surf, wave, hx, hy, field, pts):
        '''
        Returns the (rx, ry) the spot is measured against.
            - chiefray : real ray at (px,py)=(0,0)
            - centroid : intensity centroid of the traced spot (CENX/CENY)
            - middle   : midpoint of the spot bounding box (computed from `pts`)
            - vertex   : the surface vertex (0, 0)
        `pts` is the Nx2 array of traced (x, y) for THIS field/wave so 'middle' can
        be computed without re-tracing.
        '''
        ref = refer_to.lower()
        if ref == 'vertex':
            return (0.0, 0.0)
        elif ref == 'centroid':
            return (
                self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CENX, surf, wave, field, 0, 5, 0, 0, 0),
                self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.CENY, surf, wave, field, 0, 5, 0, 0, 0)
            )
        elif ref == 'middle':
            if len(pts) == 0:
                return (0.0, 0.0)
            arr = np.asarray(pts)
            return ((arr[:, 0].min() + arr[:, 0].max()) / 2.0,
                    (arr[:, 1].min() + arr[:, 1].max()) / 2.0)
        else:   # 'chiefray' and default
            return (
                self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAX, surf, wave, hx, hy, 0, 0, 0, 0),
                self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, surf, wave, hx, hy, 0, 0, 0, 0)
            )

    def _airy_radius(self, wave, surf):
        '''
        Airy-disk radius (lens units) at the image:  1.22 * lambda * (F/#).
        Wavelengths are stored in micrometers; convert to lens units via the
        system's micron-per-lens-unit scale so the disk overlays the spot.
        '''
        try:
            fno = self.TheSystem.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.WFNO, 0, wave, 0, 0, 0, 0, 0, 0)
            wl_um = self.TheSystem.SystemData.Wavelengths.GetWavelength(wave).Wavelength
            # lens units -> mm scale (millimeters per lens unit); wl is in microns
            mm_per_lu = {
                self.zos.ZOSAPI.SystemData.ZemaxSystemUnits.Millimeters: 1.0,
                self.zos.ZOSAPI.SystemData.ZemaxSystemUnits.Centimeters: 10.0,
                self.zos.ZOSAPI.SystemData.ZemaxSystemUnits.Inches: 25.4,
                self.zos.ZOSAPI.SystemData.ZemaxSystemUnits.Meters: 1000.0,
            }.get(self.TheSystem.SystemData.Units.LensUnits, 1.0)
            # 1.22 * lambda[um] * F/#  -> um, then um -> lens units
            return 1.22 * wl_um * fno / (1000.0 * mm_per_lu)
        except Exception:
            return 0.0

    def _resolve_surface(self, surface):
        # 0 -> image surface (mirrors IAS_Spot.Surface.UseImageSurface)
        if surface == 0:
            return self.TheSystem.LDE.NumberOfSurfaces - 1
        return surface

    def trace_batch(self, tool, pupil, hx, hy, wave, surf):
        '''
        Trace the whole pupil for one (field, wave) in a single batch.
        Returns an Nx2 array of (x, y) image-plane intercepts for the rays that
        passed (ErrorCode == 0 and vignetteCode == 0), preserving ray order.
        '''
        # .NET reference placeholders for the (out ...) parameters; required for pythonnet
        si = Int32(1)
        sd = Double(1.0)

        real = self.zos.ZOSAPI.Tools.RayTrace.RaysType.Real
        # `None` is a Python keyword, so the enumerator can't be reached via dotted
        # attribute access — parse it by name (matches the ZOS-API Python sample)
        opd_none = Enum.Parse(self.zos.ZOSAPI.Tools.RayTrace.OPDMode, 'None')

        px_list, py_list = pupil
        n = len(px_list)

        norm = tool.CreateNormUnpol(n, real, surf)
        norm.ClearData()
        for px, py in zip(px_list, py_list):
            norm.AddRay(Int32(wave), hx, hy, px, py, opd_none)

        # run the batch, then stream the results back
        tool.RunAndWaitForCompletion()
        norm.StartReadingResults()

        coords = []
        # output tuple order: (success, rayNumber, ErrorCode, vignetteCode, x, y, z, l, m, n, l2, m2, n2, opd, intensity)
        out = norm.ReadNextResult(si, si, si, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd)
        while out[0]:
            if out[2] == 0 and out[3] == 0:
                coords.append([out[4], out[5]])
            out = norm.ReadNextResult(si, si, si, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd, sd)

        return np.asarray(coords) if len(coords) else np.empty((0, 2))

    def calculate_summary(self, data):
        '''
        Per (wave, field): RMS and GEO (max) radius in microns, measured against the
        per-row reference point already applied to the stored coordinates.
        '''
        rows = []
        for d in data:
            arr = np.asarray(d['coordinates'])
            if len(arr) == 0:
                rows.append({'wave': d['wave'], 'field': d['field'], 'rms': float('nan'), 'geo': float('nan')})
                continue
            rx, ry = d['reference']
            dx = arr[:, 0] - rx
            dy = arr[:, 1] - ry
            r = np.sqrt(dx*dx + dy*dy)
            rows.append({
                'wave': d['wave'],
                'field': d['field'],
                'rms': float(np.sqrt(np.mean(r*r)) * 1000.0),   # lens units -> microns
                'geo': float(r.max() * 1000.0)
            })
        return pd.DataFrame(rows)

    def run(self,
            field=0,
            surface=0,
            wavelength=0,
            pattern='hexapolar',
            refer_to='chiefray',
            show_scale='scalebar',
            color_rays_by='fields',
            ray_density=6,
            configuration=0,
            direction_cosines=False,
            use_symbols=False,
            use_polarization=False,
            scatter_rays=False,
            show_airy_disk=False,
            ignore_lateral_color=False,
            plot_scale=0.0,
            delta_focus=0.0,
            exaggerate=0.0
            ):
        '''
        Standard Spot Diagram traced ray-by-ray through `IBatchRayTrace`.

        Argument <-> IAS_Spot mapping is documented on the class.  Sentinels match
        the rest of the codebase:
            - field         = 0 -> all fields
            - surface       = 0 -> image surface
            - wavelength    = 0 -> all wavelengths
            - configuration = 0 -> current config (1-based otherwise)

        `delta_focus` (lens units) shifts the image plane like the Through-Focus
        Spot Diagram; it inserts a dummy surface on the copied system before the
        image so the user's system is never modified.

        Not reproduced by an unpolarized geometric trace (recorded, not applied):
            - use_polarization
            - scatter_rays
        '''
        # resolve "all"/"current" sentinels
        surf = self._resolve_surface(surface)
        config = configuration if configuration > 0 else self.TheSystem.MCE.CurrentConfiguration

        # switch the copied system to the requested configuration
        if configuration > 0 and configuration <= self.TheSystem.MCE.NumberOfConfigurations:
            self.TheSystem.MCE.SetCurrentConfiguration(configuration)

        # apply a through-focus shift on the copy (never touches the user's system)
        if abs(delta_focus) > 1e-12:
            self.TheSystem.LDE.InsertNewSurfaceAt(self.TheSystem.LDE.NumberOfSurfaces)
            self.TheSystem.LDE.GetSurfaceAt(self.TheSystem.LDE.NumberOfSurfaces - 2).Thickness = delta_focus
            surf = self.TheSystem.LDE.NumberOfSurfaces - 1

        # clamp the ray density to a sane integer (square/hexapolar both need >= 1)
        ray_density = int(max(ray_density, 1))

        # normalized pupil sampling for the requested pattern
        pupil = self._get_pupil(pattern, ray_density)

        # field & wavelength loop bounds from the sentinels
        fs = field if field > 0 else 1
        fe = field + 1 if field > 0 else self.TheSystem.SystemData.Fields.NumberOfFields + 1
        ws = wavelength if wavelength > 0 else 1
        we = wavelength + 1 if wavelength > 0 else self.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1

        # open the batch ray trace tool once for the whole sweep
        tool = self.TheSystem.Tools.OpenBatchRayTrace()

        data = []
        airy = {}
        for f in range(fs, fe):
            hx, hy = self.get_normalized_field_coordinates(f)
            for w in range(ws, we):
                pts = self.trace_batch(tool, pupil, hx, hy, w, surf)

                # reference point for this field/wave (needs the traced pts for 'middle')
                ref = self._reference_point(refer_to, surf, w, hx, hy, f, pts)

                data.append({
                    'wave': w,
                    'field': f,
                    'reference': [float(ref[0]), float(ref[1])],
                    'coordinates': pts.tolist()
                })

                if show_airy_disk and w not in airy:
                    airy[w] = self._airy_radius(w, surf)

        # always close your tools
        tool.Close()

        # per field/wave RMS & GEO summary
        stats = self.calculate_summary(data)

        # record every IAS_Spot setting so the run is fully reproducible
        settings = {
            'window': 'SpotDiagramRayTrace',
            'field': field,
            'surface': surface,
            'wavelength': wavelength,
            'pattern': pattern,
            'refer_to': refer_to,
            'show_scale': show_scale,
            'color_rays_by': color_rays_by,
            'ray_density': ray_density,
            'configuration': config,
            'direction_cosines': direction_cosines,
            'use_symbols': use_symbols,
            'use_polarization': use_polarization,
            'scatter_rays': scatter_rays,
            'show_airy_disk': show_airy_disk,
            'ignore_lateral_color': ignore_lateral_color,
            'plot_scale': plot_scale,
            'delta_focus': delta_focus,
            'exaggerate': exaggerate
        }

        header = ['wave   field         rms             geo']
        for row in stats.itertuples():
            header.append(f'{row.wave:<6} {row.field:<6} {row.rms:15.8f} {row.geo:15.8f}')

        return {
            'type': 'scatter',
            'settings': settings,
            'header': header,
            'data': {'spots': data, 'airy': airy}
        }

    def plot(self, res):
        colors = ['#0000ff', '#00ff00', '#ff0000', '#bfbf00', '#ff00ff', '#00ffff', '#7f7fff', '#7fff7f']

        spots = res['data']['spots']
        airy = res['data'].get('airy', {})

        # one subplot per field; waves overlaid (referenced coords are centered already)
        fields = sorted({d['field'] for d in spots})
        fig, axes = plt.subplots(len(fields), 1, figsize=(6, 4 * len(fields)))
        if len(fields) == 1:
            axes = [axes]

        for ax, f in zip(axes, fields):
            for d in spots:
                if d['field'] != f:
                    continue
                arr = np.asarray(d['coordinates'])
                if len(arr) == 0:
                    continue
                rx, ry = d['reference']
                ax.scatter(arr[:, 0] - rx, arr[:, 1] - ry, s=2, color=colors[(d['wave'] - 1) % len(colors)])

                # overlay the airy disk if requested
                r = airy.get(d['wave'], airy.get(str(d['wave']), 0.0))
                if r and r > 0:
                    theta = np.linspace(0, 2 * np.pi, 180)
                    ax.plot(r * np.cos(theta), r * np.sin(theta), color='gray', linewidth=0.75, alpha=0.6)

            ax.set_title(f'Field {f}')
            ax.set_aspect('equal')
            ax.set_box_aspect(1)

        plt.show(block=True)


if __name__ == '__main__':

    spt = SpotDiagramRayTrace()
    spt.zos.TheSystem.LoadFile(r"C:\Users\humpf\OneDrive\PDF\Documents\Zemax\Samples\Sequential\Objectives\Double Gauss 28 degree field.zmx", False)

    res = spt.run(field=0, wavelength=0, surface=0, pattern='hexapolar', ray_density=6, refer_to='centroid')

    print(f'settings : {res["settings"]}')
    print('header   :')
    for line in res['header']:
        print('   ', line)

    # spt.plot(res)
