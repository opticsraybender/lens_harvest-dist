# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class Wavefront(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            field=1,
            surface=0,
            wavelength=1,
            rotation='rotate_0',
            sampling='s_64x64',
            polarization='none',
            reference_to_primary=False,
            use_exit_pupil=True,
            remove_tilt=False,
            subaperture_x=0.0,
            subaperture_y=0.0,
            subaperture_r=1.0
            ):
        '''
        Runs a Wavefront Map analysis
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.WavefrontMap)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Field.SetFieldNumber(field)
        win_settings.Surface.UseImageSurface() if surface == 0 else win_settings.Surface.SetSurfaceNumber(surface)
        win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.Rotation = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Rotations, rotation, 'rotation_0')[1]
        win_settings.Sampling = self.zos.try_parse(self.zos.ZOSAPI.Analysis.SampleSizes, sampling, 's_64x64')[1]
        win_settings.Polarization = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Polarizations, polarization, 'none')[1]
        win_settings.ReferenceToPrimary = reference_to_primary
        win_settings.UseExitPupil = use_exit_pupil
        win_settings.RemoveTilt = remove_tilt
        win_settings.Subaperture_X = subaperture_x
        win_settings.Subaperture_Y = subaperture_y
        win_settings.Subaperture_R = subaperture_r
        # make sure we don't have `surface` or `contour` as the default
        # settings.ShowAs = self.zos.ZOSAPI.Analysis.ShowAs.FalseColor

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'field': win_settings.Field.GetFieldNumber(),
            'surface': win_settings.Surface.GetSurfaceNumber(),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'rotation': str(win_settings.Rotation),
            'sampling': str(win_settings.Sampling),
            'polarizaton': str(win_settings.Polarization),
            'reference_to_primary': win_settings.ReferenceToPrimary,
            'use_exit_pupil': win_settings.UseExitPupil,
            'remove_tilt': win_settings.RemoveTilt,
            'subaperture_x': win_settings.Subaperture_X,
            'subaperture_y': win_settings.Subaperture_Y,
            'subaperture_r': win_settings.Subaperture_R
        }

        data = []
        for grid in list(res.DataGrids):
            this_grid = self.zos.get_grid(grid)
            data.append(this_grid)

        # always close the analysis
        win.Close()

        return {'type': 'grid', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    wf = Wavefront()
    res = wf.run()
    
    print(f'settings : {res['settings']}')
    print(f'header   : {res['header']}')