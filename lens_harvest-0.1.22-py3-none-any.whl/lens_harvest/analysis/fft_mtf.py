# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class FftMtf(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None

    def run(self, 
            field=0, 
            surface=0, 
            wavelength=0, 
            mtf_type='modulation', 
            sample_size='s_64x64', 
            show_diffraction_limit=True,
            use_polarization=False,
            maximum_frequency=0.0
            ):
        '''
        Runs a FFT MTF analysiis

        Use `wavelength=0` for all wavelengths
        Use `field=0` for all fields
        Use `surface=0` for the Image surface
        '''

        # open the analysis
        win = self.zos.TheSystem.Analyses.New_Analysis_SettingsFirst(self.zos.ZOSAPI.Analysis.AnalysisIDM.FftMtf)

        # apply all the settings so we have consistent outputs across computers
        win_settings = win.GetSettings().__implementation__

        win_settings.Field.UseAllFields() if field == 0 else win_settings.Field.SetFieldNumber(field)
        win_settings.Surface.UseImageSurface() if surface == 0 else win_settings.Surface.SetSurfaceNumber(surface)
        win_settings.Wavelength.UseAllWavelengths() if wavelength == 0 else win_settings.Wavelength.SetWavelengthNumber(wavelength)
        win_settings.Type = self.zos.try_parse(self.zos.ZOSAPI.Analysis.Settings.Mtf.MtfTypes, mtf_type, 'modulation')[1]
        win_settings.SampleSize = self.zos.try_parse(self.zos.ZOSAPI.Analysis.SampleSizes, sample_size, 's_64x64')[1]
        win_settings.ShowDiffractionLimit = show_diffraction_limit
        win_settings.UsePolarization = use_polarization
        win_settings.MaximumFrequency = maximum_frequency

        # run the window
        win.ApplyAndWaitForCompletion()

        # get the results
        res = win.GetResults()
        header = list(res.HeaderData.Lines)

        # it's always a good idea to save the input settings so we know how to recreate the data
        settings = {
            'window': str(win.AnalysisType),
            'field': win_settings.Field.GetFieldNumber(),
            'surface': win_settings.Surface.GetSurfaceNumber(),
            'wavelength': win_settings.Wavelength.GetWavelengthNumber(),
            'type': str(win_settings.Type),
            'sample_size': str(win_settings.SampleSize),
            'show_diffraction_limit': win_settings.ShowDiffractionLimit,
            'use_polarization': win_settings.UsePolarization,
            'maximum_frequency': win_settings.MaximumFrequency
        }

        data = []
        for series in list(res.DataSeries):
            this_series = self.zos.get_series(series)
            data.append(this_series)

        # always close the analysis
        win.Close()

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    mtf = FftMtf()
    res = mtf.run(field=0)

    print(f'settings : {res['settings']}')
    print(f'header   : {res['header']}')
    