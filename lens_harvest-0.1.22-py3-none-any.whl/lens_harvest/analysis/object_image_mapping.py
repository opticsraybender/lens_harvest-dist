# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ..connect import Connect
import numpy as np
import pandas as pd

import clr
from System import Enum

class ObjectImageMapping(object):
    def __init__(self):
        # connect to OpticStudio
        self.zos = Connect()
        
        # constants for the system
        self.pwav = None
    
    def get_pwav(self):
        '''
        gets the primary wavelength, used in several operands
        '''
        if self.pwav is None:
            for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
                if self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i).IsPrimary:
                    self.pwav = i
                    break
        return self.pwav
    
    def run(self, 
            wavelength=0,
            field_density=100
            ):
        '''
        Creates a non-linear mapping between object angle and image height, regardless of the defined field type
        '''
        
        wave = self.get_pwav() if wavelength == 0 else wavelength

        norm_hy = list(np.linspace(0, 1, field_density))
        
        # we probably want a flat image surface, just like the CRA analysis
        copy_sys = self.zos.TheSystem.CopySystem()
        copy_sys.LDE.GetSurfaceAt(copy_sys.LDE.NumberOfSurfaces - 1).Radius = float('inf')
        NSUR = copy_sys.LDE.NumberOfSurfaces - 1 

        # convert to millimeters so REAY is consistent across all files
        tool = copy_sys.Tools.OpenScale()
        tool.ScaleByUnits = True
        tool.ScaleToUnit = self.zos.ZOSAPI.Tools.General.ScaleToUnits.Millimeters
        tool.RunAndWaitForCompletion()
        tool.Close()

        obj_angle = []
        img_height = []
        

        for hy in norm_hy:
            # assuming the Nx & Ny components of the EP are 0 so we only care about the REAC direction cosine for the AOI
            l = copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAC, 0, wave, 0, hy, 0, 0, 0, 0)
            obj_angle.append(np.rad2deg(np.acos(l)))

            img_height.append(copy_sys.MFE.GetOperandValue(self.zos.ZOSAPI.Editors.MFE.MeritOperandType.REAY, NSUR, wave, 0, hy, 0, 0, 0, 0))
            

        one_output = {}
        one_output.update({'description': 'object angle vs image height'})
        one_output.update({'xlabel': f'Object Angle (deg)'})
        one_output.update({'xdata': obj_angle})
        one_output.update({'series_labels': ['Image Height (mm)']})
        one_output.update({'num_series': 1})
        # one_output.update({'ydata': np.concatenate((np.asarray(lower), np.asarray(chief), np.asarray(upper))).tolist()})
        one_output.update({'ydata': img_height})

        copy_sys.Close(False)
        
        
        settings = {
            'window': 'ObjectImageMapping',
            'field_density': field_density,
            'wavelength': wavelength
        }

        header = [
            f'Object Angle vs Image Height',
            f'Object Angle always in degrees',
            f'Image Height always in millimeters'
            ]
        data = [one_output]

        return {'type': 'line', 'settings': settings, 'header': header, 'data': data}


if __name__ == '__main__':
    
    oi = ObjectImageMapping()

    oi.zos.TheSystem.LoadFile(r"C:\Users\humpf\OneDrive\PDF\Documents\Zemax\Samples\zebase_good\A_001.ZMX", False)

    res = oi.run(wavelength=2)

    print(f'settings : {res['settings']}')
    print(f'header   : {res['header']}')
