# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import math
import pickle
import threading
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional
from urllib.parse import unquote

import json
import numpy as np
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, Response
from pydantic import BaseModel


# =============================================================================
# FastAPI App & Data
# =============================================================================

app = FastAPI()

PKL_PATH: Optional[Path] = None
_meta: dict[str, str] = {}
_data: dict[str, Any] = {}

# Cache: directory path -> {filename: about_data}
_about_cache: dict[str, dict[str, dict]] = {}
_about_cache_lock = threading.Lock()
_about_cache_loading: set[str] = set()


def _extract_surface_types(pkl: dict) -> list:
    """Return the sorted unique surface types (e.g. 'Standard', 'CoordinateBreak')
    from a parsed file's LDE table. Returns [] if unavailable."""
    try:
        lde = pkl.get("lde")
        if not lde:
            return []
        entry = lde[0] if isinstance(lde, (list, tuple)) else lde
        rows_json = entry["data"][0]
        rows = json.loads(rows_json)
        types = {row.get("type") for row in rows if row.get("type")}
        return sorted(types)
    except Exception:
        return []


def _cache_directory_about(directory: str):
    dir_path = Path(directory)
    cache = {}
    for f in dir_path.glob("*.pkl"):
        try:
            with open(f, "rb") as fh:
                pkl = pickle.load(fh)
            about = dict(pkl.get("_about", {}).get("data", {}))
            # derive the set of surface types present (e.g. CoordinateBreak) from
            # the LDE table so files can be filtered on surface type without a re-parse
            about["surface_types"] = _extract_surface_types(pkl)
            cache[str(f)] = about
        except Exception:
            continue
    with _about_cache_lock:
        _about_cache[directory] = cache
        _about_cache_loading.discard(directory)


def ensure_about_cache(directory: str):
    with _about_cache_lock:
        if directory in _about_cache or directory in _about_cache_loading:
            return
        _about_cache_loading.add(directory)
    thread = threading.Thread(target=_cache_directory_about, args=(directory,), daemon=True)
    thread.start()


class LoadRequest(BaseModel):
    path: str


class SearchRequest(BaseModel):
    directory: str
    filters: list


# =============================================================================
# Helpers
# =============================================================================

def make_json_safe(obj):
    if obj is None or isinstance(obj, (str, bool, int)):
        return obj
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    # numpy arrays/scalars: geometry is stored as compact ndarrays in the pkl
    if isinstance(obj, np.ndarray):
        return make_json_safe(obj.tolist())
    if isinstance(obj, np.generic):
        return make_json_safe(obj.item())
    if isinstance(obj, (list, tuple)):
        return [make_json_safe(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): make_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, set):
        return [make_json_safe(x) for x in obj]
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return float(obj)
    return str(obj)


def load_pkl(path: Path) -> dict:
    global _meta
    with open(path, "rb") as f:
        pkl = pickle.load(f)
        # the wheel version that wrote this file is stored top-level; pull it out
        # so it isn't treated as an analysis key
        harvest_version = pkl.pop('_harvest_version', None)
        if '_about' in pkl:
            _meta = make_json_safe(pkl['_about'])
            del pkl['_about']
        else:
            # non-sequential files have no _about; clear stale System Info
            _meta = {}
        if harvest_version is not None:
            _meta['harvest_version'] = harvest_version
        if 'layout' in pkl:
            for item in pkl['layout']:
                if isinstance(item, dict):
                    item.setdefault('type', 'layout')
        return pkl


def load_file(filename):
    global _data
    p = Path(filename)
    if p.exists():
        _data = load_pkl(p)


# =============================================================================
# Endpoints
# =============================================================================

@app.on_event("startup")
def startup():
    if PKL_PATH and PKL_PATH.exists():
        load_file(PKL_PATH)


@app.post("/load")
def reload_file(req: Optional[LoadRequest] = None):
    global _data
    if req and req.path:
        p = Path(req.path)
    elif PKL_PATH:
        p = PKL_PATH
    else:
        raise HTTPException(400, "No file specified")
    if not p.exists():
        raise HTTPException(404, f"File not found: {p}")
    _data = load_pkl(p)
    return {"keys": list(_data.keys())}


@app.get("/keys")
def get_keys():
    return {"keys": list(_data.keys())}


@app.get("/files/{directory:path}")
def get_files(directory: str):
    path = Path(unquote(directory))
    if not path.exists():
        return {"success": False, "message": f"{directory} does not exist", "files": []}
    if not path.is_dir():
        return {"success": False, "message": f"{directory} is not a directory", "files": []}
    ensure_about_cache(str(path))
    return {"success": True, "files": [str(f) for f in path.glob("*.pkl")]}


@app.get("/cache-status/{directory:path}")
def cache_status(directory: str):
    dir_key = str(Path(unquote(directory)))
    with _about_cache_lock:
        if dir_key in _about_cache:
            return {"ready": True, "count": len(_about_cache[dir_key])}
        if dir_key in _about_cache_loading:
            return {"ready": False}
    return {"ready": False}


@app.get("/about")
def about():
    return _meta


@app.get("/browse")
def browse_directory():
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    folder = filedialog.askdirectory(title="Select PKL Directory")
    root.destroy()
    if folder:
        return {"path": folder}
    return {"path": None}


@app.get("/pkl-count/{directory:path}")
def pkl_count(directory: str):
    dir_path = Path(directory)
    if not dir_path.exists() or not dir_path.is_dir():
        return {"count": 0}
    return {"count": len(list(dir_path.glob("*.pkl")))}


@app.post("/search")
def search_files(req: SearchRequest):
    directory = Path(req.directory)
    if not directory.exists() or not directory.is_dir():
        raise HTTPException(404, "Directory not found")

    dir_key = str(directory)
    with _about_cache_lock:
        cache = _about_cache.get(dir_key)
        is_loading = dir_key in _about_cache_loading

    # If cache not ready, parse synchronously (fallback)
    if cache is None:
        if is_loading:
            # Wait for background thread to finish
            import time
            for _ in range(300):  # up to 30s
                time.sleep(0.1)
                with _about_cache_lock:
                    cache = _about_cache.get(dir_key)
                if cache is not None:
                    break
        if cache is None:
            _cache_directory_about(dir_key)
            with _about_cache_lock:
                cache = _about_cache.get(dir_key, {})

    results = []
    for filepath, about_data in cache.items():
        match = True
        for filt in req.filters:
            key = filt["key"]
            op = filt["op"]
            val = filt.get("value")
            val2 = filt.get("value2")

            if key == "filename":
                actual = Path(filepath).name
            elif key == "is_reflective":
                actual = about_data.get("materials", {}).get("mirrors", 0) > 0
            elif key == "number_of_elements":
                mats = about_data.get("materials", {})
                actual = mats.get("glasses", 0) + mats.get("mirrors", 0)
            elif key in ("glasses", "mirrors", "prisms"):
                actual = about_data.get("materials", {}).get(key, 0)
            elif key == "glass_types":
                actual = about_data.get("materials", {}).get("glass_types", [])
            else:
                actual = about_data.get(key)

            if actual is None:
                match = False
                break

            try:
                if op == "contains":
                    # for list-valued fields (glass_types, surface_types) match if
                    # any element contains the phrase; otherwise substring match
                    if isinstance(actual, (list, tuple, set)):
                        if not any(str(val).lower() in str(a).lower() for a in actual):
                            match = False
                    elif str(val).lower() not in str(actual).lower():
                        match = False
                elif op == "eq":
                    if float(actual) != float(val):
                        match = False
                elif op == "lt":
                    if float(actual) >= float(val):
                        match = False
                elif op == "gt":
                    if float(actual) <= float(val):
                        match = False
                elif op == "between":
                    if not (float(val) <= float(actual) <= float(val2)):
                        match = False
                elif op == "is_true":
                    if not actual:
                        match = False
                elif op == "is_false":
                    if actual:
                        match = False
            except (ValueError, TypeError):
                match = False

            if not match:
                break

        if match:
            results.append(filepath)

    return {"files": results}


@app.get("/data/{key}")
def get_data(key: str):
    if key not in _data:
        raise HTTPException(404, f"Key '{key}' not found")
    val = make_json_safe(_data[key])
    return Response(
        content=json.dumps(val).encode(),
        media_type="application/json",
    )


@app.get("/", response_class=HTMLResponse)
def index():
    return INDEX_HTML


# =============================================================================
# Frontend (Single-page HTML application)
# =============================================================================

INDEX_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<link rel='icon' type='image/png' href='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCA1LjEuMTITAUd0AAAAuGVYSWZJSSoACAAAAAUAGgEFAAEAAABKAAAAGwEFAAEAAABSAAAAKAEDAAEAAAACAAAAMQECABEAAABaAAAAaYcEAAEAAABsAAAAAAAAAGAAAAABAAAAYAAAAAEAAABQYWludC5ORVQgNS4xLjEyAAADAACQBwAEAAAAMDIzMAGgAwABAAAAAQAAAAWgBAABAAAAlgAAAAAAAAACAAEAAgAEAAAAUjk4AAIABwAEAAAAMDEwMAAAAADZp5qVybcLXwAAChZJREFUaEPtmXtwVcUdxz+7B5JICElIIBAICSRQsI7j6NDaOm1FqVZ8DuBQVCpUELFFkYcPIqCCCokoVlB8DFMEBSkqKkWr4ig+plPRqdZqjQkxISCPhDwgJDzO79c/7rnJYXMTLhZnnI6fmczk3P3u7u+7v91zd/fCD/wfU33xwIK9IwYWuJ+fTKz7wcmi+vKB52LZimHr3hEDz3XLTxbfmQGsDsOSaiJ/w9zik8V3aADFaqQHg7rFJ4u4DNTdkpdbd3Pe8tqb8mbWThwYVx1jUTzAKngal4GanxXY3WcPnrn7J4OX7x46ONctj0VcwWApxDIZQzFdjoxzi2NiFWODHuLrBd/zxhmrxUFfs93yWMTXtGUnHhgLxnDnvpvyuruSNtjAhBdfL3vO/VF3LHdiwUSm3k5XE4s4mgasLMVoWTCaBdYy3ZW0IRp4NBPHw+p0PC0I+thmrC5zJbGIp2nSFlVWY1kQWpRT66blDXF1x2AxLdPHqnGLw+y9YNAQ43ETFvAUPOb3/ODLalcXi7gMANCZVVi24ClYumGZ50rCGKs2tAY67sfTeVhSAv0WX3WVK2mPjhsOkbagwscyF4uPVTCMqZued6Gra8FSghdMH48StzhK9aUDL8QyJsiubyxze28p8V1de8RtACDt/op3jGFVy+vRclfd9P5Jrg4Ay1oMV2H1KmtY6xYDVI/OT8JyV2umdFWPN0recXUd0eHcjEV9YW4+yocqpOMDan6c9sDXn7u6eKgeVXAqwr8RA0KtKkN7bPyqzNV1xAllACD13ooyDLOMoQqPp1D9ytXEjUcplqewWoVl1okGz7fJQJT6wtxuqfdWNLifA+ydmGc7JZoEhE4IiG+O0uwdzlj9lbhagOrRBd0y15fGbOt4fGsDUepn5/ZUYQjCaYgZjE8uQg8Vk4zQGQGEIyqmEWEvQgXClyrmXwhfZDxTtsdt80T4VgYa5vcboMJv8BmBmDMReqlg8CGYz6i0/h/9Uz/8bFSFXQgfI7yK8FrGurLvdgo1LMoZjjAJnwsRkxoJ0g0a8I0iHFLhaFDWCSERwTgmWusI9Yh5HeGJjPWlb7p9t0dcBvYv6TsMn9mIGa5+64gGATQhlOCbTxA+U6EU32xHqMPncJCJBJQ0hBwV8hFzGsIZCIMQc0rIRLTNNxHuz3yh9C03FpcODRx4tE9v9VmAmAkIpqUDnyMI7yPmBXzeUqU09a7KQ9F6dXfknorPmYjpGwRWpcrH6Q+3vm73TRqQiE8BwnmIGanCOa1rxqCCIvwZoTBzQ+k3LUE5tGvgwBN9LsLnUYS80Hw+iM9aFbO8263bP3Tr1M/tNxrhFsQMVaGzsyaOIOYfKEvSl5avd+vW/C5/KMJkhLEIXYKBAuFrlD9kbijd5NahPQONK7JnqM9CxHSKplbFrMdnfsq0qk9dfcOCnBTEPKLCte2sidCzAWElwtT0x8r3u23VXJ1/OsIclNEhE0dRbs/cULrY1bcx0Ph0djHCTISgstmBMKPrlB3PuVqA+oX9kozo8wgjQotyL77ZgvBF8DwEMb+MvF5bTGxCGJX+WHmz2yZAzdj8MSiLEdNHBSLf+hRnbii9Naw7xsDBZ3svUuHW0OvvXfW5tuukneVhXZj9RTnFGhgORv9x9bk39e7K7WFd3ay8HIRChMkhEw+kLyufFdaFqRmb3x9hJWp+ETJRlLmh9LaopsXAwXW9bkbMklCq/4Jvfp88YceBlhYd9j/U9yyEDxCTEKR6TrfZ2xe4ujB1M/LmINwT9HEY5efpS8s/cnVRaq4a0BXfrEDNlSET0zI3lD5MdC908IVe52Mpih5YjGW9Wv+ajoIHwHIdloTg6PjK8YIHSFv89XwsGyM7UE3AcJ2rCZPx7LYDdNarMbo+2JqDoaj6ioLzAWzTy1ndjcfSSCCA1fewTOh6ze7DbmNhDizLTsYyLHTqWuJq2sWyJBgojNVh+6bmJbuSMBmrtx3B0wkYfS/YeidgWFp9RUF3i8dcrA4ODt878Bjf5bffdDzyANZkG6t9g6xVYvnYlbSLlY+wWhmY72s9ersSl4xntx3AMh6rO4JYB2OZa7FMCUYQ42lxl1G74tuPWFKwJARToVqtOehK2sN45iCW6sB8ApZuriYWGWvKyjAUh247plhj9d3WacBlTS9mJboVY2L1UOR4CcaSbK10ciXtYuhkPJKDk52PpeVbvCP2jctPxOOylgG3vGsxzDBWGwMD59GJe92KMbHswmpNUC8Xj3xX0i5W87HkBouyBqu7XElMPL3PWM4L+mzE6gybdMGeTzDMCS6TwDKjaWPWjW5dl67X7awxlq3BLUUSlvGupl08xmM1Kcjeh2lFFTWuxGXfxAF/xDI9dOM3N2Nt2ScWIOmCPQ9hWdNiwvBI08asiW4jbbA8HawBMNx4YHmf4a7EpWFBznBjuTE6DbD6tKtxqZ3Sf7Lx9E+hN97ajNVlDxI8RvCYjOXtwITF8ETTxqx2vyUBSOIlDH+LLChNwrD2wPI+o11ZlIZFOaOxrMVqUjCKr6UuqNzg6sLUTu1fiGU5FmMi2X4by/XR8mO2Es2be/ZAeBHhHG3dTjyDMP2Uy3fHPPo1rswuQNmM0C/YO0X2OcrzCCUqBnwGIYxGzEXOeeIzVS5LnVfZZqtSNzMvG5+HNVIvWud9hJHpj5e3xNJmM9e8uWc6wiqEi0MmtiEUssd77pRJO9tclTeuzD4DZR3CwJAJnB1oNOjoDjP6/IUql6TOq9wWba/u9txfI6zAj5wngjb+ijAufVl5bbjv1ikUkHT+nlo6MRLLg6GFPQDLGnrK5qYXe13SuK5X53Cd5Gt3/hPDrzA8aTwOBgubYJFGL8EI3hxLgy1I8ObTIcbwSv3d/QZE2zOG+ViiX5IYy2I8GekGT6wMhGl+veflKMUqZmB4BBG2qrAGYRPNlHQZt0uidRpXZA9CuVSFnyImO6i3U33zd4SNKdOqSgAainJGIaxGSHIzUV+Yez/K7Sp8ic9tacUVLx0TWIgODQA0v94jAzUzVcwNCGnONGhE+BQ1HwSm/oOy3XT26rqMqfL3P9nbCh6pk6qkeWUv7+h+L0190w+lMWVaVUlDUc7IYI2FTVycOq+yvL4w9wyUytT7Kva5MYU5roEoza9l5atwA8pYhD4x5jKR+x9qEWqJ3AMdipxtTSI+yQjpKmQipgllZMq0qjdiZOLzIBNtFnYs4jYQpWlTVs/I6YtRqDlbfTLRYJ9+zFEytJBjL+w7Um6uWkjs6fS5KiNS51VWuP27nLCBME0vZ/VBzFmR+c7pRK5MMhCSVUhEjBcE7avPoSArtQgfqTArZeqOlp+R2kwnNfd0m1PZ4W8Q/K8GXA4+n5XEUdsdIVWVLvgkBiN/GKFRhXrU1Ha9fkeTW5fWTDyJkIBwZbc7t7/qar73NBTlDGhYmDPI/fwHvq/8F+2KsFZYIQ63AAAAAElFTkSuQmCC'>
<meta charset="UTF-8">
<title>Lens Harvest</title>
<script src="https://cdn.plot.ly/plotly-2.27.0.min.js"></script>
<script type="importmap">
{
  "imports": {
    "three": "https://cdn.jsdelivr.net/npm/three@0.168.0/build/three.module.js",
    "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.168.0/examples/jsm/"
  }
}
</script>
<style>
  /* --- Theme Variables --- */
  :root {
    --bg-body: #1a1a2e;
    --bg-panel: #16213e;
    --bg-elevated: #2a2a4a;
    --bg-sidebar: #22223a;
    --border: #444;
    --border-light: #555;
    --text: #eee;
    --text-muted: #ccc;
    --text-dim: #aaa;
    --accent: #4a6fa5;
    --accent-border: #6a8fc5;
    --hover: #3a3a5a;
    --table-header: #2a2a4a;
    --table-stripe: #22223a;
    --layout-bg: #1a1a2e;
    --layout-cross: #cccccc;
    --layout-mesh: #55555F;
  }
  body.light {
    --bg-body: #f5f5f5;
    --bg-panel: #ffffff;
    --bg-elevated: #e8e8e8;
    --bg-sidebar: #ebebeb;
    --border: #ccc;
    --border-light: #bbb;
    --text: #222;
    --text-muted: #444;
    --text-dim: #666;
    --accent: #4a6fa5;
    --accent-border: #6a8fc5;
    --hover: #d8d8d8;
    --table-header: #e0e0e0;
    --table-stripe: #f0f0f0;
    --layout-bg: #f5f5f5;
    --layout-cross: #222222;
    --layout-mesh: #888888;
  }

  /* --- Reset & Layout --- */
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { height: 100%; overflow: hidden; }
  body { font-family: system-ui, sans-serif; padding: 0; background: var(--bg-body); color: var(--text); display: flex; flex-direction: row; }
  #main-content { flex: 1; min-width: 0; display: flex; flex-direction: column; padding: 1rem; }

  /* --- Header & Meta --- */
  h1 { margin-bottom: 1rem; }
  #meta { color: var(--text-muted); font-size: 0.7em; margin-top: -10px; margin-bottom: -10px; position: relative; top: 10px; flex-shrink: 0; }
  select, button { font-size: 1rem; padding: 0.4rem 0.8rem; margin-right: 0.5rem; }
  #h1_name { background: transparent; border: none; padding: 0; margin: 0; font: inherit; color: inherit; }
  #h1_name option { font-size: 1rem; font-weight: normal; color: #333; }

  /* --- Grid Selector --- */
  #grid-selector { flex-shrink: 0; align-items: center; }
  .grid-btn { background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; width: 32px; height: 32px; cursor: pointer; color: var(--text-muted); font-size: 0.7rem; line-height: 1; display: flex; align-items: center; justify-content: center; padding: 0; }
  .grid-btn.active { background: var(--accent); border-color: var(--accent-border); color: #fff; }

  /* --- Panel Grid --- */
  #panel-grid { flex: 1; min-height: 0; display: grid; gap: 0; margin-top: 25px; }
  #panel-grid.grid-1x1 { grid-template-columns: 1fr; grid-template-rows: 1fr; }
  #panel-grid.grid-1x2 { grid-template-columns: 1fr 1fr; grid-template-rows: 1fr; gap: 4px; }
  #panel-grid.grid-2x1 { grid-template-columns: 1fr; grid-template-rows: 1fr 1fr; gap: 4px; }
  #panel-grid.grid-2x2 { grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr; gap: 4px; }

  /* --- Panels --- */
  .panel { display: flex; flex-direction: column; min-height: 0; overflow: hidden; border: 1px solid var(--border); }
  .panel-controls { display: flex; align-items: center; gap: 0.5rem; padding: 0.3rem 0.5rem; flex-shrink: 0; }
  .panel-key-select { background: transparent; border: none; color: var(--text); font-size: 0.9rem; outline: none; cursor: pointer; }
  .panel-key-select option { background: var(--bg-body); color: var(--text); }
  .panel-icon-btn { background: none; border: none; cursor: pointer; padding: 4px; display: flex; align-items: center; justify-content: center; opacity: 0.7; color: var(--text-muted); }
  .panel-icon-btn:hover { opacity: 1; }
  .panel-settings { max-height: 200px; overflow-y: auto; flex-shrink: 0; padding: 0 0.5rem; }
  .panel-viz { flex: 1; min-height: 0; overflow: hidden; position: relative; width: 100%; }
  .panel-rawdata { flex: 1; min-height: 0; overflow: auto; padding: 0.5rem; display: none; }
  .panel-rawdata-pre { margin: 0; font-size: 0.8rem; line-height: 1.3; white-space: pre; color: var(--text); }

  /* --- Tables --- */
  table { border-collapse: collapse; width: 100%; margin-top: 1rem; table-layout: fixed; }
  th, td { border: 1px solid var(--border); padding: 0.3rem 0.6rem; text-align: right; }
  th { background: var(--table-header); }
  tr:nth-child(even) { background: var(--table-stripe); }
  .sag-table-wrap { position: absolute; top: 0; left: 0; right: 0; bottom: 0; overflow-x: auto; overflow-y: auto; }
  .sag-table-wrap table { width: auto; table-layout: fixed; }
  .sag-table-wrap th, .sag-table-wrap td { width: 100px; min-width: 100px; max-width: 100px; }
  .sag-table-wrap thead th { position: sticky; top: 0; background: var(--table-header); z-index: 1; }
  .desc { color: var(--text-dim); font-style: italic; margin-bottom: 0.5rem; }
  .layout-settings { display: flex; flex-wrap: wrap; gap: 0.4rem 0.7rem; align-items: center; font-size: 0.75rem; padding: 0; margin: 0; line-height: 1; }
  .layout-settings label { display: flex; align-items: center; gap: 0.2rem; color: var(--text-muted); margin: 0; }
  .layout-settings select { font-size: 0.75rem; padding: 0.1rem 0.2rem; background: var(--bg-body); border: 1px solid var(--border-light); color: var(--text); border-radius: 3px; }
  .layout-settings button { font-size: 0.75rem; margin: 0; }
  .panel-settings-pre:has(.layout-settings) { margin: 0; padding: 0.2rem 0; }
  .lde-table { table-layout: auto; margin-top: 0; }
  .zernike-table th { position: sticky; top: 0; background: var(--table-header); z-index: 1; }
  .lde-table th { position: sticky; top: 0; background: var(--table-header); z-index: 1; white-space: nowrap; }
  .lde-table td { white-space: nowrap; font-size: 0.8rem; }
  .lde-table tr:nth-child(even) { background: transparent; }
  .lde-table tr[style] td { color: #000; }
  .lde-table tbody tr { cursor: pointer; }
  .lde-table tbody tr:hover { outline: 2px solid var(--text-muted); outline-offset: -2px; }
  .lde-table tbody tr.lde-active { outline: 2px solid #ff8000; outline-offset: -2px; }
  .lde-table:focus { outline: none; }

  /* --- Segmented Controls --- */
  .segmented-control { display: inline-flex; border: 1px solid var(--border-light); border-radius: 6px; overflow: hidden; margin: 0.4rem 0; }
  .segmented-control button { background: var(--bg-elevated); color: var(--text-muted); border: none; padding: 0.3rem 0.8rem; font-size: 0.85rem; cursor: pointer; border-right: 1px solid var(--border-light); transition: background 0.15s; }
  .segmented-control button:last-child { border-right: none; }
  .segmented-control button:hover { background: var(--hover); }
  .segmented-control button.active { background: var(--accent); color: #fff; }

  /* --- Left Sidebar (Info) --- */
  #left-sidebar { width: 0; min-width: 0; background: var(--bg-sidebar); border-right: 1px solid var(--border); overflow-y: auto; overflow-x: hidden; transition: width 0.25s ease, min-width 0.25s ease, padding 0.25s ease; padding: 0; position: relative; }
  #left-sidebar.open { width: 300px; min-width: 300px; padding: 1rem; }
  #left-sidebar-content { opacity: 0; transition: opacity 0.15s ease; }
  #left-sidebar.open #left-sidebar-content { opacity: 1; }
  #left-sidebar-content h3 { margin-bottom: 0.6rem; font-size: 0.95rem; }
  #left-sidebar-toggle { background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; padding: 6px 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; width: 32px; height: 32px; color: var(--text-muted); flex-shrink: 0; }
  #about-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; table-layout: fixed; }
  #about-table td { border: none; padding: 0.25rem 0.4rem; vertical-align: top; word-wrap: break-word; }
  #about-table td:first-child { width: 40%; font-weight: 600; color: var(--text-muted); }
  #about-table tr:nth-child(even) { background: var(--table-stripe); }
  .about-section { margin-bottom: 0.8rem; }
  .about-section h4 { font-size: 0.8rem; color: var(--text-dim); margin-bottom: 0.3rem; border-bottom: 1px solid var(--border); padding-bottom: 0.2rem; }

  /* --- Right Sidebar (Filters) --- */
  #sidebar { width: 0; min-width: 0; background: var(--bg-sidebar); border-left: 1px solid var(--border); overflow-y: auto; overflow-x: hidden; transition: width 0.25s ease, min-width 0.25s ease, padding 0.25s ease; padding: 0; position: relative; }
  #sidebar.open { width: 300px; min-width: 300px; padding: 1rem; }
  .top-right-controls { position: fixed; top: 0.7rem; right: 0.7rem; z-index: 400; display: flex; gap: 4px; align-items: center; }
  #copy-zmx-path, #dir-dialog-btn { background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; padding: 6px 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; width: 32px; height: 32px; color: var(--text-muted); }
  #theme-toggle { background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; padding: 6px 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; width: 32px; height: 32px; color: var(--text-muted); }
  #sidebar-toggle { background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; padding: 6px 8px; cursor: pointer; display: flex; flex-direction: column; gap: 3px; align-items: center; justify-content: center; width: 32px; height: 32px; }
  #sidebar-toggle span { display: block; width: 18px; height: 2px; background: var(--text-muted); border-radius: 1px; }
  #sidebar-content { opacity: 0; transition: opacity 0.15s ease; }
  #sidebar.open #sidebar-content { opacity: 1; }
  #sidebar-content h3 { margin-bottom: 0.6rem; font-size: 0.95rem; }

  /* --- Filters --- */
  .filter-row { margin-bottom: 0.6rem; padding: 0.4rem; background: var(--bg-elevated); border-radius: 4px; }
  .filter-row .filter-select-row { display: flex; align-items: center; gap: 4px; }
  .filter-row .filter-select-row .filter-select-wrap { flex: 1; position: relative; }
  .filter-row .filter-select-row .filter-select-wrap select { width: 100%; }
  /* custom caret (the native <select> arrow sits under the overlay input) */
  .filter-row .filter-select-row .filter-select-wrap::after { content: ''; position: absolute; top: 50%; right: 8px; width: 0; height: 0; border-left: 4px solid transparent; border-right: 4px solid transparent; border-top: 5px solid var(--text-dim); transform: translateY(-25%); pointer-events: none; z-index: 3; }
  /* search-as-you-type input overlaid on top of the criteria <select>; borderless
     and transparent so only the <select>'s own outline/background shows */
  .filter-row .filter-select-row .filter-search { position: absolute; top: 0.2rem; left: 0; width: calc(100% - 18px); box-sizing: border-box; margin-top: 0; border: none; background: transparent; z-index: 2; outline: none; }
  .filter-row .filter-select-row .filter-search::placeholder { color: var(--text-dim); }
  .filter-row .filter-select-row button { flex-shrink: 0; }
  /* custom filterable dropdown panel (replaces the native popup so it can filter
     live while staying open as the user types) */
  .filter-dropdown { position: absolute; top: 100%; left: 0; right: 0; margin-top: 2px; max-height: 220px; overflow-y: auto; background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; z-index: 50; display: none; box-shadow: 0 4px 10px rgba(0,0,0,0.25); }
  .filter-dropdown.open { display: block; }
  .filter-dropdown-item { padding: 0.3rem 0.5rem; font-size: 0.8rem; color: var(--text); cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .filter-dropdown-item:hover, .filter-dropdown-item.active { background: var(--hover); }
  .filter-dropdown-empty { padding: 0.3rem 0.5rem; font-size: 0.8rem; color: var(--text-dim); }
  .filter-row select, .filter-row input { width: 100%; margin-top: 0.2rem; font-size: 0.8rem; padding: 0.25rem 0.4rem; background: var(--bg-body); border: 1px solid var(--border-light); color: var(--text); border-radius: 3px; }
  .filter-row label { font-size: 0.75rem; color: var(--text-dim); }
  .filter-row .filter-inputs { margin-top: 0.3rem; }
  .filter-row .filter-inputs input { display: inline-block; width: 45%; }
  .filter-row .filter-inputs input + input { margin-left: 5%; }
  #sidebar-buttons { display: flex; gap: 0.5rem; margin-top: 0.8rem; }
  #sidebar-buttons button { flex: 1; font-size: 0.85rem; padding: 0.4rem; cursor: pointer; border-radius: 4px; border: 1px solid var(--border-light); }
  #btn-search { background: var(--accent); color: #fff; }
  #btn-reset { background: var(--bg-elevated); color: var(--text-muted); }
  #add-filter-btn { width: 100%; margin-top: 0.5rem; font-size: 0.8rem; padding: 0.3rem; background: var(--bg-elevated); border: 1px solid var(--border-light); color: var(--text-muted); border-radius: 4px; cursor: pointer; }
  #add-filter-btn:hover { background: var(--hover); }

  /* --- Axes Dialog --- */
  #axes-ctx-menu { display: none; position: absolute; background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 4px; padding: 2px 0; z-index: 200; }
  #axes-ctx-menu div { padding: 6px 16px; cursor: pointer; color: var(--text); font-size: 0.9rem; }
  #axes-ctx-menu div:hover { background: var(--hover); }
  #axes-dialog { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: 6px; padding: 1.2rem; z-index: 501; min-width: 260px; }
  #axes-dialog label { display: block; margin-bottom: 0.4rem; font-size: 0.85rem; }
  #axes-dialog input { width: 100%; padding: 0.3rem 0.5rem; margin-bottom: 0.6rem; font-size: 0.9rem; background: var(--bg-body); border: 1px solid var(--border-light); color: var(--text); border-radius: 3px; }
  #axes-dialog .btn-row { display: flex; gap: 0.5rem; justify-content: flex-end; margin-top: 0.5rem; }
  #axes-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.4); z-index: 500; }
</style>
</head>
<body>

<div id="left-sidebar">
  <div id="left-sidebar-content">
    <h3>System Info</h3>
    <div id="about-info"></div>
  </div>
</div>

<!-- ===== Main Content ===== -->
<div id="main-content">
<div style="display:flex;align-items:center;gap:1rem;position:relative;z-index:10;">
  <button id="left-sidebar-toggle" title="Toggle info panel"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="12" x2="12" y2="16"/><circle cx="12" cy="8" r="0.5" fill="currentColor" stroke="none"/></svg></button>
  <h1 style="margin:0;font-size: 1em">Lens Viewer : <select id='h1_name'></select></h1>
  <div id="grid-selector" style="display:flex;gap:4px;">
    <button class="grid-btn active" data-layout="1x1" title="Single panel">&#9633;</button>
    <button class="grid-btn" data-layout="1x2" title="Side by side">&#9633;&#9633;</button>
    <button class="grid-btn" data-layout="2x1" title="Stacked">&#9633;<br>&#9633;</button>
    <button class="grid-btn" data-layout="2x2" title="2x2 grid">&#9633;&#9633;<br>&#9633;&#9633;</button>
  </div>
</div>
<div id='meta'></div>
<div id="panel-grid" class="grid-1x1">
  <div class="panel" data-panel-id="0">
    <div class="panel-controls">
      <label>Analysis:</label>
      <select class="panel-key-select"><option>Loading...</option></select>
      <button class="panel-icon-btn panel-toggle-btn" title="Toggle settings"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68 1.65 1.65 0 0 0 10 3.17V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
      <button class="panel-icon-btn panel-legend-btn" title="Toggle legend"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="9" y2="6"/><line x1="3" y1="12" x2="9" y2="12"/><line x1="3" y1="18" x2="9" y2="18"/><rect x="12" y="4" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="10" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="16" width="4" height="4" fill="currentColor" stroke="none"/></svg></button>
      <button class="panel-icon-btn panel-rawdata-btn" title="Show raw data"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="8" y1="9" x2="10" y2="9"/></svg></button>
    </div>
    <div class="panel-settings"><pre class="panel-settings-pre"></pre></div>
    <div class="panel-viz"></div>
    <div class="panel-rawdata"><pre class="panel-rawdata-pre"></pre></div>
  </div>
  <div class="panel" data-panel-id="1" style="display:none;">
    <div class="panel-controls">
      <label>Analysis:</label>
      <select class="panel-key-select"><option>Loading...</option></select>
      <button class="panel-icon-btn panel-toggle-btn" title="Toggle settings"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68 1.65 1.65 0 0 0 10 3.17V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
      <button class="panel-icon-btn panel-legend-btn" title="Toggle legend"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="9" y2="6"/><line x1="3" y1="12" x2="9" y2="12"/><line x1="3" y1="18" x2="9" y2="18"/><rect x="12" y="4" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="10" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="16" width="4" height="4" fill="currentColor" stroke="none"/></svg></button>
      <button class="panel-icon-btn panel-rawdata-btn" title="Show raw data"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="8" y1="9" x2="10" y2="9"/></svg></button>
    </div>
    <div class="panel-settings"><pre class="panel-settings-pre"></pre></div>
    <div class="panel-viz"></div>
    <div class="panel-rawdata"><pre class="panel-rawdata-pre"></pre></div>
  </div>
  <div class="panel" data-panel-id="2" style="display:none;">
    <div class="panel-controls">
      <label>Analysis:</label>
      <select class="panel-key-select"><option>Loading...</option></select>
      <button class="panel-icon-btn panel-toggle-btn" title="Toggle settings"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68 1.65 1.65 0 0 0 10 3.17V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
      <button class="panel-icon-btn panel-legend-btn" title="Toggle legend"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="9" y2="6"/><line x1="3" y1="12" x2="9" y2="12"/><line x1="3" y1="18" x2="9" y2="18"/><rect x="12" y="4" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="10" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="16" width="4" height="4" fill="currentColor" stroke="none"/></svg></button>
      <button class="panel-icon-btn panel-rawdata-btn" title="Show raw data"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="8" y1="9" x2="10" y2="9"/></svg></button>
    </div>
    <div class="panel-settings"><pre class="panel-settings-pre"></pre></div>
    <div class="panel-viz"></div>
    <div class="panel-rawdata"><pre class="panel-rawdata-pre"></pre></div>
  </div>
  <div class="panel" data-panel-id="3" style="display:none;">
    <div class="panel-controls">
      <label>Analysis:</label>
      <select class="panel-key-select"><option>Loading...</option></select>
      <button class="panel-icon-btn panel-toggle-btn" title="Toggle settings"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68 1.65 1.65 0 0 0 10 3.17V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
      <button class="panel-icon-btn panel-legend-btn" title="Toggle legend"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="9" y2="6"/><line x1="3" y1="12" x2="9" y2="12"/><line x1="3" y1="18" x2="9" y2="18"/><rect x="12" y="4" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="10" width="4" height="4" fill="currentColor" stroke="none"/><rect x="12" y="16" width="4" height="4" fill="currentColor" stroke="none"/></svg></button>
      <button class="panel-icon-btn panel-rawdata-btn" title="Show raw data"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="8" y1="9" x2="10" y2="9"/></svg></button>
    </div>
    <div class="panel-settings"><pre class="panel-settings-pre"></pre></div>
    <div class="panel-viz"></div>
    <div class="panel-rawdata"><pre class="panel-rawdata-pre"></pre></div>
  </div>
</div>
</div>

<!-- ===== Sidebar ===== -->
<div class="top-right-controls">
  <button id="copy-zmx-path" title="Copy .zmx path to clipboard"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></button>
  <button id="dir-dialog-btn" title="Select directory"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg></button>
  <button id="theme-toggle" title="Toggle light/dark mode"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg></button>
  <button id="sidebar-toggle" title="Filter Files"><span></span><span></span><span></span></button>
</div>
<div id="sidebar">
  <div id="sidebar-content">
    <h3>Filter Files</h3>
    <div id="filter-list"></div>
    <button id="add-filter-btn">+ Add Filter</button>
    <div id="sidebar-buttons">
      <button id="btn-search">Search</button>
      <button id="btn-reset">Reset</button>
    </div>
    <span id="filter-count" style="font-size:0.75rem;color:var(--text-dim);margin-top:0.4rem;display:block;"></span>
  </div>
</div>

<!-- ===== Axes Context Menu & Dialog ===== -->
<div id="axes-ctx-menu"><div id="axes-ctx-modify">Modify Axes</div></div>
<div id="axes-overlay"></div>
<div id="axes-dialog">
  <label>X Min <input id="ax-xmin" type="number" step="any"></label>
  <label>X Max <input id="ax-xmax" type="number" step="any"></label>
  <label>Y Min <input id="ax-ymin" type="number" step="any"></label>
  <label>Y Max <input id="ax-ymax" type="number" step="any"></label>
  <label style="display:flex;align-items:center;gap:0.4rem;margin-top:0.4rem;"><input id="ax-persistent" type="checkbox"> Persistent</label>
  <div class="btn-row">
    <button id="ax-cancel">Cancel</button>
    <button id="ax-ok">Ok</button>
  </div>
</div>

<!-- ===== Directory Dialog ===== -->
<div id="dir-overlay" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:499;"></div>
<div id="dir-dialog" style="display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:6px;padding:1.5rem;z-index:500;min-width:400px;">
  <h3 style="margin-bottom:1rem;font-size:1rem;">Select Directory</h3>
  <input id="dir-path" type="text" readonly style="width:100%;padding:0.4rem 0.6rem;font-size:0.85rem;background:var(--bg-body);border:1px solid var(--border-light);color:var(--text);border-radius:3px;margin-bottom:0.5rem;">
  <div id="dir-pkl-count" style="font-size:0.8rem;color:var(--text-muted);margin-bottom:1rem;"></div>
  <div style="display:flex;gap:0.5rem;justify-content:flex-end;">
    <button id="dir-browse" style="background:var(--bg-elevated);border:1px solid var(--border-light);color:var(--text-muted);border-radius:4px;padding:0.4rem 0.8rem;cursor:pointer;">Browse...</button>
    <button id="dir-cancel" style="background:var(--bg-elevated);border:1px solid var(--border-light);color:var(--text-muted);border-radius:4px;padding:0.4rem 0.8rem;cursor:pointer;">Cancel</button>
    <button id="dir-ok" style="background:var(--accent);border:1px solid var(--accent-border);color:#fff;border-radius:4px;padding:0.4rem 0.8rem;cursor:pointer;">Ok</button>
  </div>
</div>

<!-- ===== Main Script ===== -->
<script>
window._layoutModuleReady = new Promise(resolve => { window._layoutModuleResolve = resolve; });

// =============================================================================
// Panel Infrastructure
// =============================================================================

const panels = [];

function createPanel(el) {
  const panel = {
    id: parseInt(el.dataset.panelId),
    container: el,
    sel: el.querySelector('.panel-key-select'),
    viz: el.querySelector('.panel-viz'),
    settings: el.querySelector('.panel-settings'),
    settingsPre: el.querySelector('.panel-settings-pre'),
    toggleBtn: el.querySelector('.panel-toggle-btn'),
    legendBtn: el.querySelector('.panel-legend-btn'),
    rawdataBtn: el.querySelector('.panel-rawdata-btn'),
    rawdata: el.querySelector('.panel-rawdata'),
    rawdataPre: el.querySelector('.panel-rawdata-pre'),
    rawdataVisible: false,
    headerText: '',
    legendVisible: true,
    zmxData: null,
    plotEl: null,
  };

  panel.sel.addEventListener('change', () => {
    const paramName = panel.id === 0 ? 'key' : 'key' + panel.id;
    updateQueryParam(paramName, panel.sel.value);
    panel._persistentAxes = null;
    loadSelected(panel);
  });

  panel.settings.style.display = 'none';
  panel.toggleBtn.style.opacity = '0.4';

  panel.toggleBtn.addEventListener('click', () => {
    const isHidden = panel.settings.style.display === 'none';
    panel.settings.style.display = isHidden ? '' : 'none';
    panel.toggleBtn.style.opacity = isHidden ? '1' : '0.4';
    updateQueryParam('s' + panel.id, isHidden ? 'e' : null);
    if (panel.viz._fullLayout) {
      setTimeout(() => Plotly.Plots.resize(panel.viz), 0);
    }
  });

  panel.legendBtn.addEventListener('click', () => {
    panel.legendVisible = !panel.legendVisible;
    panel.legendBtn.style.opacity = panel.legendVisible ? '1' : '0.5';
    updateQueryParam('l' + panel.id, panel.legendVisible ? null : 'h');
    const el = panel.plotEl || panel.viz;
    if (el._fullLayout) {
      Plotly.relayout(el, { showlegend: panel.legendVisible });
    }
  });

  panel.rawdataBtn.addEventListener('click', () => {
    panel.rawdataVisible = !panel.rawdataVisible;
    applyRawData(panel);
    updateQueryParam('r' + panel.id, panel.rawdataVisible ? 'd' : null);
  });

  panels.push(panel);
  return panel;
}

createPanel(document.querySelector('.panel[data-panel-id="0"]'));
createPanel(document.querySelector('.panel[data-panel-id="1"]'));
createPanel(document.querySelector('.panel[data-panel-id="2"]'));
createPanel(document.querySelector('.panel[data-panel-id="3"]'));

// =============================================================================
// Grid Layout
// =============================================================================

const LAYOUT_PANELS = { '1x1': [0], '1x2': [0, 1], '2x1': [0, 1], '2x2': [0, 1, 2, 3] };

function applyGridLayout(layout) {
    const grid = document.getElementById('panel-grid');
    document.querySelectorAll('.grid-btn').forEach(b => b.classList.toggle('active', b.dataset.layout === layout));
    grid.className = 'grid-' + layout;

    const visibleIds = LAYOUT_PANELS[layout];
    panels.forEach((p, i) => {
        const shouldShow = visibleIds.includes(i);
        p.container.style.display = shouldShow ? '' : 'none';
        if (shouldShow && (!p.sel.value || p.sel.options.length <= 1)) {
            fetchKeys(p).then(() => loadSelected(p));
        }
    });

    updateQueryParam('layout', layout === '1x1' ? null : layout);
    setTimeout(() => window.dispatchEvent(new Event('resize')), 50);
}

document.getElementById('grid-selector').addEventListener('click', (e) => {
    const btn = e.target.closest('.grid-btn');
    if (!btn) return;
    applyGridLayout(btn.dataset.layout);
});

// =============================================================================
// Sidebars
// =============================================================================

document.getElementById('left-sidebar-toggle').addEventListener('click', () => {
    const sidebar = document.getElementById('left-sidebar');
    sidebar.classList.toggle('open');
    updateQueryParam('info', sidebar.classList.contains('open') ? '1' : null);
    setTimeout(() => window.dispatchEvent(new Event('resize')), 300);
});

document.getElementById('sidebar-toggle').addEventListener('click', () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
    updateQueryParam('sidebar', sidebar.classList.contains('open') ? '1' : null);
});

function getTheme() { return document.body.classList.contains('light') ? 'light' : 'dark'; }
function getThemeColors() {
    const style = getComputedStyle(document.body);
    return {
        bg: style.getPropertyValue('--bg-body').trim(),
        panel: style.getPropertyValue('--bg-panel').trim(),
        text: style.getPropertyValue('--text').trim(),
        muted: style.getPropertyValue('--text-muted').trim(),
        layoutBg: style.getPropertyValue('--layout-bg').trim(),
        layoutCross: style.getPropertyValue('--layout-cross').trim(),
        layoutMesh: style.getPropertyValue('--layout-mesh').trim(),
    };
}

document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('light');
    const isLight = getTheme() === 'light';
    updateQueryParam('theme', isLight ? 'light' : null);
    document.querySelector('#theme-toggle svg').innerHTML = isLight
        ? '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'
        : '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
    panels.forEach(p => { if (p.sel.value && p.sel.value !== 'Loading...' && p.container.style.display !== 'none') loadSelected(p); });
});

const FILTER_CRITERIA = [
  { label: 'Filename',                key: 'filename',             type: 'string' },
  { label: 'Exit Pupil Position',     key: 'EXPP',                 type: 'number' },
  { label: 'Total Track Length',      key: 'TOTR',                 type: 'number' },
  { label: 'Working F/#',            key: 'WFNO',                 type: 'number' },
  { label: 'Effective Focal Length',  key: 'EFFL',                 type: 'number' },
  { label: 'Exit Pupil Diameter',    key: 'EXPD',                 type: 'number' },
  { label: 'Entrance Pupil Diameter',key: 'EPDI',                 type: 'number' },
  { label: 'Entrance Pupil Position',key: 'ENPP',                 type: 'number' },
  { label: 'Object Distance',        key: 'object_distance',      type: 'number' },
  { label: 'Image Distance',         key: 'back_workingdistance', type: 'number' },
  { label: 'Number of Surfaces',     key: 'number_of_surfaces',   type: 'number' },
  { label: 'Is Reflective',          key: 'is_reflective',        type: 'boolean' },
  { label: 'Author',                 key: 'author',               type: 'string' },
  { label: 'Notes',                  key: 'notes',                type: 'string' },
  { label: 'Title',                  key: 'title',                type: 'string' },
  { label: 'Field of View',          key: 'radial_angle',         type: 'number' },
  { label: 'Image Height',           key: 'maximum_y',            type: 'number' },
  { label: 'Field Type',             key: 'field_type',           type: 'string' },
  { label: 'Number of Elements',     key: 'number_of_elements',   type: 'number' },
  { label: 'Transmission',           key: 'CODA',                 type: 'number' },
  // --- System Info fields ---
  { label: 'Is Afocal',              key: 'afocalmode',           type: 'boolean' },
  { label: 'Is Telecentric',         key: 'telecentric',          type: 'boolean' },
  { label: 'Lagrange Invariant',     key: 'LINV',                 type: 'number' },
  { label: 'Ray Aiming',             key: 'rayaiming',            type: 'string' },
  { label: 'Stop Surface',           key: 'stopsurface',          type: 'number' },
  { label: 'Temperature',            key: 'temperature',          type: 'number' },
  { label: 'Pressure',               key: 'pressure',             type: 'number' },
  { label: 'Reference OPD',          key: 'referenceopd',         type: 'string' },
  { label: 'Glass Count',            key: 'glasses',              type: 'number' },
  { label: 'Mirror Count',           key: 'mirrors',              type: 'number' },
  { label: 'Glass Type',             key: 'glass_types',          type: 'string' },
  { label: 'Catalog',                key: 'catalogs',             type: 'string' },
  { label: 'Field Normalization',    key: 'normalization',        type: 'string' },
  { label: 'Number of Fields',       key: 'number_of_fields',     type: 'number' },
  { label: 'Number of Wavelengths',  key: 'number_of_wavelengths',type: 'number' },
  { label: 'Primary Wavelength',     key: 'primary_wavelength',   type: 'number' },
  { label: 'Minimum Wavelength',     key: 'minimum_wavelength',   type: 'number' },
  { label: 'Maximum Wavelength',     key: 'maximum_wavelength',   type: 'number' },
  { label: 'Units',                  key: 'units',                type: 'string' },
  // --- Surface type (e.g. CoordinateBreak) ---
  { label: 'Surface Type',           key: 'surface_types',        type: 'string' },
];

let filterCount = 0;

function getUsedFilterKeys() {
    const keys = [];
    document.querySelectorAll('.filter-row select').forEach(s => {
        if (s.value) keys.push(s.value);
    });
    return keys;
}

function hasUnselectedFilter() {
    const rows = document.querySelectorAll('.filter-row');
    for (const row of rows) {
        if (!row.querySelector('select').value) return true;
    }
    return false;
}

function updateFilterControls() {
    const unselected = hasUnselectedFilter();
    document.getElementById('add-filter-btn').disabled = unselected;
    document.getElementById('add-filter-btn').style.opacity = unselected ? '0.4' : '';
    document.getElementById('btn-search').disabled = unselected;
    document.getElementById('btn-search').style.opacity = unselected ? '0.4' : '';
}

function createFilterRow() {
    if (hasUnselectedFilter()) return;

    const row = document.createElement('div');
    row.className = 'filter-row';
    row.dataset.filterId = filterCount++;

    const usedKeys = getUsedFilterKeys();
    const criteriaSelect = document.createElement('select');
    criteriaSelect.innerHTML = '<option value="">-- Select --</option>' +
        FILTER_CRITERIA
            .filter(c => !usedKeys.includes(c.key))
            .sort((a, b) => a.label.localeCompare(b.label))
            .map(c => `<option value="${c.key}" data-type="${c.type}">${c.label}</option>`).join('');

    const inputsDiv = document.createElement('div');
    inputsDiv.className = 'filter-inputs';

    const removeBtn = document.createElement('button');
    removeBtn.textContent = '×';
    removeBtn.style.cssText = 'background:none;border:none;color:var(--text-dim);cursor:pointer;font-size:1rem;padding:2px 4px;line-height:1;';
    removeBtn.addEventListener('click', () => { row.remove(); updateFilterControls(); });

    // The native <select> stays in the DOM as the value-holder (so collectFilters,
    // getUsedFilterKeys and restoreFilterRow keep working), but we drive selection
    // through an overlaid search box + a custom dropdown panel. A native popup can't
    // be filtered live while open, so we render our own list that stays open as the
    // user types. The select itself shows only its outline/background (text hidden).
    criteriaSelect.style.color = 'transparent';
    criteriaSelect.style.pointerEvents = 'none';
    criteriaSelect.tabIndex = -1;

    const selectWrap = document.createElement('div');
    selectWrap.className = 'filter-select-wrap';

    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.className = 'filter-search';
    searchInput.placeholder = '-- Select --';
    searchInput.autocomplete = 'off';

    const dropdown = document.createElement('div');
    dropdown.className = 'filter-dropdown';

    // commit a choice: sync the hidden <select> and fire its change handlers
    function chooseValue(value, label) {
        criteriaSelect.value = value;
        searchInput.value = label;
        closeDropdown();
        criteriaSelect.dispatchEvent(new Event('change'));
    }

    // (re)render the dropdown list to the options whose label contains `q`
    function renderDropdown(q) {
        q = (q || '').trim().toLowerCase();
        dropdown.innerHTML = '';
        let count = 0;
        Array.from(criteriaSelect.options).forEach(opt => {
            if (!opt.value) return;  // skip the placeholder
            if (q && !opt.textContent.toLowerCase().includes(q)) return;
            const item = document.createElement('div');
            item.className = 'filter-dropdown-item';
            if (opt.value === criteriaSelect.value) item.classList.add('active');
            item.textContent = opt.textContent;
            item.addEventListener('mousedown', (e) => {
                e.preventDefault();  // keep focus in the input
                chooseValue(opt.value, opt.textContent);
            });
            dropdown.appendChild(item);
            count++;
        });
        if (count === 0) {
            const empty = document.createElement('div');
            empty.className = 'filter-dropdown-empty';
            empty.textContent = 'No matches';
            dropdown.appendChild(empty);
        }
    }

    function openDropdown() {
        renderDropdown(searchInput.value === (criteriaSelect.selectedOptions[0] || {}).textContent ? '' : searchInput.value);
        dropdown.classList.add('open');
    }
    function closeDropdown() { dropdown.classList.remove('open'); }

    // clicking/focusing the box auto-opens the dropdown
    searchInput.addEventListener('focus', () => { searchInput.select(); openDropdown(); });
    searchInput.addEventListener('mousedown', () => { if (!dropdown.classList.contains('open')) openDropdown(); });
    // filter live while staying open as the user types
    searchInput.addEventListener('input', () => {
        if (!dropdown.classList.contains('open')) dropdown.classList.add('open');
        renderDropdown(searchInput.value);
    });
    // basic keyboard support: Enter picks first match, Escape closes
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { closeDropdown(); searchInput.blur(); }
        else if (e.key === 'Enter') {
            const first = dropdown.querySelector('.filter-dropdown-item');
            if (first) { e.preventDefault(); first.dispatchEvent(new Event('mousedown')); }
        } else if (e.key === 'ArrowDown' && !dropdown.classList.contains('open')) {
            openDropdown();
        }
    });
    // close when focus leaves; restore the committed label if left half-typed
    searchInput.addEventListener('blur', () => {
        closeDropdown();
        const opt = criteriaSelect.selectedOptions[0];
        searchInput.value = opt && opt.value ? opt.textContent : '';
    });

    selectWrap.appendChild(criteriaSelect);
    selectWrap.appendChild(searchInput);
    selectWrap.appendChild(dropdown);

    const selectRow = document.createElement('div');
    selectRow.className = 'filter-select-row';
    selectRow.appendChild(selectWrap);
    selectRow.appendChild(removeBtn);

    row.appendChild(selectRow);
    row.appendChild(inputsDiv);

    // keep the search box label in sync if the value changes programmatically
    criteriaSelect.addEventListener('change', () => {
        const opt = criteriaSelect.selectedOptions[0];
        searchInput.value = opt && opt.value ? opt.textContent : '';
    });

    criteriaSelect.addEventListener('change', () => {
        const opt = criteriaSelect.selectedOptions[0];
        const type = opt.dataset.type;
        inputsDiv.innerHTML = '';

        if (type === 'string') {
            inputsDiv.innerHTML = '<label>Contains</label><input type="text" class="filter-val" placeholder="search text...">';
        } else if (type === 'boolean') {
            inputsDiv.innerHTML = '<select class="filter-bool"><option value="is_true">Yes</option><option value="is_false">No</option></select>';
        } else if (type === 'number') {
            const opSel = document.createElement('select');
            opSel.className = 'filter-op';
            opSel.innerHTML = '<option value="eq">= Equal</option><option value="lt">&lt; Less than</option><option value="gt">&gt; Greater than</option><option value="between">Between</option>';
            inputsDiv.appendChild(opSel);

            const val1 = document.createElement('input');
            val1.type = 'number'; val1.step = 'any'; val1.className = 'filter-val'; val1.placeholder = 'value';
            inputsDiv.appendChild(val1);

            const val2 = document.createElement('input');
            val2.type = 'number'; val2.step = 'any'; val2.className = 'filter-val2'; val2.placeholder = 'max';
            val2.style.display = 'none';
            inputsDiv.appendChild(val2);

            opSel.addEventListener('change', () => {
                val2.style.display = opSel.value === 'between' ? '' : 'none';
                val1.placeholder = opSel.value === 'between' ? 'min' : 'value';
            });
        }
        updateFilterControls();
    });

    document.getElementById('filter-list').appendChild(row);
    updateFilterControls();
}

function collectFilters() {
    const filters = [];
    document.querySelectorAll('.filter-row').forEach(row => {
        const sel = row.querySelector('select');
        const key = sel.value;
        if (!key) return;

        const type = sel.selectedOptions[0].dataset.type;
        let filt = { key };

        if (type === 'string') {
            const val = row.querySelector('.filter-val').value.trim();
            if (!val) return;
            filt.op = 'contains';
            filt.value = val;
        } else if (type === 'boolean') {
            filt.op = row.querySelector('.filter-bool').value;
        } else if (type === 'number') {
            const op = row.querySelector('.filter-op').value;
            const val = row.querySelector('.filter-val').value.trim();
            if (!val) return;
            filt.op = op;
            filt.value = val;
            if (op === 'between') {
                const val2 = row.querySelector('.filter-val2').value.trim();
                if (!val2) return;
                filt.value2 = val2;
            }
        }
        filters.push(filt);
    });
    return filters;
}

function filtersToUrl(filters) {
    return filters.map(f => {
        if (f.op === 'between') return `${f.key}:between:${f.value}:${f.value2}`;
        if (f.op === 'is_true' || f.op === 'is_false') return `${f.key}:${f.op}`;
        return `${f.key}:${f.op}:${f.value}`;
    }).join(';');
}

function filtersFromUrl(str) {
    if (!str) return [];
    return str.split(';').map(s => {
        const parts = s.split(':');
        const f = { key: parts[0], op: parts[1] };
        if (f.op === 'between') { f.value = parts[2]; f.value2 = parts[3]; }
        else if (f.op !== 'is_true' && f.op !== 'is_false') { f.value = parts[2]; }
        return f;
    });
}

function restoreFilterRow(f) {
    createFilterRow();
    const row = document.getElementById('filter-list').lastElementChild;
    const sel = row.querySelector('select');
    sel.value = f.key;
    sel.dispatchEvent(new Event('change'));

    const criterion = FILTER_CRITERIA.find(c => c.key === f.key);
    if (!criterion) return;

    if (criterion.type === 'string') {
        row.querySelector('.filter-val').value = f.value || '';
    } else if (criterion.type === 'boolean') {
        row.querySelector('.filter-bool').value = f.op;
    } else if (criterion.type === 'number') {
        row.querySelector('.filter-op').value = f.op;
        row.querySelector('.filter-op').dispatchEvent(new Event('change'));
        row.querySelector('.filter-val').value = f.value || '';
        if (f.op === 'between') {
            row.querySelector('.filter-val2').value = f.value2 || '';
        }
    }
}

async function executeSearch() {
    const params = new URLSearchParams(window.location.search);
    const directory = params.get('dir');
    if (!directory) return;

    const filters = collectFilters();
    if (filters.length === 0) return;

    updateQueryParam('filters', filtersToUrl(filters));

    const searchBtn = document.getElementById('btn-search');
    searchBtn.disabled = true;
    searchBtn.textContent = 'Searching...';
    searchBtn.style.opacity = '0.6';

    const res = await fetch('/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ directory, filters })
    });
    const data = await res.json();

    const selectElement = document.getElementById('h1_name');
    const prevValue = selectElement.value;
    selectElement.length = 0;
    data.files.forEach(fullPath => {
        const fileNameWithExt = fullPath.split(/[/\\]/).pop();
        const option = new Option(fileNameWithExt, fileNameWithExt);
        option.dataset.fullname = fullPath;
        selectElement.add(option);
    });
    let found = false;
    for (let i = 0; i < selectElement.options.length; i++) {
        if (selectElement.options[i].value === prevValue) {
            selectElement.selectedIndex = i;
            found = true;
            break;
        }
    }
    updateH1Title();
    if (!found && selectElement.options.length > 0) {
        updateQueryParam('file', selectElement.value);
        reloadFile();
    }

    searchBtn.disabled = false;
    searchBtn.textContent = 'Search';
    searchBtn.style.opacity = '';
    document.getElementById('filter-count').textContent = `${data.files.length} of ${_totalFileCount}`;
}

document.getElementById('add-filter-btn').addEventListener('click', createFilterRow);
document.getElementById('btn-search').addEventListener('click', executeSearch);

document.getElementById('btn-reset').addEventListener('click', () => {
    document.getElementById('filter-list').innerHTML = '';
    updateQueryParam('filters', null);
    load_directory(false);
});

// =============================================================================
// URL State & Axes Context Menu
// =============================================================================

function updateQueryParam(key, value) {
    const params = new URLSearchParams(window.location.search);
    if (value) params.set(key, value);
    else params.delete(key);
    history.replaceState(null, '', '?' + params.toString());
}

{
    const ctxMenu = document.getElementById('axes-ctx-menu');
    const dialog = document.getElementById('axes-dialog');
    const overlay = document.getElementById('axes-overlay');
    const persistChk = document.getElementById('ax-persistent');
    let activeViz = null;
    let activePanel = null;

    panels.forEach(p => {
        p._persistentAxes = null;
        p.viz.addEventListener('contextmenu', (e) => {
            const el = p.plotEl || p.viz;
            if (!el.layout || p.viz.querySelector('.layout-container')) return;
            e.preventDefault();
            activeViz = el;
            activePanel = p;
            ctxMenu.style.left = e.pageX + 'px';
            ctxMenu.style.top = e.pageY + 'px';
            ctxMenu.style.display = 'block';
        });
    });

    document.addEventListener('click', () => ctxMenu.style.display = 'none');

    document.getElementById('axes-ctx-modify').addEventListener('click', () => {
        ctxMenu.style.display = 'none';
        if (!activeViz || !activeViz.layout) return;
        const layout = activeViz.layout;
        const xRange = layout.xaxis.range || [0, 1];
        const yRange = layout.yaxis.range || [0, 1];
        document.getElementById('ax-xmin').value = xRange[0];
        document.getElementById('ax-xmax').value = xRange[1];
        document.getElementById('ax-ymin').value = yRange[0];
        document.getElementById('ax-ymax').value = yRange[1];
        persistChk.checked = !!(activePanel && activePanel._persistentAxes);
        overlay.style.display = 'block';
        dialog.style.display = 'block';
    });

    document.getElementById('ax-cancel').addEventListener('click', () => {
        dialog.style.display = 'none';
        overlay.style.display = 'none';
    });

    overlay.addEventListener('click', () => {
        dialog.style.display = 'none';
        overlay.style.display = 'none';
    });

    document.getElementById('ax-ok').addEventListener('click', () => {
        if (!activeViz || !activeViz.layout) return;
        const xmin = parseFloat(document.getElementById('ax-xmin').value);
        const xmax = parseFloat(document.getElementById('ax-xmax').value);
        const ymin = parseFloat(document.getElementById('ax-ymin').value);
        const ymax = parseFloat(document.getElementById('ax-ymax').value);
        Plotly.relayout(activeViz, {
            'xaxis.range': [xmin, xmax],
            'yaxis.range': [ymin, ymax],
            'xaxis.autorange': false,
            'yaxis.autorange': false
        });
        if (activePanel) {
            const axes = persistChk.checked ? { xmin, xmax, ymin, ymax } : null;
            activePanel._persistentAxes = axes;
            // key by chart type so the override follows this chart to other files/panels
            const key = activePanel.sel && activePanel.sel.value;
            if (key) {
                if (axes) _persistentAxesByKey[key] = axes;
                else delete _persistentAxesByKey[key];
            }
        }
        dialog.style.display = 'none';
        overlay.style.display = 'none';
    });
}

// =============================================================================
// Data Loading
// =============================================================================

function updateH1Title() {
    const s = document.getElementById('h1_name');
    s.parentElement.title = `${s.selectedIndex + 1} of ${s.options.length}`;
}

document.getElementById('h1_name').addEventListener('change', () => {
    updateQueryParam('file', document.getElementById('h1_name').value);
    updateH1Title();
    reloadFile();
});

let _totalFileCount = 0;
let _waveMap = {};
let _aboutData = null;
// persistent axis overrides keyed by chart type (panel.sel.value, e.g. 'fft_mtf')
// so a modified axis follows that chart across files and across panels 1-4
let _persistentAxesByKey = {};

async function load_directory(first_run = false) {
    const params = new URLSearchParams(window.location.search);
    const directory = params.get('dir');

    if (directory !== null) {
        const res = await fetch(`/files/${encodeURIComponent(directory)}`);
        const d = await res.json();

        const selectElement = document.getElementById('h1_name');
        selectElement.length = 0;

        d.files.forEach(fullPath => {
            const fileNameWithExt = fullPath.split(/[/\\]/).pop();
            const option = new Option(fileNameWithExt, fileNameWithExt);
            option.dataset.fullname = fullPath;
            selectElement.add(option);
        });
        _totalFileCount = d.files.length;
        document.getElementById('filter-count').textContent = `${_totalFileCount} of ${_totalFileCount}`;

        if (first_run) {
            const fileParam = params.get('file');
            if (fileParam) {
                for (let i = 0; i < selectElement.options.length; i++) {
                    if (selectElement.options[i].value === fileParam) {
                        selectElement.selectedIndex = i;
                        break;
                    }
                }
            }
            reloadFile();
        }
        updateH1Title();
    }
}

async function fetchKeys(panel) {
  panel = panel || panels[0];
  const res = await fetch('/keys');
  const {keys} = await res.json();

  const params = new URLSearchParams(window.location.search);
  const paramName = panel.id === 0 ? 'key' : 'key' + panel.id;
  const keyParam = params.get(paramName);
  const cur = keyParam || (panel.sel.selectedIndex >= 0 ? panel.sel[panel.sel.selectedIndex].value : '');

  panel.sel.innerHTML = keys.map(k => `<option value="${k}">${k}</option>`).join('');

  for (let i = 0; i < panel.sel.options.length; i++) {
    if (panel.sel.options[i].value === cur) {
      panel.sel.selectedIndex = i;
      break;
    }
  }
}

async function fetchAbout() {
  const res = await fetch('/about');
  const data = await res.json();
  _aboutData = data;

  const metaEl = document.getElementById('meta');
  metaEl.textContent = data['title'] || '';
  metaEl.title = data['version'] || '';

  _waveMap = {};
  if (data.data && data.data.mapping) {
    for (const entry of data.data.mapping) {
      _waveMap[entry.number] = entry.value;
    }
  }

  populateAboutPanel(data);
}

function populateAboutPanel(data) {
  const container = document.getElementById('about-info');
  if (!data || (!data.title && !data.data)) { container.innerHTML = '<p style="color:var(--text-dim);font-size:0.8rem;">No system info available.</p>'; return; }

  let html = '';

  // General section
  html += '<div class="about-section"><h4>General</h4><table id="about-table"><tbody>';
  if (data.system_name) html += `<tr><td>File</td><td>${data.system_name}</td></tr>`;
  if (data.title) html += `<tr><td>Title</td><td>${data.title}</td></tr>`;
  if (data.data && data.data.notes) html += `<tr><td>Notes</td><td>${data.data.notes}</td></tr>`;
  if (data.data && data.data.author) html += `<tr><td>Author</td><td>${data.data.author}</td></tr>`;
  if (data.data && data.data.units) html += `<tr><td>Units</td><td>${data.data.units}</td></tr>`;
  if (data.timestamp) html += `<tr title='UTC Timezone'><td>Timestamp</td><td>${data.timestamp.replace(' UTC','')}</td></tr>`;
  if (data.version) html += `<tr><td>Version</td><td>${data.version}</td></tr>`;
  if (data.harvest_version) html += `<tr title='lens_harvest wheel version that parsed this file'><td>Harvest Ver.</td><td>${data.harvest_version}</td></tr>`;
  html += '</tbody></table></div>';

  // System properties
  if (data.data) {
    const d = data.data;
    html += '<div class="about-section"><h4>System Properties</h4><table id="about-table"><tbody>';
    if (d.afocalmode !== undefined) html += `<tr><td>Afocal Mode</td><td>${d.afocalmode}</td></tr>`;
    if (d.number_of_surfaces !== undefined) html += `<tr><td>Surfaces</td><td>${d.number_of_surfaces}</td></tr>`;
    if (d.EFFL !== undefined) html += `<tr><td>EFL</td><td>${parseFloat(d.EFFL).toPrecision(6)}</td></tr>`;
    if (d.WFNO !== undefined) html += `<tr><td>Working F/#</td><td>${parseFloat(d.WFNO).toPrecision(6)}</td></tr>`;
    if (d.TOTR !== undefined) html += `<tr><td>Total Track</td><td>${parseFloat(d.TOTR).toPrecision(6)}</td></tr>`;
    if (d.EPDI !== undefined) html += `<tr><td title='Entrance Pupil Diameter'>EP Dia.</td><td>${parseFloat(d.EPDI).toPrecision(6)}</td></tr>`;
    if (d.ENPP !== undefined) html += `<tr><td title='Entrance Pupil Position (from S1)'>EP Pos.</td><td>${parseFloat(d.ENPP).toPrecision(6)}</td></tr>`;
    if (d.EXPD !== undefined) html += `<tr title='Exit Pupil Diameter'><td>XP Dia.</td><td>${parseFloat(d.EXPD).toPrecision(6)}</td></tr>`;
    if (d.EXPP !== undefined) html += `<tr title='Exit Pupil Position (from SI)'><td>XP Pos.</td><td>${parseFloat(d.EXPP).toPrecision(6)}</td></tr>`;
    if (d.LINV !== undefined) html += `<tr title='Lagrange Invariant'><td>Ж</td><td>${parseFloat(d.LINV).toPrecision(6)}</td></tr>`;
    if (d.object_distance !== undefined) { const od = parseFloat(d.object_distance); html += `<tr><td>Obj. Distance</td><td>${(od === Infinity || isNaN(od) || d.object_distance === 'Infinity') ? '∞' : od.toPrecision(6)}</td></tr>`; }
    if (d.back_workingdistance !== undefined) html += `<tr><td>Img. Distance</td><td>${parseFloat(d.back_workingdistance).toPrecision(6)}</td></tr>`;
    if (d.telecentric !== undefined) html += `<tr><td>Telecentric</td><td>${d.telecentric}</td></tr>`;
    if (d.rayaiming) html += `<tr><td>Ray Aiming</td><td>${d.rayaiming}</td></tr>`;
    if (d.stopsurface !== undefined) html += `<tr><td>Stop Surface</td><td>${d.stopsurface}</td></tr>`;
    if (d.temperature !== undefined) html += `<tr><td>Temperature</td><td>${d.temperature} °C</td></tr>`;
    if (d.pressure !== undefined) html += `<tr><td>Pressure</td><td>${d.pressure} atm</td></tr>`;
    if (d.referenceopd) html += `<tr><td>Reference OPD</td><td>${d.referenceopd}</td></tr>`;
    if (d.materials) {
      html += `<tr><td>Glasses</td><td>${d.materials.glasses || 0}</td></tr>`;
      html += `<tr><td>Mirrors</td><td>${d.materials.mirrors || 0}</td></tr>`;
      if (d.materials.glass_types && d.materials.glass_types.length > 0) html += `<tr><td>Glass Types</td><td>${d.materials.glass_types.join(', ')}</td></tr>`;
    }
    if (d.catalogs && d.catalogs.length > 0) html += `<tr><td>Catalogs</td><td>${d.catalogs.join(', ')}</td></tr>`;
    html += '</tbody></table></div>';

    // Fields
    html += '<div class="about-section"><h4>Fields</h4><table id="about-table"><tbody>';
    if (d.field_type) html += `<tr><td>Type</td><td>${d.field_type}</td></tr>`;
    if (d.number_of_fields !== undefined) html += `<tr><td>Count</td><td>${d.number_of_fields}</td></tr>`;
    if (d.normalization) html += `<tr><td>Normalization</td><td>${d.normalization}</td></tr>`;
    const isRect = d.normalization === 'Rectangular';
    if (d.field_min) {
      html += `<tr><td>Min</td><td>(${parseFloat(d.field_min.x).toFixed(2)}, ${parseFloat(d.field_min.y).toFixed(2)})</td></tr>`;
      if (isRect) {
        if (d.field_min.x_num !== undefined && d.field_min.x_num !== null) html += `<tr><td>Min X Field #</td><td>${d.field_min.x_num}</td></tr>`;
        if (d.field_min.y_num !== undefined && d.field_min.y_num !== null) html += `<tr><td>Min Y Field #</td><td>${d.field_min.y_num}</td></tr>`;
      } else {
        if (d.field_min.x_num !== undefined && d.field_min.x_num !== null) html += `<tr><td>Min Field #</td><td>${d.field_min.x_num}</td></tr>`;
      }
    }
    if (d.field_max) {
      html += `<tr><td>Max</td><td>(${parseFloat(d.field_max.x).toFixed(2)}, ${parseFloat(d.field_max.y).toFixed(2)})</td></tr>`;
      if (isRect) {
        if (d.field_max.x_num !== undefined && d.field_max.x_num !== null) html += `<tr><td>Max X Field #</td><td>${d.field_max.x_num}</td></tr>`;
        if (d.field_max.y_num !== undefined && d.field_max.y_num !== null) html += `<tr><td>Max Y Field #</td><td>${d.field_max.y_num}</td></tr>`;
      } else {
        if (d.field_max.x_num !== undefined && d.field_max.x_num !== null) html += `<tr><td>Max Field #</td><td>${d.field_max.x_num}</td></tr>`;
      }
    }
    html += '</tbody></table></div>';

    // Wavelengths
    html += '<div class="about-section"><h4>Wavelengths</h4><table id="about-table"><tbody>';
    if (d.number_of_wavelengths !== undefined) html += `<tr><td>Count</td><td>${d.number_of_wavelengths}</td></tr>`;
    if (d.primary_wavelength !== undefined) html += `<tr><td>Primary</td><td>${d.primary_wavelength} µm</td></tr>`;
    if (d.minimum_wavelength !== undefined) html += `<tr><td>Min</td><td>${d.minimum_wavelength} µm</td></tr>`;
    if (d.maximum_wavelength !== undefined) html += `<tr><td>Max</td><td>${d.maximum_wavelength} µm</td></tr>`;
    if (d.mapping) {
      for (const m of d.mapping) {
        const isPrimary = d.primary_index !== undefined && m.number === d.primary_index;
        html += `<tr><td>${isPrimary ? '*' : ''}Wave ${m.number}</td><td>${m.value} µm</td></tr>`;
      }
    }
    html += '</tbody></table></div>';
  }

  container.innerHTML = html;
}

async function reloadFile() {
    const f_sel = document.getElementById('h1_name');
    const filename = f_sel.options[f_sel.selectedIndex].dataset.fullname;

    if (filename === undefined) {
        await fetch('load', {method: 'POST'});
    } else {
        await fetch('/load', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: filename })
        });
    }

    await fetchAbout();

    for (const panel of panels) {
        if (panel.container.style.display === 'none') continue;
        await fetchKeys(panel);
        panel.settingsPre.textContent = '';
        loadSelected(panel);
    }
}

// =============================================================================
// Data Parsing & Render Routing
// =============================================================================

async function loadSelected(panel) {
  panel = panel || panels[0];
  const key = panel.sel.value;
  if (!key) return;
  const paramName = panel.id === 0 ? 'key' : 'key' + panel.id;
  updateQueryParam(paramName, key);
  const res = await fetch(`/data/${encodeURIComponent(key)}`);
  const d = await res.json();

  cleanupPanel(panel);
  panel.zmxData = (typeof d === 'string') ? JSON.parse(d) : d;

  parseData(panel);
}

function cleanupPanel(panel) {
  const el = panel.plotEl || panel.viz;
  if (el && el._fullLayout) {
    Plotly.purge(el);
  }
  if (panel.plotEl && panel.plotEl !== panel.viz && panel.plotEl._fullLayout) {
    Plotly.purge(panel.plotEl);
  }
  panel.plotEl = null;
  panel.viz.innerHTML = '';
  panel.viz.style.display = '';
  panel.rawdata.style.display = 'none';
}

function renderSegmented(panel, labels, renderFn) {
  const viz = panel.viz;
  viz.innerHTML = '';
  viz.style.display = 'flex';
  viz.style.flexDirection = 'column';

  const segDiv = document.createElement('div');
  segDiv.className = 'segmented-control';
  const plotContainer = document.createElement('div');
  plotContainer.style.cssText = 'width:100%;flex:1;min-height:0;';

  for (let i = 0; i < labels.length; i++) {
    const btn = document.createElement('button');
    btn.textContent = labels[i];
    if (i === 0) btn.classList.add('active');
    btn.addEventListener('click', () => {
      segDiv.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      plotContainer.innerHTML = '';
      renderFn(i, plotContainer);
      panel.plotEl = plotContainer;
    });
    segDiv.appendChild(btn);
  }

  viz.appendChild(segDiv);
  viz.appendChild(plotContainer);
  panel.plotEl = plotContainer;
  renderFn(0, plotContainer);
}

// Build a plain-text dump of the rendered Plotly traces (line series / heatmaps).
function buildRawData(panel) {
  const el = panel.plotEl || panel.viz;
  if (!el || !el.data || !el.data.length) return '(no plottable data)';

  // render a 2-D array of cells as right-padded, column-aligned text
  function formatGrid(rows) {
    if (!rows.length) return '';
    const cells = rows.map(row => row.map(v => String(v)));
    const ncol = Math.max(...cells.map(r => r.length));
    const widths = new Array(ncol).fill(0);
    for (const row of cells) {
      for (let c = 0; c < row.length; c++) {
        if (row[c].length > widths[c]) widths[c] = row[c].length;
      }
    }
    return cells.map(row =>
      row.map((v, c) => (c === row.length - 1 ? v : v.padEnd(widths[c]))).join('  ')
    ).join('\n');
  }

  const sections = [];
  for (let t = 0; t < el.data.length; t++) {
    const trace = el.data[t];
    const name = trace.name || ('Trace ' + (t + 1));
    let body = '';

    if (trace.type === 'heatmap' && Array.isArray(trace.z)) {
      // z is a 2-D array of rows; emit it as a column-aligned grid.
      body = formatGrid(trace.z);
    } else if (Array.isArray(trace.x) && Array.isArray(trace.y)) {
      const n = Math.min(trace.x.length, trace.y.length);
      const rows = [['X', 'Y']];
      for (let i = 0; i < n; i++) rows.push([trace.x[i], trace.y[i]]);
      body = formatGrid(rows);
    } else {
      continue;
    }
    sections.push(name + '\n' + body);
  }

  return sections.length ? sections.join('\n\n') : '(no plottable data)';
}

// Toggle between the Plotly graph and the raw-data text view for a panel.
function applyRawData(panel) {
  panel.rawdataBtn.style.opacity = panel.rawdataVisible ? '1' : '0.7';
  if (panel.rawdataVisible) {
    let text = panel.headerText || '';
    if (text && !text.endsWith('\n')) text += '\n';
    text += '\n' + buildRawData(panel);
    panel.rawdataPre.textContent = text;
    panel.viz.style.display = 'none';
    panel.rawdata.style.display = 'block';
  } else {
    panel.rawdata.style.display = 'none';
    panel.viz.style.display = '';
    if (panel.viz._fullLayout || (panel.plotEl && panel.plotEl._fullLayout)) {
      setTimeout(() => Plotly.Plots.resize(panel.plotEl || panel.viz), 0);
    }
  }
}

function parseData(panel) {
  panel = panel || panels[0];
  panel.plotEl = panel.viz;
  const d = panel.zmxData[0];
  // a failed analysis serializes as null/[null]; show a notice instead of crashing
  if (d === null || typeof d !== 'object') {
    if (window.disposeLayout) window.disposeLayout(panel);
    panel.viz.style.overflow = 'auto';
    panel.viz.innerHTML = '<p class="desc">No data for this analysis (it failed during extraction).</p>';
    panel.settingsPre.textContent = '';
    return;
  }
  let text = '';
  if ('settings' in d) {
      const maxKeyLength = Math.max(...Object.keys(d.settings).map(key => key.length));
      const maxValLength = Math.max(...Object.values(d.settings).map(val => String(val).length));

      text += "SETTINGS\n";
      for (const [key, value] of Object.entries(d.settings)) {
        text += `${key.padEnd(maxKeyLength, " ")} : ${value}\n`;
      }

      if (d.header.length > 0) {
          text += '\n' + '-'.repeat(maxKeyLength + 3 + maxValLength) + '\n\n';
          text += "HEADER\n";
          for (const line of d.header) {
            text += line + '\n';
          }
          text += '\n';
      }
  }
  panel.settingsPre.textContent = text;
  panel.headerText = text;

  panel.viz.style.overflow = 'hidden';
  if (d.type === 'layout') {
    window._layoutModuleReady.then(() => renderLayout(d, panel));
  } else {
    if (window.disposeLayout) window.disposeLayout(panel);
    if (d.settings && d.settings.window === 'LDE') renderLDE(d, panel);
    else if (d.settings && d.settings.window === 'NCE') renderNCE(d, panel);
    else if (d.type === 'table') renderTable(d, panel);
    else if (d.type === 'line' && d.settings && d.settings.window === 'TransmissionFan' && panel.zmxData.length === 2) {
      renderTransmissionFan(panel.zmxData[0], panel.zmxData[1], panel);
    } else if (d.type === 'line' && d.settings && d.settings.window === 'RMSField' && panel.zmxData.length === 3) {
      renderSegmented(panel, ['Wavefront', 'Spot Radius', 'Strehl Ratio'], (idx, container) => {
        const origViz = panel.viz;
        panel.viz = container;
        renderLine(panel.zmxData[idx], panel);
        panel.viz = origViz;
      });
    } else if (d.type === 'line' && d.settings && d.settings.window === 'RMSFocus' && panel.zmxData.length === 3) {
      renderSegmented(panel, ['Wavefront', 'Spot Radius', 'Strehl Ratio'], (idx, container) => {
        const origViz = panel.viz;
        panel.viz = container;
        renderLine(panel.zmxData[idx], panel);
        panel.viz = origViz;
      });
    } else if (d.type === 'line') renderLine(d, panel);
    else if (d.type === 'grid') {
      const dualWindows = ['FftPsf', 'GeometricImageAnalysis', 'WavefrontMap'];
      if (d.settings && dualWindows.includes(d.settings.window) && panel.zmxData.length === 2) {
        renderHeatmapDual(panel.zmxData[0], panel.zmxData[1], panel);
      } else {
        renderHeatmap(d, panel);
      }
    }
    else if (d.type === 'scatter' && d.settings && d.settings.window === 'GridDistortion' && panel.zmxData.length === 2) {
      renderSegmented(panel, ['On-Axis', 'Full-Field'], (idx, container) => {
        _renderGridDistortion(panel.zmxData[idx], container);
      });
    }
    else if (d.type === 'scatter') renderScatter(d, panel);

    const plotEl = panel.plotEl || panel.viz;
    if (!panel.legendVisible && plotEl._fullLayout) {
      Plotly.relayout(plotEl, { showlegend: false });
    }
    // apply a persistent axis override for this chart type, if one was set on any
    // panel/file; keep panel._persistentAxes in sync so the dialog shows it
    const axKey = panel.sel && panel.sel.value;
    const ax = (axKey && _persistentAxesByKey[axKey]) || null;
    panel._persistentAxes = ax;
    if (ax && plotEl._fullLayout) {
      Plotly.relayout(plotEl, {
        'xaxis.range': [ax.xmin, ax.xmax], 'yaxis.range': [ax.ymin, ax.ymax],
        'xaxis.autorange': false, 'yaxis.autorange': false
      });
    }
  }

  // if the raw-data view is active, refresh it for the newly loaded analysis
  if (panel.rawdataVisible) applyRawData(panel);
}

// =============================================================================
// Render: Table
// =============================================================================

function renderTable(d, panel) {
    panel = panel || panels[0];
    const viz = panel.viz;

    let html = '';
    let threshold = 1e-2;
    let sigdig = 6;

    for (let i = 0; i < d.data.length; i++) {
        if (d.data[i].length === 1) continue;

        const dd = JSON.parse(d.data[i]);
        if (JSON.stringify(Object.keys(dd[0])) === JSON.stringify(Object.keys(dd[1]))) {
            const cols = Object.keys(dd[0]);
            const hasZn = cols.includes('Zn');
            html += `<table${hasZn ? ' class="zernike-table"' : ''}><thead><tr>`;
            if (!hasZn) html += `<th>#</th>`;
            for (const col of cols) {
                html += `<th>${col}</th>`;
            }
            html += `</tr></thead><tbody>`;
            for (let j = 0; j < dd.length; j++) {
                html += `<tr>`;
                if (!hasZn) html += `<td>${j}</td>`;
                for (const [, val] of Object.entries(dd[j])) {
                    html += `<td class='fc'>${val}</td>`;
                }
                html += `</tr>`;
            }
            html += `</tbody></table>`;
        } else {
            sigdig = 10;
            html = `<table><thead><tr><th>Key</th><th>Value</th></tr></thead><tbody>`;
            for (const el of dd) {
                const [key, val] = Object.entries(el)[0];
                html += `<tr><td>${key}</td><td class='fc'>${val}</td></tr>`;
            }
            html += `</tbody></table>`;
        }

        if (i < d.data.length - 1) {
            html += '<br><hr><br>';
        }
    }

    if (panel.sel.value === 'sag_table') {
        viz.style.overflow = 'hidden';
        viz.innerHTML = `<div class="sag-table-wrap">${html}</div>`;
    } else {
        viz.style.overflow = 'auto';
        viz.innerHTML = html;
    }

    const table = viz.querySelector('table');
    if (table) {
        const numCols = table.querySelector('tr').children.length;
        const availW = viz.clientWidth;
        const colW = availW / numCols;
        const charsPerCol = Math.floor(colW / 8) - 2;
        const adaptedSigdig = Math.max(2, Math.min(sigdig, charsPerCol - 4));

        viz.querySelectorAll('td.fc').forEach(td => {
            let val = parseFloat(td.textContent);
            if (!isNaN(val)) {
                val = Math.abs(val) < threshold && val !== 0 ? val.toExponential(adaptedSigdig - 2) : val.toFixed(adaptedSigdig);
                if (Math.abs(val) < 1e-15) { val = parseFloat('0').toFixed(adaptedSigdig); }
                td.textContent = val;
            }
        });
    }
}

// =============================================================================
// Render: LDE Table
// =============================================================================

function renderLDE(d, panel) {
    panel = panel || panels[0];
    const viz = panel.viz;
    const rows = JSON.parse(d.data[0]);
    const stopSurf = _aboutData && _aboutData.data ? _aboutData.data.stopsurface : null;

    const columns = ['type', 'comment', 'radius', 'thickness', 'material', 'coating', 'semi_diameter', 'chip_zone', 'mech_semi_diameter', 'conic', 'tce'];
    const headers = ['Surface', 'Type', 'Comment', 'Radius', 'Thickness', 'Material', 'Coating', 'Semi-Dia', 'Chip Zone', 'Mech Semi-Dia', 'Conic', 'TCE x 1E-6'];

    // Global coordinate columns (gx/gy/gz/gl/gm/gn) only exist in newer pkl files;
    // add them after TCE only when at least one row carries them.
    const globalCols = ['gx', 'gy', 'gz', 'gl', 'gm', 'gn'];
    const globalHeaders = ['Global X', 'Global Y', 'Global Z', 'Global α', 'Global β', 'Global γ'];
    const hasGlobal = rows.some(r => globalCols.some(c => r[c] !== undefined));
    if (hasGlobal) {
        columns.push(...globalCols);
        headers.push(...globalHeaders);
    }

    let html = `<table class="lde-table" tabindex="0"><thead><tr>`;
    for (const h of headers) html += `<th>${h}</th>`;
    html += `</tr></thead><tbody>`;

    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const bgColor = row.color || '';
        const style = bgColor ? ` style="background-color:${bgColor}"` : '';
        html += `<tr data-surf="${i}"${style}>`;

        let surfLabel = i.toString();
        if (i === 0) surfLabel = '0 (OBJ)';
        else if (i === rows.length - 1) surfLabel = `${i} (IMA)`;
        else if (i === stopSurf) surfLabel = `${i} (STOP)`;
        html += `<td>${surfLabel}</td>`;

        for (const col of columns) {
            let val = row[col];
            if (val === null || val === undefined) val = '-';
            else if (typeof val === 'number') {
                if (col === 'tce') val = val === 0 ? '0.00000' : val.toFixed(5);
                else val = Math.abs(val) > 1e8 ? 'Infinity' : val.toFixed(5);
            }
            html += `<td>${val}</td>`;
        }
        html += `</tr>`;
    }
    html += `</tbody></table>`;

    viz.style.overflow = 'auto';
    viz.innerHTML = html;

    const table = viz.querySelector('.lde-table');
    let activeRow = -1;

    function setActiveRow(idx) {
        if (idx < 0 || idx >= rows.length) return;
        const prevRow = table.querySelector('tr.lde-active');
        if (prevRow) prevRow.classList.remove('lde-active');
        activeRow = idx;
        const newRow = table.querySelector(`tr[data-surf="${idx}"]`);
        if (newRow) {
            newRow.classList.add('lde-active');
            newRow.scrollIntoView({ block: 'nearest' });
        }
        highlightLayoutSurface(idx);
    }

    table.querySelectorAll('tbody tr').forEach(tr => {
        tr.addEventListener('click', () => {
            setActiveRow(parseInt(tr.dataset.surf));
            table.focus();
        });
    });

    table.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (activeRow < rows.length - 1) setActiveRow(activeRow + 1);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (activeRow > 0) setActiveRow(activeRow - 1);
        }
    });
}

function renderNCE(d, panel) {
    panel = panel || panels[0];
    const viz = panel.viz;
    const rows = JSON.parse(d.data[0]);

    // NCE rows are ragged: the first 10 columns are common to every object, then
    // type-specific columns vary. pandas pads the union with null, so every row
    // carries every key -- build the column list from the union of row keys.
    const COMMON = ['type', 'comment', 'ref_object', 'inside_of',
                    'x_position', 'y_position', 'z_position',
                    'tilt_about_x', 'tilt_about_y', 'tilt_about_z'];
    const LABELS = {
        type: 'Object Type', comment: 'Comment', ref_object: 'Ref Object', inside_of: 'Inside Of',
        x_position: 'X Position', y_position: 'Y Position', z_position: 'Z Position',
        tilt_about_x: 'Tilt About X', tilt_about_y: 'Tilt About Y', tilt_about_z: 'Tilt About Z',
        material: 'Material', radius_1: 'Radius 1', clear_edge_1: 'Clear/Edge 1',
        thickness: 'Thickness', radius_2: 'Radius 2', clear_edge_2: 'Clear/Edge 2',
        layout_rays: '# Layout Rays', analysis_rays: '# Analysis Rays', power_watts: 'Power(Watts)',
        x_half_width: 'X Half Width', y_half_width: 'Y Half Width',
        x_pixels: '# X Pixels', y_pixels: '# Y Pixels',
    };

    // collect every column actually present (preserve first-seen order), minus bookkeeping keys
    const seen = new Set();
    const extras = [];
    for (const row of rows) {
        for (const k of Object.keys(row)) {
            if (k === 'object' || k === 'color' || COMMON.includes(k)) continue;
            if (!seen.has(k)) { seen.add(k); extras.push(k); }
        }
    }
    const columns = [...COMMON, ...extras];
    const headers = ['Object', ...columns.map(c => LABELS[c] || c)];

    let html = `<table class="lde-table" tabindex="0"><thead><tr>`;
    for (const h of headers) html += `<th>${h}</th>`;
    html += `</tr></thead><tbody>`;

    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const bgColor = row.color || '';
        const style = bgColor ? ` style="background-color:${bgColor}"` : '';
        html += `<tr data-surf="${i}"${style}>`;

        html += `<td>${row.object != null ? row.object : i + 1}</td>`;

        for (const col of columns) {
            let val = row[col];
            if (val === null || val === undefined) val = '-';
            else if (typeof val === 'number') {
                val = Math.abs(val) > 1e8 ? 'Infinity' : val.toFixed(5);
            }
            html += `<td>${val}</td>`;
        }
        html += `</tr>`;
    }
    html += `</tbody></table>`;

    viz.style.overflow = 'auto';
    viz.innerHTML = html;

    const table = viz.querySelector('.lde-table');
    let activeRow = -1;

    function setActiveRow(idx) {
        if (idx < 0 || idx >= rows.length) return;
        const prevRow = table.querySelector('tr.lde-active');
        if (prevRow) prevRow.classList.remove('lde-active');
        activeRow = idx;
        const newRow = table.querySelector(`tr[data-surf="${idx}"]`);
        if (newRow) {
            newRow.classList.add('lde-active');
            newRow.scrollIntoView({ block: 'nearest' });
        }
        const objNum = rows[idx] && rows[idx].object != null ? rows[idx].object : idx + 1;
        highlightLayoutObject(objNum);
    }

    table.querySelectorAll('tbody tr').forEach(tr => {
        tr.addEventListener('click', () => {
            setActiveRow(parseInt(tr.dataset.surf));
            table.focus();
        });
    });

    table.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (activeRow < rows.length - 1) setActiveRow(activeRow + 1);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (activeRow > 0) setActiveRow(activeRow - 1);
        }
    });
}

function highlightLayoutSurface(surfIdx) {
    const layoutPanel = panels.find(p => p._layoutApp && p.container.style.display !== 'none');
    if (!layoutPanel) return;
    const { crossGroup, meshGroup, scene, camera, renderer, controls, surfaceGroups, objectColors } = layoutPanel._layoutApp;
    const defaultColor = getThemeColors().layoutCross;
    const highlightColor = 0xff8000;
    const defaultMeshColor = getThemeColors().layoutMesh;
    // a non-highlighted mesh resets to its own NSC object color (if any), else default
    const restColor = (i) => (objectColors && objectColors[i]) || defaultMeshColor;

    // Match each mesh group to its surface number. Prefer the explicit per-group
    // surface array emitted by the layout; fall back to the positional i+1
    // assumption (surfaces 1..N, skipping S0) for older .pkl files without it.
    const matches = (i) => surfaceGroups ? surfaceGroups[i] === surfIdx : (i + 1 === surfIdx);

    crossGroup.children.forEach((child, i) => {
        child.material.color.set(matches(i) ? highlightColor : defaultColor);
    });
    meshGroup.children.forEach((child, i) => {
        child.material.color.set(matches(i) ? highlightColor : restColor(i));
    });

    renderer.render(scene, camera);
}

function highlightLayoutObject(objNum) {
    const layoutPanel = panels.find(p => p._layoutApp && p.container.style.display !== 'none');
    if (!layoutPanel) return;
    const { crossGroup, meshGroup, scene, camera, renderer, objects, objectColors } = layoutPanel._layoutApp;
    if (!objects) return;     // layout JSON has no object mapping (older .pkl)
    const defaultColor = getThemeColors().layoutCross;
    const highlightColor = 0xff8000;
    const defaultMeshColor = getThemeColors().layoutMesh;
    // a non-highlighted mesh resets to its own NSC object color (if any), else default
    const restColor = (i) => (objectColors && objectColors[i]) || defaultMeshColor;

    // mesh/cross children are parallel to `objects`, which holds the NSC object
    // number for each mesh group (one NCE object can span several mesh groups)
    crossGroup.children.forEach((child, i) => {
        child.material.color.set(objects[i] === objNum ? highlightColor : defaultColor);
    });
    meshGroup.children.forEach((child, i) => {
        child.material.color.set(objects[i] === objNum ? highlightColor : restColor(i));
    });

    renderer.render(scene, camera);
}

// =============================================================================
// Plotly Theme Helper
// =============================================================================

function plotlyTheme() {
    const c = getThemeColors();
    return { paper_bgcolor: c.bg, plot_bgcolor: c.panel, font: { color: c.text }, legend: { font: { color: c.text } }, colorway: TRACE_COLORS };
}

// =============================================================================
// Render: Line Plots
// =============================================================================

function deinterleave(ydata, n) {
  const len = ydata.length / n;
  const result = new Array(ydata.length);
  for (let i = 0; i < ydata.length; i++) {
    const series = i % n;
    const pos = Math.floor(i / n);
    result[series * len + pos] = ydata[i];
  }
  return result;
}

const TRACE_COLORS = [
  '#0000FF', '#00FF00', '#FF0000', '#BFBF00',
  '#FF00FF', '#00FFFF', '#7F7FFF', '#7FFF7F',
  '#7F007F', '#FF003F', '#7F00FF', '#FF7F7F',
  '#137EEB', '#2785D7', '#3A8BC4', '#4E92B0',
  '#62989C', '#759F89', '#89A575', '#9CAC62',
  '#B0B24E', '#C4B93A', '#D7BF27', '#EBC613'
];

function renderLine(d, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  if (d.description) viz.innerHTML = `<p class="desc">${d.description}</p>`;

  if (d.settings && d.settings.window === 'FieldCurvatureAndDistortion') { renderFieldCurvature(d, panel); return; }
  if (d.settings && d.settings.window === 'RelativeIllumination') { renderRelativeIllumination(d, panel); return; }
  if (d.settings && ['RayFan', 'OpticalPathFan'].includes(d.settings.window)) { renderFanPlot(d, panel); return; }

  const traces = [];
  const PLOTLY_COLORS = TRACE_COLORS;
  let colorIdx = 0;

  if (d.data.length > 0) {
      for (let i = 0; i < d.data.length; i++) {
        const xdata = d.data[i].xdata;
        const n = xdata.length;
        const cols = d.data[i].ydata.length / n;
        const ydata = deinterleave(d.data[i].ydata, cols);

        for (let j = 0; j < cols; j++) {
            const lineCfg = { shape: 'spline', smoothing: 0.5 };
            const isLongAb = d.settings && d.settings.window === 'LongitudinalAberration';
            const isYYBar = d.settings && d.settings.window === 'YYBar';
            const label = (d.data[i].description + ' ' + (d.data[i].series_labels[j] || '')).toLowerCase();
            const isMtf = d.settings && ['FftMtf', 'FftThroughFocusMtf'].includes(d.settings.window);
            const isRMS = d.settings && (d.settings.window === 'RMSField' || d.settings.window === 'RMSFocus');
            const isReference = (isMtf && label.includes('diffraction limit'))
                || (isRMS && label.includes('poly'));

            if (isReference) {
                lineCfg.color = getTheme() === 'light' ? '#000000' : '#ffffff';
                if (d.data[i].series_labels[j] === 'Sagittal') lineCfg.dash = 'dash';
            } else if (d.settings && ['OpticalPathFan', 'RayFan'].includes(d.settings.window)) {
                lineCfg.color = PLOTLY_COLORS[j % PLOTLY_COLORS.length];
                if (d.data[i].description.includes('Sagittal')) lineCfg.dash = 'dash';
            } else if (isMtf) {
                lineCfg.color = PLOTLY_COLORS[colorIdx % PLOTLY_COLORS.length];
                if (d.data[i].series_labels[j] === 'Sagittal') lineCfg.dash = 'dash';
            } else {
                lineCfg.color = PLOTLY_COLORS[colorIdx % PLOTLY_COLORS.length];
                colorIdx++;
            }

            if (isYYBar) {
                const sliceY = ydata.slice(j * n, (j + 1) * n);
                for (let seg = 0; seg < n - 1; seg++) {
                    traces.push({
                        x: [xdata[seg], xdata[seg + 1]], y: [sliceY[seg], sliceY[seg + 1]],
                        mode: 'lines', type: 'scatter',
                        line: { color: PLOTLY_COLORS[seg % 2] },
                        name: d.data[i].description + ' : ' + d.data[i].series_labels[j],
                        showlegend: seg === 0
                    });
                }
                traces.push({
                    x: xdata, y: sliceY, mode: 'markers+text', type: 'scatter',
                    marker: { size: 6, color: getThemeColors().text },
                    text: xdata.map((_, idx) => String(idx + 1)),
                    textposition: 'top center', textfont: { size: 9, color: getThemeColors().muted },
                    hovertemplate: 'Surface %{text}<br>YBar: %{x}<br>Y: %{y}<extra></extra>',
                    name: d.data[i].description + ' : ' + d.data[i].series_labels[j] + ' (pts)',
                    showlegend: false
                });
            } else {
                traces.push({
                    x: isLongAb ? ydata.slice(j * n, (j + 1) * n) : xdata,
                    y: isLongAb ? xdata : ydata.slice(j * n, (j + 1) * n),
                    mode: 'lines', type: 'scatter', line: lineCfg,
                    name: d.data[i].description + ' : ' + d.data[i].series_labels[j]
                });
            }
        }
        const isMtfOuter = d.settings && ['FftMtf', 'FftThroughFocusMtf'].includes(d.settings.window);
        const labelOuter = (d.data[i].description + ' ' + (d.data[i].series_labels[0] || '')).toLowerCase();
        const isRefOuter = isMtfOuter && labelOuter.includes('diffraction limit');
        if (isMtfOuter && !isRefOuter) colorIdx++;
      }

      let yaxisCfg = { title: d.data[0].series_labels[0], color: getThemeColors().muted, autorange: true };
      if (d.settings && ['FftThroughFocusMtf', 'FftMtf'].includes(d.settings.window)) {
        yaxisCfg = { title: 'Modulus of the OTF', color: getThemeColors().muted, autorange: false, range: [0, 1] };
      } else if (d.settings && d.settings.window === 'FocalShiftDiagram') {
        let maxAbs = 0;
        for (const t of traces) for (const v of t.y) { if (Math.abs(v) > maxAbs) maxAbs = Math.abs(v); }
        yaxisCfg = { title: d.data[0].series_labels[0], color: getThemeColors().muted, autorange: false, range: [-maxAbs, maxAbs] };
      } else if (d.settings && d.settings.window === 'LongitudinalAberration') {
        yaxisCfg = { title: 'Rel. Pupil', color: getThemeColors().muted, autorange: false, range: [0, 1] };
      } else if (d.settings && d.settings.window === 'RayFan') {
        yaxisCfg.title = 'Epsilon';
      } else if (d.settings && d.settings.window === 'OpticalPathFan') {
        yaxisCfg.title = 'Waves';
      }

      let xaxisCfg = { title: d.data[0].xlabel, color: getThemeColors().muted, autorange: true };
      if (d.settings && d.settings.window === 'LongitudinalAberration') {
        let maxAbs = 0;
        for (const t of traces) for (const v of t.x) { if (Math.abs(v) > maxAbs) maxAbs = Math.abs(v); }
        xaxisCfg = { title: 'Millimeters', color: getThemeColors().muted, autorange: false, range: [-maxAbs, maxAbs] };
      }

      const layout = {
        xaxis: xaxisCfg, yaxis: yaxisCfg,
        ...plotlyTheme(),
      };

      if (d.settings && d.settings.window === 'YYBar') {
        layout.showlegend = false;
        layout.xaxis.title = 'Y-Bar';
        layout.yaxis.title = 'Y';
      }

      Plotly.newPlot(viz, traces, layout, {responsive: true, displaylogo: false});

      if (d.settings && d.settings.window === 'YYBar') {
        requestAnimationFrame(() => _spotEnforceAspect(viz));
        viz.on('plotly_relayout', () => { requestAnimationFrame(() => _spotEnforceAspect(viz)); });
      }
  } else {
    viz.innerHTML = '<br><br><h1>No data to display</h1>';
  }
}

function renderFieldCurvature(d, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  const PLOTLY_COLORS = TRACE_COLORS;
  const curvatureTraces = [];
  const distortionTraces = [];

  for (let i = 0; i < d.data.length; i++) {
    const xdata = d.data[i].xdata;
    const n = xdata.length;
    const cols = d.data[i].ydata.length / n;
    const ydata = deinterleave(d.data[i].ydata, cols);
    const color = PLOTLY_COLORS[i % PLOTLY_COLORS.length];

    for (let j = 0; j < cols; j++) {
      const label = d.data[i].series_labels[j];
      if (label === 'Real Height' || label === 'Ref. Height') continue;

      const seriesY = ydata.slice(j * n, (j + 1) * n);
      const traceName = d.data[i].description + ' : ' + label;

      if (label === 'Tan Shift' || label === 'Sag Shift') {
        curvatureTraces.push({ x: seriesY, y: xdata, mode: 'lines', type: 'scatter',
          line: { shape: 'spline', smoothing: 0.5, color, dash: label === 'Sag Shift' ? 'dot' : 'solid' },
          name: traceName, xaxis: 'x', yaxis: 'y' });
      } else if (label === 'Distortion') {
        distortionTraces.push({ x: seriesY, y: xdata, mode: 'lines', type: 'scatter',
          line: { shape: 'spline', smoothing: 0.5, color },
          name: traceName, xaxis: 'x2', yaxis: 'y2' });
      }
    }
  }

  function symRange(traces) {
    let maxAbs = 0;
    for (const t of traces) for (const v of t.x) { if (Math.abs(v) > maxAbs) maxAbs = Math.abs(v); }
    return [-maxAbs, maxAbs];
  }

  const layout = {
    grid: { rows: 1, columns: 2, pattern: 'independent' },
    xaxis: { title: 'Focus (Shift)', color: getThemeColors().muted, range: symRange(curvatureTraces) },
    yaxis: { title: d.data[0].xlabel, color: getThemeColors().muted, autorange: true },
    xaxis2: { title: 'Distortion', color: getThemeColors().muted, range: symRange(distortionTraces) },
    yaxis2: { title: d.data[0].xlabel, color: getThemeColors().muted, autorange: true },
    ...plotlyTheme(),
  };

  Plotly.newPlot(viz, curvatureTraces.concat(distortionTraces), layout, { responsive: true, displaylogo: false });
}

function renderRelativeIllumination(d, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  const traces = [];

  for (let i = 0; i < d.data.length; i++) {
    const xdata = d.data[i].xdata;
    const n = xdata.length;
    const cols = d.data[i].ydata.length / n;
    const ydata = deinterleave(d.data[i].ydata, cols);

    for (let j = 0; j < cols; j++) {
      const label = d.data[i].series_labels[j];
      const seriesY = ydata.slice(j * n, (j + 1) * n);
      traces.push({ x: xdata, y: seriesY, mode: 'lines', type: 'scatter',
        line: { shape: 'spline', smoothing: 0.5 }, name: label,
        yaxis: label === 'Effective F/#' ? 'y2' : 'y' });
    }
  }

  const layout = {
    xaxis: { title: d.data[0].xlabel, color: getThemeColors().muted, autorange: true },
    yaxis: { title: 'Rel. Ill', color: getThemeColors().muted, autorange: true },
    yaxis2: { title: 'Effective F/#', color: getThemeColors().muted, autorange: true, overlaying: 'y', side: 'right', showgrid: false },
    ...plotlyTheme(),
  };

  Plotly.newPlot(viz, traces, layout, { responsive: true, displaylogo: false });
}

function renderFanPlot(d, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  const PLOTLY_COLORS = TRACE_COLORS;

  const fields = [];
  for (let i = 0; i < d.data.length; i++) {
    const m = d.data[i].description.match(/field number (\d+)/);
    if (m) { const fNum = parseInt(m[1]); if (!fields.includes(fNum)) fields.push(fNum); }
  }

  viz.innerHTML = '';
  viz.style.display = 'flex';
  viz.style.flexDirection = 'column';

  const segDiv = document.createElement('div');
  segDiv.className = 'segmented-control';
  for (let i = 0; i < fields.length; i++) {
    const btn = document.createElement('button');
    btn.textContent = fields[i];
    if (i === 0) btn.classList.add('active');
    btn.addEventListener('click', () => {
      segDiv.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      _renderFanForField(d, fields[i], plotContainer, PLOTLY_COLORS);
    });
    segDiv.appendChild(btn);
  }
  viz.appendChild(segDiv);

  const plotContainer = document.createElement('div');
  plotContainer.style.cssText = 'width:100%;flex:1;min-height:0;';
  viz.appendChild(plotContainer);
  panel.plotEl = plotContainer;

  _renderFanForField(d, fields[0], plotContainer, PLOTLY_COLORS);
}

function _renderFanForField(d, fieldNum, container, PLOTLY_COLORS) {
  const tanTraces = [];
  const sagTraces = [];
  const fieldPattern = `field number ${fieldNum}`;

  for (let i = 0; i < d.data.length; i++) {
    if (!d.data[i].description.includes(fieldPattern)) continue;
    const xdata = d.data[i].xdata;
    const n = xdata.length;
    const cols = d.data[i].ydata.length / n;
    const ydata = deinterleave(d.data[i].ydata, cols);
    const isTan = d.data[i].description.includes('Tangential fan');

    for (let j = 0; j < cols; j++) {
      const trace = {
        x: xdata, y: ydata.slice(j * n, (j + 1) * n),
        mode: 'lines', type: 'scatter',
        line: { shape: 'spline', smoothing: 0.5, color: PLOTLY_COLORS[j % PLOTLY_COLORS.length] },
        name: d.data[i].series_labels[j], legendgroup: d.data[i].series_labels[j],
        showlegend: isTan, xaxis: isTan ? 'x' : 'x2', yaxis: isTan ? 'y' : 'y2'
      };
      if (isTan) tanTraces.push(trace); else sagTraces.push(trace);
    }
  }

  const yTitle = d.settings.window === 'OpticalPathFan' ? 'Waves' : 'Epsilon';
  let maxAbs = 0;
  for (const t of tanTraces.concat(sagTraces)) for (const v of t.y) { if (Math.abs(v) > maxAbs) maxAbs = Math.abs(v); }

  const layout = {
    grid: { rows: 1, columns: 2, pattern: 'independent' },
    xaxis: { title: 'Py', color: getThemeColors().muted, range: [-1, 1] },
    yaxis: { title: yTitle, color: getThemeColors().muted, range: [-maxAbs, maxAbs] },
    xaxis2: { title: 'Px', color: getThemeColors().muted, range: [-1, 1] },
    yaxis2: { title: yTitle, color: getThemeColors().muted, range: [-maxAbs, maxAbs] },
    ...plotlyTheme(),
    annotations: [
      { text: 'Tangential', xref: 'x domain', yref: 'y domain', x: 0.5, y: 1.05, showarrow: false, font: { color: getThemeColors().text } },
      { text: 'Sagittal', xref: 'x2 domain', yref: 'y2 domain', x: 0.5, y: 1.05, showarrow: false, font: { color: getThemeColors().text } }
    ]
  };

  Plotly.newPlot(container, tanTraces.concat(sagTraces), layout, { responsive: true, displaylogo: false });
}

// =============================================================================
// Render: Transmission Fan (dual panel: on-axis / full-field)
// =============================================================================

function renderTransmissionFan(dOnAxis, dFullField, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  const PLOTLY_COLORS = TRACE_COLORS;

  viz.innerHTML = '';

  const leftTraces = [];
  const rightTraces = [];

  for (const item of dOnAxis.data) {
    const xdata = item.xdata;
    const n = xdata.length;
    const cols = item.ydata.length / n;
    const ydata = deinterleave(item.ydata, cols);
    for (let j = 0; j < cols; j++) {
      leftTraces.push({
        x: xdata, y: ydata.slice(j * n, (j + 1) * n),
        mode: 'lines', type: 'scatter',
        line: { shape: 'spline', smoothing: 0.5, color: PLOTLY_COLORS[j % PLOTLY_COLORS.length] },
        name: item.series_labels[j], legendgroup: item.series_labels[j],
        showlegend: true, xaxis: 'x', yaxis: 'y'
      });
    }
  }

  for (const item of dFullField.data) {
    const xdata = item.xdata;
    const n = xdata.length;
    const cols = item.ydata.length / n;
    const ydata = deinterleave(item.ydata, cols);
    for (let j = 0; j < cols; j++) {
      rightTraces.push({
        x: xdata, y: ydata.slice(j * n, (j + 1) * n),
        mode: 'lines', type: 'scatter',
        line: { shape: 'spline', smoothing: 0.5, color: PLOTLY_COLORS[j % PLOTLY_COLORS.length] },
        name: item.series_labels[j], legendgroup: item.series_labels[j],
        showlegend: false, xaxis: 'x2', yaxis: 'y2'
      });
    }
  }

  const layout = {
    grid: { rows: 1, columns: 2, pattern: 'independent' },
    xaxis: { title: 'Pupil Coordinate', color: getThemeColors().muted, range: [-1, 1] },
    yaxis: { title: 'Transmission', color: getThemeColors().muted, range: [0, 1] },
    xaxis2: { title: 'Pupil Coordinate', color: getThemeColors().muted, range: [-1, 1] },
    yaxis2: { title: 'Transmission', color: getThemeColors().muted, range: [0, 1] },
    ...plotlyTheme(),
    annotations: [
      { text: 'On-Axis', xref: 'x domain', yref: 'y domain', x: 0.5, y: 1.05, showarrow: false, font: { color: getThemeColors().text } },
      { text: 'Full-Field', xref: 'x2 domain', yref: 'y2 domain', x: 0.5, y: 1.05, showarrow: false, font: { color: getThemeColors().text } }
    ]
  };

  Plotly.newPlot(viz, leftTraces.concat(rightTraces), layout, { responsive: true, displaylogo: false });
}

// =============================================================================
// Render: Scatter Plots (Spot, Footprint, Grid Distortion)
// =============================================================================

function renderScatter(d, panel) {
    panel = panel || panels[0];
    const viz = panel.viz;
    switch (d.settings.window) {
        case 'GridDistortion': _renderGridDistortion(d, viz); break;
        case 'FootprintDiagram': _renderFootprint(d, 0, viz); break;
        case 'SpotDiagram': _renderSpot(d, viz); panel.plotEl = viz; break;
        case 'SpotDiagramThroughFocus': _renderSpotThroughFocus(d, viz); panel.plotEl = viz.lastElementChild; break;
    }
}

function _renderGridDistortion(d, viz) {
    const dd = JSON.parse(d.data[0]);
    const traces = [];
    const byI = {}, byJ = {};
    for (const pt of dd) {
        if (!byI[pt.i]) byI[pt.i] = [];
        if (!byJ[pt.j]) byJ[pt.j] = [];
        byI[pt.i].push(pt);
        byJ[pt.j].push(pt);
    }
    for (const key in byI) byI[key].sort((a, b) => a.j - b.j);
    for (const key in byJ) byJ[key].sort((a, b) => a.i - b.i);

    const gridColor = getThemeColors().muted;
    for (const key in byI) {
        const pts = byI[key];
        traces.push({ x: pts.map(p => p.predicted_x), y: pts.map(p => p.predicted_y),
            mode: 'lines', type: 'scatter', line: { color: gridColor, width: 1 }, hoverinfo: 'x+y', showlegend: false });
    }
    for (const key in byJ) {
        const pts = byJ[key];
        traces.push({ x: pts.map(p => p.predicted_x), y: pts.map(p => p.predicted_y),
            mode: 'lines', type: 'scatter', line: { color: gridColor, width: 1 }, hoverinfo: 'x+y', showlegend: false });
    }
    traces.push({ x: dd.map(p => p.real_x), y: dd.map(p => p.real_y),
        mode: 'markers', type: 'scatter', marker: { symbol: 'x', size: 8, color: '#1f77b4' }, name: 'Real' });

    const layout = {
        xaxis: { autorange: true, showgrid: false, zeroline: false, showticklabels: false, ticks: '' },
        yaxis: { autorange: true, scaleanchor: 'x', scaleratio: 1, showgrid: false, zeroline: false, showticklabels: false, ticks: '' },
        ...plotlyTheme(), paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)',
    };
    Plotly.newPlot(viz, traces, layout, { responsive: true, displaylogo: false });
}

function _renderFootprint(d, wave = 0, viz) {
    const PLOTLY_COLORS = TRACE_COLORS;
    const traces = [];
    let colorIdx = 0;

    for (const s of d.data.footprint) {
        if (wave !== 0 && s.wave !== wave) continue;
        const coords = s.coordinates;
        if (coords.length === 0) continue;
        traces.push({ x: coords.map(c => c[0]), y: coords.map(c => c[1]),
            mode: 'markers', type: 'scatter',
            marker: { size: 2, color: PLOTLY_COLORS[colorIdx % PLOTLY_COLORS.length] },
            name: `Field ${s.field}` });
        colorIdx++;
    }

    for (let i = 0; i < d.data.aperture.length; i++) {
        const a = d.data.aperture[i];
        traces.push({ x: a[0], y: a[1], mode: 'lines', type: 'scatter',
            line: { color: getThemeColors().muted, shape: 'linear', width: 1 },
            name: `Aperture ${i + 1}`, showlegend: false });
    }

    const layout = {
        xaxis: { title: 'X', color: getThemeColors().muted, autorange: true },
        yaxis: { title: 'Y', color: getThemeColors().muted, autorange: true },
        ...plotlyTheme(),
    };
    Plotly.newPlot(viz, traces, layout, { responsive: true, displaylogo: false });
    requestAnimationFrame(() => _spotEnforceAspect(viz));
    viz.on('plotly_relayout', () => { requestAnimationFrame(() => _spotEnforceAspect(viz)); });
}

function _renderSpot(d, viz) {
    const dd = JSON.parse(d.data[0]);
    const max_w = dd.reduce((max, obj) => obj.wave > max ? obj.wave : max, 0);
    const x = {}, y = {};
    for (let i = 1; i <= max_w; i++) { x[i] = []; y[i] = []; }
    for (const row of dd) { x[row.wave].push(row.REAX); y[row.wave].push(row.REAY); }

    const traces = [];
    for (let i = 1; i <= max_w; i++) {
        traces.push({ x: x[i], y: y[i], mode: 'markers', type: 'scatter',
            name: _waveMap[i] !== undefined ? `Wavelength: ${_waveMap[i]}` : `Wave ${i}` });
    }

    const layout = {
        xaxis: { title: 'x', color: getThemeColors().muted, autorange: true },
        yaxis: { title: 'y', color: getThemeColors().muted, autorange: true },
        ...plotlyTheme(),
    };
    Plotly.newPlot(viz, traces, layout, {responsive: true, displaylogo: false});
    requestAnimationFrame(() => _spotEnforceAspect(viz));
    viz.on('plotly_relayout', () => { requestAnimationFrame(() => _spotEnforceAspect(viz)); });
}

function _renderSpotThroughFocus(d, viz) {
    viz.innerHTML = '';
    let currentRange = null;

    const segDiv = document.createElement('div');
    segDiv.className = 'segmented-control';
    for (let i = 0; i < 5; i++) {
        const btn = document.createElement('button');
        btn.textContent = i + 1;
        if (i === 0) btn.classList.add('active');
        btn.addEventListener('click', () => {
            segDiv.querySelectorAll('button').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            if (plotContainer._fullLayout) {
                currentRange = { x: plotContainer._fullLayout.xaxis.range.slice(), y: plotContainer._fullLayout.yaxis.range.slice() };
            }
            _renderSpotAtIndex(d, i, plotContainer, currentRange);
        });
        segDiv.appendChild(btn);
    }
    viz.appendChild(segDiv);

    const plotContainer = document.createElement('div');
    plotContainer.style.cssText = 'width:100%;flex:1;min-height:0;';
    viz.appendChild(plotContainer);
    viz.style.display = 'flex';
    viz.style.flexDirection = 'column';

    _renderSpotAtIndex(d, 0, plotContainer, null);
}

function _renderSpotAtIndex(d, idx, container, rangeOverride) {
    const raw = Array.isArray(d.data[idx]) ? d.data[idx][0] : d.data[idx];
    const dd = JSON.parse(raw);
    const max_w = dd.reduce((max, obj) => obj.wave > max ? obj.wave : max, 0);
    const x = {}, y = {};
    for (let i = 1; i <= max_w; i++) { x[i] = []; y[i] = []; }
    for (const row of dd) { x[row.wave].push(row.REAX); y[row.wave].push(row.REAY); }

    const traces = [];
    for (let i = 1; i <= max_w; i++) {
        traces.push({ x: x[i], y: y[i], mode: 'markers', type: 'scatter',
            name: _waveMap[i] !== undefined ? `Wavelength: ${_waveMap[i]}` : `Wave ${i}` });
    }

    const layout = {
        xaxis: { title: 'x', color: getThemeColors().muted, autorange: !rangeOverride },
        yaxis: { title: 'y', color: getThemeColors().muted, autorange: !rangeOverride },
        ...plotlyTheme(),
    };
    if (rangeOverride) { layout.xaxis.range = rangeOverride.x; layout.yaxis.range = rangeOverride.y; }

    Plotly.newPlot(container, traces, layout, {responsive: true, displaylogo: false});
    requestAnimationFrame(() => _spotEnforceAspect(container));
    container.on('plotly_relayout', () => { requestAnimationFrame(() => _spotEnforceAspect(container)); });
}

// =============================================================================
// Render: Heatmaps
// =============================================================================

function renderHeatmapDual(d1, d2, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  viz.innerHTML = '';

  function buildTrace(d, xaxis, yaxis) {
    const traceData = { z: d.data[0].values, type: 'heatmap', colorscale: 'Jet', xaxis, yaxis };
    const win = d.settings.window;
    if (['FftPsf', 'GeometricImageAnalysis', 'WavefrontMap'].includes(win)) {
      const nx = d.data[0].nx, dx = d.data[0].dx, sideLen = nx * dx;
      traceData.x0 = d.data[0].min_x; traceData.dx = sideLen / nx;
      traceData.y0 = d.data[0].min_y; traceData.dy = sideLen / d.data[0].values.length;
    }
    return traceData;
  }

  function xTitle(d) {
    const win = d.settings.window;
    if (win === 'FftPsf') return 'X (um)';
    if (win === 'WavefrontMap') return 'Px';
    return d.x_label || '';
  }
  function yTitle(d) {
    const win = d.settings.window;
    if (win === 'FftPsf') return 'Y (um)';
    if (win === 'WavefrontMap') return 'Py';
    return d.y_label || '';
  }

  const wfmRange = d1.settings.window === 'WavefrontMap' ? { range: [-1, 1] } : {};
  const plotW = Math.min(viz.clientWidth, 2000);
  const plotH = Math.min(viz.clientHeight, 2000);

  const layout = {
    width: plotW, height: plotH, margin: { l: 60, r: 60, t: 30, b: 60 },
    grid: { rows: 1, columns: 2, pattern: 'independent' },
    xaxis:  { title: xTitle(d1), color: getThemeColors().muted, showgrid: false, zeroline: false, ticks: 'outside', ...wfmRange },
    yaxis:  { title: yTitle(d1), color: getThemeColors().muted, showgrid: false, zeroline: false, ticks: 'outside', scaleanchor: 'x', scaleratio: 1, ...wfmRange },
    xaxis2: { title: xTitle(d2), color: getThemeColors().muted, showgrid: false, zeroline: false, ticks: 'outside', ...wfmRange },
    yaxis2: { title: yTitle(d2), color: getThemeColors().muted, showgrid: false, zeroline: false, ticks: 'outside', scaleanchor: 'x2', scaleratio: 1, ...wfmRange },
    ...plotlyTheme(), plot_bgcolor: getThemeColors().bg,
    annotations: [
      { text: d1.data[0].description || 'Field 1', xref: 'x domain', yref: 'y domain', x: 0.5, y: 1.08, showarrow: false, font: { color: getThemeColors().text, size: 12 } },
      { text: d2.data[0].description || 'Field 2', xref: 'x2 domain', yref: 'y2 domain', x: 0.5, y: 1.08, showarrow: false, font: { color: getThemeColors().text, size: 12 } }
    ]
  };

  Plotly.newPlot(viz, [buildTrace(d1, 'x', 'y'), buildTrace(d2, 'x2', 'y2')], layout, {responsive: true, displaylogo: false});
}

function renderHeatmap(d, panel) {
  panel = panel || panels[0];
  const viz = panel.viz;
  if (d.description) viz.innerHTML = `<p class="desc">${d.description}</p>`;

  const traceData = { z: d.data[0].values, type: 'heatmap', colorscale: 'Jet' };
  if (d.settings && ['FftPsf', 'GeometricImageAnalysis', 'WavefrontMap'].includes(d.settings.window)) {
    const nx = d.data[0].nx, dx = d.data[0].dx, sideLen = nx * dx;
    traceData.x0 = d.data[0].min_x; traceData.dx = sideLen / nx;
    traceData.y0 = d.data[0].min_y; traceData.dy = sideLen / d.data[0].values.length;
  }

  const wfm = d.settings && d.settings.window === 'WavefrontMap';
  const psf = d.settings && d.settings.window === 'FftPsf';
  const plotW = Math.min(viz.clientWidth, 2000);
  const plotH = Math.min(viz.clientHeight, 2000);

  const layout = {
    width: plotW, height: plotH, margin: { l: 60, r: 60, t: 30, b: 60 },
    xaxis: { title: psf ? 'X (um)' : wfm ? 'Px' : d.x_label, color: getThemeColors().muted, showgrid: false, zeroline: false, ticks: 'outside', ...(wfm ? { range: [-1, 1] } : {}) },
    yaxis: { title: psf ? 'Y (um)' : wfm ? 'Py' : d.y_label, color: getThemeColors().muted, showgrid: false, zeroline: false, ticks: 'outside', scaleanchor: 'x', scaleratio: 1, ...(wfm ? { range: [-1, 1] } : {}) },
    ...plotlyTheme(), plot_bgcolor: getThemeColors().bg,
  };
  Plotly.newPlot(viz, [traceData], layout, {responsive: true, displaylogo: false});
}

// =============================================================================
// Aspect Ratio Enforcement (Spot, Footprint, YYBar)
// =============================================================================

function _spotEnforceAspect(plotDiv) {
    const xa = plotDiv._fullLayout.xaxis;
    const ya = plotDiv._fullLayout.yaxis;
    const xRange = xa.range, yRange = ya.range;
    const plotWidth = xa._length, plotHeight = ya._length;
    if (!plotWidth || !plotHeight) return;

    const dataW = Math.abs(xRange[1] - xRange[0]);
    const dataH = Math.abs(yRange[1] - yRange[0]);
    const uppX = dataW / plotWidth, uppY = dataH / plotHeight;

    if (Math.abs(uppX - uppY) / Math.max(uppX, uppY) < 0.001) return;

    const xCenter = (xRange[0] + xRange[1]) / 2;
    const yCenter = (yRange[0] + yRange[1]) / 2;
    let newXRange, newYRange;

    if (uppX > uppY) {
        const newDataH = uppX * plotHeight;
        newYRange = [yCenter - newDataH / 2, yCenter + newDataH / 2];
        newXRange = xRange;
    } else {
        const newDataW = uppY * plotWidth;
        newXRange = [xCenter - newDataW / 2, xCenter + newDataW / 2];
        newYRange = yRange;
    }

    Plotly.relayout(plotDiv, { 'xaxis.range': newXRange, 'yaxis.range': newYRange, 'xaxis.autorange': false, 'yaxis.autorange': false });
}

// =============================================================================
// Initialization
// =============================================================================


// Restore sidebar, filters, layout, and theme from URL
{
    const params = new URLSearchParams(window.location.search);
    if (params.get('theme') === 'light') {
        document.body.classList.add('light');
        document.querySelector('#theme-toggle svg').innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
    }
    if (params.get('info') === '1') {
        document.getElementById('left-sidebar').classList.add('open');
    }
    if (params.get('sidebar') === '1') {
        document.getElementById('sidebar').classList.add('open');
    }
    const savedFilters = filtersFromUrl(params.get('filters'));
    if (savedFilters.length > 0) {
        for (const f of savedFilters) restoreFilterRow(f);
    }
    const layoutParam = params.get('layout');
    if (layoutParam && LAYOUT_PANELS[layoutParam]) {
        applyGridLayout(layoutParam);
    }
    panels.forEach(p => {
        if (params.get('s' + p.id) === 'e') {
            p.settings.style.display = '';
            p.toggleBtn.style.opacity = '1';
        }
        if (params.get('l' + p.id) === 'h') {
            p.legendVisible = false;
            p.legendBtn.style.opacity = '0.5';
        }
        if (params.get('r' + p.id) === 'd') {
            p.rawdataVisible = true;
            p.rawdataBtn.style.opacity = '1';
        }
    });
}

// =============================================================================
// Directory Dialog
// =============================================================================

async function updatePklCount(dir) {
    const label = document.getElementById('dir-pkl-count');
    if (!dir) { label.textContent = ''; return; }
    const res = await fetch(`/pkl-count/${encodeURIComponent(dir)}`);
    const data = await res.json();
    label.textContent = `${data.count} pkl files`;
}

function showDirDialog() {
    const params = new URLSearchParams(window.location.search);
    const dir = params.get('dir') || '';
    document.getElementById('dir-path').value = dir;
    document.getElementById('dir-overlay').style.display = 'block';
    document.getElementById('dir-dialog').style.display = 'block';
    updatePklCount(dir);
}

function hideDirDialog() {
    document.getElementById('dir-overlay').style.display = 'none';
    document.getElementById('dir-dialog').style.display = 'none';
}

document.getElementById('dir-dialog-btn').addEventListener('click', showDirDialog);

document.getElementById('copy-zmx-path').addEventListener('click', () => {
    const params = new URLSearchParams(window.location.search);
    let dir = params.get('dir') || '';
    const sel = document.getElementById('h1_name');
    const filename = sel.value || '';
    const base = filename.replace(/\.[^.]+$/, '');
    const isWindows = /^[A-Za-z]:/.test(dir);
    if (isWindows) dir = dir.replace(/\//g, '\\');
    const sep = isWindows ? '\\' : '/';
    const zmxPath = '"' + dir + sep + base + '.zmx"';
    navigator.clipboard.writeText(zmxPath);
});

document.getElementById('dir-browse').addEventListener('click', async () => {
    const res = await fetch('/browse');
    const data = await res.json();
    if (data.path) {
        document.getElementById('dir-path').value = data.path;
        updatePklCount(data.path);
    }
});

document.getElementById('dir-cancel').addEventListener('click', hideDirDialog);
document.getElementById('dir-overlay').addEventListener('click', hideDirDialog);

document.getElementById('dir-ok').addEventListener('click', () => {
    const path = document.getElementById('dir-path').value.trim();
    if (!path) return;
    hideDirDialog();
    updateQueryParam('dir', path);
    load_directory(false).then(() => {
        reloadFile();
    });
});

// Startup
{
    const params = new URLSearchParams(window.location.search);
    if (!params.get('dir')) {
        showDirDialog();
    } else {
        load_directory(true).then(async () => {
            if (params.get('filters')) executeSearch();
            if (!params.get('layout') && !params.get('key') && !params.get('key1')) {
                const res = await fetch('/keys');
                const {keys} = await res.json();
                if (keys.includes('lde') && keys.includes('layout')) {
                    applyGridLayout('1x2');
                    updateQueryParam('layout', '1x2');
                    for (const panel of panels) {
                        if (panel.container.style.display === 'none') continue;
                        await fetchKeys(panel);
                    }
                    updateQueryParam('key', 'lde');
                    panels[0].sel.value = 'lde';
                    loadSelected(panels[0]);
                    updateQueryParam('key1', 'layout');
                    panels[1].sel.value = 'layout';
                    loadSelected(panels[1]);
                    return;
                }
            }
        });
        fetchKeys();
    }
}

</script>

<!-- ===== Three.js Layout Module ===== -->
<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const LAYOUT_COLORS = ['#0000FF', '#00FF00', '#FF0000', '#BFBF00',
    '#FF00FF', '#00FFFF', '#7F7FFF', '#7FFF7F',
    '#7F007F', '#FF003F', '#7F00FF', '#FF7F7F',
    '#137EEB', '#2785D7', '#3A8BC4', '#4E92B0',
    '#62989C', '#759F89', '#89A575', '#9CAC62',
    '#B0B24E', '#C4B93A', '#D7BF27', '#EBC613'];

function clearScene(panel) {
    panel = panel || panels[0];
    const app = panel._layoutApp;
    if (!app) return;

    cancelAnimationFrame(app.animId);
    if (app.resizeObs) app.resizeObs.disconnect();
    if (app.docClickHandler) document.removeEventListener('click', app.docClickHandler);
    if (app.controls) app.controls.dispose();

    if (app.scene) {
        app.scene.traverse(obj => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
                const materials = Array.isArray(obj.material) ? obj.material : [obj.material];
                for (const mat of materials) {
                    for (const key of Object.keys(mat)) { if (mat[key] && mat[key].isTexture) mat[key].dispose(); }
                    mat.dispose();
                }
            }
        });
    }
    panel._layoutApp = null;
}

window.disposeLayout = function(panel) {
    panel = panel || panels[0];
    clearScene(panel);
    if (panel._layoutRenderer) {
        panel._layoutRenderer.domElement.style.display = 'none';
    }
};

window.renderLayout = function(d, panel) {
    panel = panel || panels[0];
    const viz = panel.viz;
    const layoutData = d;

    // Determine whether to include S0 (object surface) in the plot
    let includeS0 = true;
    if (_aboutData && _aboutData.data) {
        const objDist = parseFloat(_aboutData.data.object_distance);
        const totr = parseFloat(_aboutData.data.TOTR);
        if (objDist && totr && objDist > 2 * totr) includeS0 = false;
    }

    clearScene(panel);

    // Populate settings panel with layout controls
    panel.settingsPre.innerHTML = `
        <div class="layout-settings">
            <label>Field <select class="layout-fields"><option value="all">All</option></select></label>
            <label>Rays <select class="layout-rays">
                <option value="7" selected>7</option>
                <option value="3">3</option>
                <option value="2">2</option>
                <option value="1">1</option>
                <option value="0">0</option>
            </select></label>
            <select class="layout-model">
                <option value="cross">Wire</option>
                <option value="shaded">Shaded</option>
            </select>
            <label>View <select class="layout-view">
                <option value="">-</option>
                <option value="isometric">Iso</option>
                <option value="xy">XY</option>
                <option value="yz">YZ</option>
                <option value="xz">XZ</option>
            </select></label>
            <button class="layout-reset" style="font-size:0.8rem;padding:0.2rem 0.6rem;margin-top:0.3rem;">Reset</button>
        </div>
    `;
    const settingsParam = new URLSearchParams(window.location.search).get('s' + panel.id);
    panel.settings.style.display = settingsParam === 'e' ? '' : 'none';
    panel.toggleBtn.style.opacity = settingsParam === 'e' ? '1' : '0.4';

    viz.innerHTML = `
        <div class="layout-screenshot-bar" style="position:absolute;top:8px;right:8px;z-index:50;display:flex;gap:4px;">
            <button class="layout-copy-png" title="Copy to clipboard" style="background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:4px;padding:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--text-muted);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            </button>
            <button class="layout-save-png" title="Save as PNG" style="background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:4px;padding:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--text-muted);">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            </button>
        </div>
        <div class="layout-container" style="width:100%;height:100%;border:1px solid #444;border-radius:2px;position:relative;"></div>
    `;

    const container = viz.querySelector('.layout-container');

    const coordLabel = document.createElement('div');
    coordLabel.style.cssText = 'position:absolute;top:4px;left:6px;color:#ccc;font-size:0.75rem;font-family:monospace;pointer-events:none;z-index:10;';
    container.appendChild(coordLabel);

    if (!panel._layoutRenderer) {
        panel._layoutRenderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    }
    const renderer = panel._layoutRenderer;
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.domElement.style.display = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(getThemeColors().layoutBg);
    const aspect = container.clientWidth / container.clientHeight;

    // Build shaded mesh group
    const meshGroup = new THREE.Group();
    layoutData.mesh.points.forEach((points, idx) => {
        const faces = layoutData.mesh.faces[idx];
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(points.flat()), 3));
        const indices = [];
        for (let i = 0; i < faces.length;) {
            const n = faces[i++];
            const faceVerts = faces.slice(i, i + n); i += n;
            if (n === 3) indices.push(...faceVerts);
            else if (n > 3) { for (let j = 1; j < n - 1; j++) indices.push(faceVerts[0], faceVerts[j], faceVerts[j + 1]); }
        }
        geometry.setIndex(indices);
        geometry.computeVertexNormals();
        // use the NSC object's draw color (DrawData.ObjectColor) when present; else default
        const objColor = (layoutData.object_colors && layoutData.object_colors[idx]) || getThemeColors().layoutMesh;
        meshGroup.add(new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({
            color: objColor, side: THREE.DoubleSide, transparent: true, opacity: 0.5, depthWrite: false
        })));
    });

    // Build wireframe cross-section group
    const crossGroup = new THREE.Group();
    layoutData.yz_cross.points.forEach((pts, idx) => {
        const verts = pts.map(p => new THREE.Vector3(...p));
        const lineVerts = [];
        for (const [i0, i1] of layoutData.yz_cross.lines[idx]) lineVerts.push(verts[i0], verts[i1]);
        crossGroup.add(new THREE.LineSegments(
            new THREE.BufferGeometry().setFromPoints(lineVerts),
            new THREE.LineBasicMaterial({ color: getThemeColors().layoutCross })
        ));
    });

    crossGroup.visible = true;
    meshGroup.visible = false;
    scene.add(crossGroup);
    scene.add(meshGroup);

    // Build rays - group by field, then by individual ray
    const rayGroups = []; // array of { fieldGroup, raySubGroups[] }
    layoutData.rays.forEach((el, idx) => {
        const fieldGroup = new THREE.Group();
        fieldGroup.name = 'rays';
        const rayVerts = el.points.map(p => new THREE.Vector3(p[0], p[1], p[2]));
        // prefer an explicit per-ray-set color (e.g. NSC per-source); else use palette by index
        const color = el.color || LAYOUT_COLORS[idx % LAYOUT_COLORS.length];

        // Build adjacency and find root nodes (no incoming edges)
        const adj = {};
        const hasIncoming = new Set();
        for (const line of el.lines) {
            if (!adj[line[0]]) adj[line[0]] = [];
            adj[line[0]].push(line[1]);
            hasIncoming.add(line[1]);
        }

        // Find roots: nodes that appear as source but never as target
        const allNodes = new Set(Object.keys(adj).map(Number));
        const roots = [...allNodes].filter(n => !hasIncoming.has(n)).sort((a, b) => a - b);

        const raySubGroups = [];

        if (roots.length === 1 && (adj[roots[0]] || []).length > 1) {
            // Tree structure: single root with multiple children (S0 case)
            const root = roots[0];
            const children = adj[root] || [];
            for (let r = 0; r < children.length; r++) {
                const rayGroup = new THREE.Group();
                if (includeS0) {
                    rayGroup.add(new THREE.Line(
                        new THREE.BufferGeometry().setFromPoints([rayVerts[root], rayVerts[children[r]]]),
                        new THREE.LineBasicMaterial({ color })
                    ));
                }
                const visited = new Set();
                let current = children[r];
                while (adj[current] && adj[current].length > 0 && !visited.has(current)) {
                    visited.add(current);
                    const next = adj[current][0];
                    rayGroup.add(new THREE.Line(
                        new THREE.BufferGeometry().setFromPoints([rayVerts[current], rayVerts[next]]),
                        new THREE.LineBasicMaterial({ color })
                    ));
                    current = next;
                }
                fieldGroup.add(rayGroup);
                raySubGroups.push(rayGroup);
            }
        } else {
            // Multiple roots: each root starts an independent ray chain
            for (const root of roots) {
                const rayGroup = new THREE.Group();
                const visited = new Set();
                let current = root;
                while (adj[current] && adj[current].length > 0 && !visited.has(current)) {
                    visited.add(current);
                    const next = adj[current][0];
                    rayGroup.add(new THREE.Line(
                        new THREE.BufferGeometry().setFromPoints([rayVerts[current], rayVerts[next]]),
                        new THREE.LineBasicMaterial({ color })
                    ));
                    current = next;
                }
                fieldGroup.add(rayGroup);
                raySubGroups.push(rayGroup);
            }
        }

        scene.add(fieldGroup);
        rayGroups.push({ fieldGroup, raySubGroups });
    });

    // Lighting
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(5, 5, 5);
    scene.add(dirLight);

    // Camera — fit scene to 90% of container
    const box = new THREE.Box3().setFromObject(scene);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const sceneW = size.z, sceneH = size.y;
    const margin = 0.9;
    let halfH, halfW;
    if (sceneW / sceneH > container.clientWidth / container.clientHeight) {
        halfW = (sceneW / 2) / margin; halfH = halfW / aspect;
    } else {
        halfH = (sceneH / 2) / margin; halfW = halfH * aspect;
    }
    const camDist = Math.max(size.x, size.y, size.z) * 2;

    const camera = new THREE.OrthographicCamera(-halfW, halfW, halfH, -halfH, -camDist * 4, camDist * 4);
    camera.position.set(-camDist, 0, center.z);
    camera.up.set(0, 1, 0);
    camera.lookAt(center);
    camera.updateProjectionMatrix();

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.copy(center);
    controls.enableDamping = false;
    controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.ROTATE };
    controls.saveState();

    // Rectangle zoom
    const zoomRect = document.createElement('div');
    zoomRect.style.cssText = 'display:none;position:absolute;border:1px dashed #ccc;background:rgba(255,255,255,0.05);pointer-events:none;z-index:10;';
    container.appendChild(zoomRect);
    let zoomDragging = false, zoomStartX, zoomStartY;

    container.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        if (e.target !== renderer.domElement) return;
        zoomDragging = true; controls.enabled = false;
        const rect = container.getBoundingClientRect();
        zoomStartX = e.clientX - rect.left; zoomStartY = e.clientY - rect.top;
        zoomRect.style.left = zoomStartX + 'px'; zoomRect.style.top = zoomStartY + 'px';
        zoomRect.style.width = '0px'; zoomRect.style.height = '0px'; zoomRect.style.display = 'block';
    });
    container.addEventListener('mousemove', (e) => {
        if (!zoomDragging) return;
        const rect = container.getBoundingClientRect();
        const curX = e.clientX - rect.left, curY = e.clientY - rect.top;
        zoomRect.style.left = Math.min(zoomStartX, curX) + 'px'; zoomRect.style.top = Math.min(zoomStartY, curY) + 'px';
        zoomRect.style.width = Math.abs(curX - zoomStartX) + 'px'; zoomRect.style.height = Math.abs(curY - zoomStartY) + 'px';
    });
    container.addEventListener('mouseup', (e) => {
        if (!zoomDragging) return;
        zoomDragging = false; zoomRect.style.display = 'none'; controls.enabled = true;
        const rect = container.getBoundingClientRect();
        const endX = e.clientX - rect.left, endY = e.clientY - rect.top;
        const rectW = Math.abs(endX - zoomStartX), rectH = Math.abs(endY - zoomStartY);
        if (rectW < 5 || rectH < 5) return;
        const cw = container.clientWidth, ch = container.clientHeight;
        const zoomFactor = Math.min(cw / rectW, ch / rectH);
        const cx = (Math.min(zoomStartX, endX) + rectW / 2), cy = (Math.min(zoomStartY, endY) + rectH / 2);
        const ndcX = (cx / cw) * 2 - 1, ndcY = -(cy / ch) * 2 + 1;
        const worldCenter = new THREE.Vector3(ndcX, ndcY, 0).unproject(camera);
        const currentCenter = new THREE.Vector3(0, 0, 0).unproject(camera);
        const offset = worldCenter.clone().sub(currentCenter);
        camera.position.add(offset); controls.target.add(offset);
        camera.zoom *= zoomFactor; camera.updateProjectionMatrix(); controls.update();
    });

    // Animation loop
    let animId = null;
    function animate() { animId = requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); }
    animate();

    panel._layoutApp = { scene, camera, renderer, controls, meshGroup, crossGroup, rayGroups, camDist, center, animId, objects: layoutData.objects || null, surfaceGroups: layoutData.surface_groups || null, objectColors: layoutData.object_colors || null };

    // World coordinates on hover
    let showXCoord = false;
    container.addEventListener('mousemove', (e) => {
        const rect = container.getBoundingClientRect();
        const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        const ndcY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        const world = new THREE.Vector3(ndcX, ndcY, 0).unproject(camera);
        coordLabel.textContent = showXCoord
            ? `X: ${world.x.toFixed(4)}  Y: ${world.y.toFixed(4)}  Z: ${world.z.toFixed(4)}`
            : `Y: ${world.y.toFixed(4)}  Z: ${world.z.toFixed(4)}`;
    });
    container.addEventListener('mouseleave', () => { coordLabel.textContent = ''; });

    let rotStartX = 0, rotStartY = 0;
    container.addEventListener('mousedown', (e) => { if (e.button === 2) { rotStartX = e.clientX; rotStartY = e.clientY; } });
    container.addEventListener('mousemove', (e) => {
        if (e.buttons & 2) { if (Math.abs(e.clientX - rotStartX) > 3 || Math.abs(e.clientY - rotStartY) > 3) showXCoord = true; }
    });

    // Settings controls (in panel.settings area)
    const settingsEl = panel.settingsPre;
    const fieldSelect = settingsEl.querySelector('.layout-fields');
    const raySelect = settingsEl.querySelector('.layout-rays');
    const modelSelect = settingsEl.querySelector('.layout-model');
    const viewSelect = settingsEl.querySelector('.layout-view');

    // Populate field options
    layoutData.rays.forEach((el, idx) => {
        const op = document.createElement('option');
        op.value = idx.toString();
        op.textContent = el.comment || `Field ${idx + 1}`;
        fieldSelect.appendChild(op);
    });

    // Wire/Shaded toggle
    modelSelect.addEventListener('change', () => {
        const val = modelSelect.value;
        crossGroup.visible = val === 'cross'; meshGroup.visible = val === 'shaded';
    });

    // Field visibility
    fieldSelect.addEventListener('change', () => {
        const val = fieldSelect.value;
        rayGroups.forEach((rg, i) => {
            rg.fieldGroup.visible = (val === 'all' || parseInt(val) === i);
        });
    });

    // Number of rays visibility
    function applyRayFilter() {
        const count = parseInt(raySelect.value);
        rayGroups.forEach(rg => {
            const n = rg.raySubGroups.length;
            const mid = Math.floor(n / 2);
            rg.raySubGroups.forEach((sg, i) => {
                if (count === 0) sg.visible = false;
                else if (count === 7) sg.visible = true;
                else if (count === 1) sg.visible = (i === mid);
                else if (count === 2) sg.visible = (i === 0 || i === n - 1);
                else if (count === 3) sg.visible = (i === 0 || i === mid || i === n - 1);
                else sg.visible = true;
            });
        });
    }
    raySelect.addEventListener('change', applyRayFilter);

    // Reset & View
    settingsEl.querySelector('.layout-reset').addEventListener('click', resetView);
    viewSelect.addEventListener('change', function() {
        switch (this.value) {
            case 'isometric': camera.position.set(-camDist, camDist, -camDist); camera.up.set(0, 1, 0); break;
            case 'xy': camera.position.set(0, 0, camDist); camera.up.set(0, 1, 0); break;
            case 'yz': camera.position.set(-camDist, 0, center.z); camera.up.set(0, 1, 0); camera.lookAt(center); break;
            case 'xz': camera.position.set(0, camDist, center.z); camera.up.set(1, 0, 0); camera.lookAt(center); break;
        }
        controls.update(); this.value = '';
    });

    // Screenshots
    viz.querySelector('.layout-copy-png').addEventListener('click', () => {
        renderer.render(scene, camera);
        renderer.domElement.toBlob(blob => { navigator.clipboard.write([new ClipboardItem({'image/png': blob})]); });
    });
    viz.querySelector('.layout-save-png').addEventListener('click', () => {
        renderer.render(scene, camera);
        const link = document.createElement('a'); link.download = 'layout.png';
        link.href = renderer.domElement.toDataURL('image/png'); link.click();
    });

    // Resize observer
    function updateCameraFrustum() {
        const w = container.clientWidth, h = container.clientHeight;
        if (w === 0 || h === 0) return;
        renderer.setSize(w, h);
        const asp = w / h;
        const margin = 0.9;
        let hH, hW;
        if (sceneW / sceneH > asp) {
            hW = (sceneW / 2) / margin; hH = hW / asp;
        } else {
            hH = (sceneH / 2) / margin; hW = hH * asp;
        }
        camera.left = -hW; camera.right = hW; camera.top = hH; camera.bottom = -hH;
        camera.updateProjectionMatrix();
    }
    function resetView() {
        camera.zoom = 1;
        updateCameraFrustum();
        camera.position.set(-camDist, 0, center.z);
        camera.up.set(0, 1, 0);
        camera.lookAt(center);
        camera.updateProjectionMatrix();
        controls.target.copy(center);
        controls.update();
        showXCoord = false;
    }
    const resizeObs = new ResizeObserver(() => updateCameraFrustum());
    resizeObs.observe(container);

    // Right-click context menu
    const ctxMenu = document.createElement('div');
    ctxMenu.style.cssText = 'display:none;position:absolute;background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:4px;padding:2px 0;z-index:100;';
    const resetItem = document.createElement('div');
    resetItem.textContent = 'Reset View';
    resetItem.style.cssText = 'padding:6px 16px;cursor:pointer;color:var(--text);font-size:0.9rem;';
    resetItem.addEventListener('mouseenter', () => resetItem.style.background = 'var(--hover)');
    resetItem.addEventListener('mouseleave', () => resetItem.style.background = 'none');
    resetItem.addEventListener('click', () => { resetView(); ctxMenu.style.display = 'none'; });
    ctxMenu.appendChild(resetItem);
    container.appendChild(ctxMenu);

    let rightDownX = 0, rightDownY = 0, rightDragged = false;
    container.addEventListener('mousedown', (e) => { if (e.button === 2) { rightDownX = e.clientX; rightDownY = e.clientY; rightDragged = false; } });
    container.addEventListener('mousemove', (e) => { if (e.buttons & 2) { if (Math.abs(e.clientX - rightDownX) > 3 || Math.abs(e.clientY - rightDownY) > 3) rightDragged = true; } });
    container.addEventListener('contextmenu', (e) => {
        e.preventDefault(); if (rightDragged) return;
        const rect = container.getBoundingClientRect();
        ctxMenu.style.left = (e.clientX - rect.left) + 'px'; ctxMenu.style.top = (e.clientY - rect.top) + 'px';
        ctxMenu.style.display = 'block';
    });

    const docClickHandler = () => ctxMenu.style.display = 'none';
    document.addEventListener('click', docClickHandler);

    panel._layoutApp.resizeObs = resizeObs;
    panel._layoutApp.docClickHandler = docClickHandler;
};

window._layoutModuleResolve();
</script>
</body>
</html>
"""

def serve(host="127.0.0.1", port=8000):
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    pass
