# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from .connect import Connect

from .analysis.about import About

from .analysis.chief_ray_angle import ChiefRayAngle
from .analysis.chromatic import Chromatic
from .analysis.diffraction_encircled_energy import DiffractionEncircledEnergy
from .analysis.fft_mtf import FftMtf
from .analysis.fft_psf import FftPsf
from .analysis.fft_through_focus_mtf import FftThroughFocusMtf
from .analysis.field_curvature_and_distortion import FieldCurvatureAndDistortion
from .analysis.footprint_diagram import FootprintDiagram
from .analysis.geometric_image_analysis import GeometricImageAnalysis
from .analysis.grid_distortion import GridDistortion
from .analysis.longitudinal import Longitudinal
from .analysis.object_image_mapping import ObjectImageMapping
from .analysis.paraxial import Paraxial
from .analysis.ray_fan import RayFan
from .analysis.relative_illumination import RelativeIllumination
from .analysis.rms_vs_field import RmsVsField
from .analysis.sag_table import SagTable
from .analysis.seidel import Seidel
from .analysis.single_ray_trace import SingleRayTrace
from .analysis.spot_diagram import SpotDiagram
from .analysis.spot_diagram_raytrace import SpotDiagramRayTrace
from .analysis.spot_diagram_through_focus import SpotDiagramThroughFocus
from .analysis.through_focus import ThroughFocus
from .analysis.transmission import Transmission
from .analysis.wave_fan import WaveFan
from .analysis.wavefront import Wavefront
from .analysis.y_ybar import Y_YBar
from .analysis.zernike import Zernike

from .layouts.shaded_model_v2 import Layout

from .analysis.lde import LDE
from .analysis.nce import NCE

import json
import pandas as pd
from pathlib import Path
import pickle
import subprocess
import time


def _harvest_version():
    """Return the installed lens_harvest wheel version that produced this run,
    or 'unknown' if it can't be determined (e.g. running from source)."""
    try:
        from importlib.metadata import version, PackageNotFoundError
        try:
            return version("lens_harvest")
        except PackageNotFoundError:
            return "unknown"
    except Exception:
        return "unknown"


class RunAll():
    def __init__(self):
        # clear previous output (can remove in production)
        subprocess.run("cls", shell=True, check=True)

        # connect to OpticStudio
        self.reconnect()

        # initialize the current filename
        self.current_filename = None

        # track the failed files
        self.failed = []

        pass
    def reconnect(self):
        self.zos = Connect()
    def disconnect(self):
        self.zos.TheApplication.CloseApplication()
        self.zos = None
        del self.zos
    
    def disconnect_and_reconnect(self, key):
        self.disconnect()
        self.reconnect()
        self.load_file()

    def load_file(self, filename = None):
        if filename is None and self.current_filename is not None:
            filename = self.current_filename

        if filename is None:
            raise Exception('filename cannot be None')

        self.zos.TheSystem.LoadFile(str(filename), False)
        self.current_filename = filename

        self.extremes = self.get_extremes()

    def is_nonsequential(self):
        return self.zos.TheSystem.Mode == self.zos.ZOSAPI.SystemType.NonSequential

    def cap_layout_rays(self, max_rays=20):
        """In non-sequential mode, cap each source's '# Layout Rays' at max_rays.
        Returns True if the file was modified."""
        modified = False
        nce = self.zos.TheSystem.NCE
        for i in range(1, nce.NumberOfObjects + 1):      # NCE is 1-based, like the MFE
            obj = nce.GetObjectAt(i)
            # all source object types begin with "Source" (SourcePoint, SourceEllipse, ...)
            if str(obj.Type)[:6].lower() != 'source':
                continue
            # For standard NSC sources, Par1 == "# Layout Rays", Par2 == "# Analysis Rays"
            cell = obj.GetObjectCell(self.zos.ZOSAPI.Editors.NCE.ObjectColumn.Par1)
            current = int(cell.IntegerValue)
            if current > max_rays:
                cell.IntegerValue = max_rays
                modified = True
                print(f'File modified (layout rays for Source {i} changed from {current} to {max_rays})')
        return modified

    def _run_with_retry(self, name, func, **kwargs):
        max_retries = 3

        for attempt in range(max_retries + 1):
            try:
                return func(**kwargs)
            except Exception:
                if attempt < max_retries:
                    self.disconnect_and_reconnect(name)
        
        if self.current_filename not in self.failed:
            self.failed.append(self.current_filename)
        return [None]

    def all2(self, level=1, **kwargs):
        if self.is_nonsequential():
            self.cap_layout_rays(20)
            all_res = {
                
                'nce': self._run_with_retry('nce', self.nce, **kwargs),
                'layout': self._run_with_retry('layout', self.layout, **kwargs),
            }
            layout_res = all_res['layout']
            layout_ok = len(layout_res) > 0 and layout_res[0] is not None and layout_res[0] is not False
            if layout_ok:
                self.save_to_disk(all_res, **kwargs)
            else:
                print(f'Layout failed, not saving: {self.current_filename}')
            return

        all_res = {}
        all_res.update({'_about': self.about()})
        
        analyses = [
            ('lde', self.lde),
            ('layout', self.layout),
            ('chief_ray_angle', self.chief_ray_angle),                                  # [x]
            ('chromatic', self.chromatic),
            ('diffraction_encircled_energy', self.diffraction_encircled_energy),
            ('fft_mtf', self.fft_mtf),
            ('fft_psf', self.fft_psf),
            ('fft_through_focus_mtf', self.fft_through_focus_mtf),
            ('field_curvature_and_distortion', self.field_curvature_and_distortion),
            ('footprint_diagram', self.footprint_diagram),
            ('geometric_image_analysis', self.geometric_image_analysis),
            ('grid_distortion', self.grid_distortion),
            ('longitudinal', self.longitudinal),
            ('object_image', self.object_image),
            ('paraxial', self.paraxial),
            ('ray_fan', self.ray_fan),
            ('relative_illumination', self.relative_illumination),
            ('rms_vs_field', self.rms_vs_field),
            ('sag_table', self.sag_table),
            ('seidel', self.seidel),
            ('single_ray_trace', self.single_ray_trace),
            ('spot_diagram', self.spot_diamgram),
            ('spot_diagram_raytrace', self.spot_diagram_raytrace),
            ('spot_diagram_through_focus', self.spot_diagram_through_focus),
            ('through_focus', self.through_focus),
            ('transmission', self.transmission),
            ('wave_fan', self.wave_fan),
            ('wavefront', self.wavefront),
            ('y_ybar', self.y_ybar),
            ('zernike', self.zernike),
            
            
        ]
        
        for key, func in analyses:
            all_res[key] = self._run_with_retry(key, func, **kwargs)

        # check to see if all the fields are valid
        save = True
        for el in all_res:
            if len(el) > 0 and el[0] == False:
                print(f'Failed for file : {self.current_filename}')
                save = False
                break
                 
        if save:
            self.save_to_disk(all_res, **kwargs)
    
    def save_to_disk(self, res, **kwargs):
        
        fn = kwargs.get('filename', None)

        if fn is None:
            fn = self.zos.TheSystem.SystemFile

        fn = Path(fn).with_suffix('.pkl')

        # make the parent directory...not sure I really want to do this
        # fn.parent.mkdir(parents=True, exist_ok=True)

        if not fn.parent.is_dir():
            return False

        # stamp the wheel version that produced this result so consumers can
        # tell which lens_harvest build wrote the file
        res['_harvest_version'] = _harvest_version()

        with open(fn, 'wb') as file:
            pickle.dump(res, file)
        pass

    def about(self):
        about = About()
        return about.run()
    
    def lde(self, **kwargs):
        lde = LDE()

        res = lde.run()

        return [res]

    def nce(self, **kwargs):
        nce = NCE()

        res = nce.run()

        return [res]

    def layout(self, **kwargs):
        layout = Layout(self.zos, settings_first=True)

        pwav = 1 if self.is_nonsequential() else self.extremes['wave_primary']['number']
        kwargs = {
            'screenshot': False,
            'show_orientation': True,
            'layout': 'cross',
            'xbars': False,
            'field': 'all',
            'wave': pwav,
            'number_of_rays': 7,
            'pattern': 'yfan',
            'title': None,
            'skip_plot': True,
            'save_json': False
            }
        return [layout.run(**kwargs)]

    def chief_ray_angle(self, **kwargs):
        cra = ChiefRayAngle()

        pwav = self.extremes['wave_primary']['number']
        res = cra.run(
            field_density=kwargs.get('field_density', 20),
            wavelength=kwargs.get('wavelength', pwav)
        )
        return [res]
    def chromatic(self, **kwargs):
        chromatic = Chromatic()
        res = chromatic.run(
            maximum_shift=kwargs.get('maximum_shift', 0.0), 
            pupil_zone=kwargs.get('pupil_zone', 0.0)
            )
        return [res]
    def diffraction_encircled_energy(self, **kwargs):
        '''
        we might need to loop this through & up the sampling to get some results
        should we also get the polychromatic one?
        '''
        pwav = self.extremes['wave_primary']['number']
        diffraction_encircled_energy = DiffractionEncircledEnergy()
        res = diffraction_encircled_energy.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            huygens_sampling=kwargs.get('huygens_sampling', 's_128x128'),
            sample_size=kwargs.get('sample_size', 's_128x128'),
            encircled_energy_type=kwargs.get('encircled_energy_type', 'encircled'),
            refer_to=kwargs.get('refer_to', 'centroid'),
            scatter_rays=kwargs.get('scatter_rays', False),
            show_diffraction_limit=kwargs.get('show_diffraction_limit', True),
            use_huygens_psf=kwargs.get('use_huygens_psf', False),
            use_polarization=kwargs.get('use_polarization', False),
            image_delta=kwargs.get('image_delta', 0.0),
            radius_maximum=kwargs.get('radius_maximum', 0.0)
        )
        return [res]
    def fft_mtf(self, **kwargs):
        fft_mtf = FftMtf()

        pwav = self.extremes['wave_primary']['number']
        # use `wavelength = 0` for polychromatic
        res = fft_mtf.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            mtf_type=kwargs.get('mtf_type', 'modulation'),
            sample_size=kwargs.get('sample_size', 's_64x664'),
            show_diffraction_limit=kwargs.get('show_diffraction_limit', True),
            use_polarization=kwargs.get('use_polarization', False),
            maximum_frequency=kwargs.get('maximum_frequency', 0.0)
        )
        return [res]
    def fft_psf(self, **kwargs):
        fft_psf = FftPsf()

        pwav = self.extremes['wave_primary']['number']
        field_min = self.extremes['field_min']['number']
        field_max = self.extremes['field_max']['number']

        res_min = fft_psf.run(
            field=kwargs.get('field', field_min),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            sample_size=kwargs.get('sample_size', 'psfs_64x64'),
            output_size=kwargs.get('output_size', 'psfs_128x128'),
            rotation=kwargs.get('rotation', 'cw0'),
            image_delta=kwargs.get('image_delta', 0.0),
            use_polarization=kwargs.get('use_polarization', False),
            psf_type=kwargs.get('psf_type', 'none'),
            normalize=kwargs.get('normalize', True)
        )
        res_max = fft_psf.run(
            field=kwargs.get('field', field_max),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            sample_size=kwargs.get('sample_size', 'psfs_64x64'),
            output_size=kwargs.get('output_size', 'psfs_128x128'),
            rotation=kwargs.get('rotation', 'cw0'),
            image_delta=kwargs.get('image_delta', 0.0),
            use_polarization=kwargs.get('use_polarization', False),
            psf_type=kwargs.get('psf_type', 'none'),
            normalize=kwargs.get('normalize', True)
        )
        return [res_min, res_max]
    def fft_through_focus_mtf(self, **kwargs):
        fft_through_focus_mtf = FftThroughFocusMtf()

        pwav = self.extremes['wave_primary']['number']
        # use `wavelength = 0` for polychromatic
        res = fft_through_focus_mtf.run(
            field=kwargs.get('field', 0),
            wavelength=kwargs.get('wavelength', pwav),
            mtf_type=kwargs.get('mtf_type', ' modulation'),
            sample_size=kwargs.get('sample_size', 's_64x64'),
            use_polarization=kwargs.get('use_polarization', False),
            delta_focus=kwargs.get('delta_focus', 0.1),
            frequency=kwargs.get('frequency', 50 if not self.zos.TheSystem.SystemData.Aperture.AFocalImageSpace else 0),
            number_of_steps=kwargs.get('number_of_steps', 5)
        )
        return [res]
    def field_curvature_and_distortion(self, **kwargs):
        field_curvature_and_distortion = FieldCurvatureAndDistortion()
        res = field_curvature_and_distortion.run(
            wavelength=kwargs.get('wavelength', 0),
            display_as=kwargs.get('display_as', 'percent'),
            distortion=kwargs.get('distortion', 'f_tantheta'),
            scan_type=kwargs.get('scan_type', 'plus_y'),
            ignore_vignetting=kwargs.get('ignore_vignetting', True),
            maximum_curvature=kwargs.get('maximum_curvature', 0.0),
            maximum_distortion=kwargs.get('maximum_distortion', 0.0),
            reference_field=kwargs.get('reference_field', 1),
            field_aspect_ratio=kwargs.get('field_aspect_ratio', 1.0)
        )
        return [res]
    def footprint_diagram(self, **kwargs):
        footprint_diagram = FootprintDiagram()

        pwav = self.extremes['wave_primary']['number']
        res = footprint_diagram.run(
            field=kwargs.get('field', 0), 
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            ray_density=kwargs.get('ray_density', 10),
            configuraion=kwargs.get('configuration', 0),
            delete_vignetted=kwargs.get('delete_vignetted', True)
        )
        return [res]
    def geometric_image_analysis(self, **kwargs):
        geometric_image_analysis = GeometricImageAnalysis()
        
        # pwav = self.extremes['wave_primary']['number']
        # currently polychromatic...change `wavelength = pwav` for monochromatic
        field_min = self.extremes['field_min']['number']
        field_max = self.extremes['field_max']['number']
        
        res_min = geometric_image_analysis.run(
            wavelength=kwargs.get('wavelength', 0), 
            field=kwargs.get('field', field_min),
            surface=kwargs.get('surface', 0),
            field_size=kwargs.get('field_size', 0.0),
            image_size=kwargs.get('image_size', -1.0),
            file=kwargs.get('file', 'CIRCLE.IMA'),
            rotation=kwargs.get('rotation', 0.0),
            rays_x_1000=kwargs.get('rays_x_1000', 10),
            source=kwargs.get('source', 'uniform'),
            number_of_pixels=kwargs.get('number_of_pixels', 100),
            na=kwargs.get('na', 0.0),
            total_watts=kwargs.get('total_watts', 1.0),
            parity=kwargs.get('parity', 'even'),
            reference=kwargs.get('reference', 'chiefray'),
            use_polarization=kwargs.get('use_polarization', False),
            remove_vignetting_factors=kwargs.get('remove_vignetting_factors', True),
            scatter_rays=kwargs.get('scatter_rays', False),
            delete_vignetted=kwargs.get('delete_vignetted', False),
            use_pixel_interpolation=kwargs.get('use_pixel_interpolation', False),
        )

        res_max = geometric_image_analysis.run(
            wavelength=kwargs.get('wavelength', 0), 
            field=kwargs.get('field', field_max),
            surface=kwargs.get('surface', 0),
            field_size=kwargs.get('field_size', 0.0),
            image_size=kwargs.get('image_size', -1.0),
            file=kwargs.get('file', 'CIRCLE.IMA'),
            rotation=kwargs.get('rotation', 0.0),
            rays_x_1000=kwargs.get('rays_x_1000', 10),
            source=kwargs.get('source', 'uniform'),
            number_of_pixels=kwargs.get('number_of_pixels', 100),
            na=kwargs.get('na', 0.0),
            total_watts=kwargs.get('total_watts', 1.0),
            parity=kwargs.get('parity', 'even'),
            reference=kwargs.get('reference', 'chiefray'),
            use_polarization=kwargs.get('use_polarization', False),
            remove_vignetting_factors=kwargs.get('remove_vignetting_factors', True),
            scatter_rays=kwargs.get('scatter_rays', False),
            delete_vignetted=kwargs.get('delete_vignetted', False),
            use_pixel_interpolation=kwargs.get('use_pixel_interpolation', False),
        )

        return [res_min, res_max]
    def grid_distortion(self, **kwargs):
        grid_distortion = GridDistortion()

        pwav = self.extremes['wave_primary']['number']
        res = grid_distortion.run(
            field=kwargs.get('field', 1),
            wavelength=kwargs.get('wavelength', pwav),
            symmetric_magnification=kwargs.get('symmetric_magnification', False),
            scale_factor=kwargs.get('scale_factor', 1.0),
            aspect=kwargs.get('aspect', 1.0),
            field_width=kwargs.get('field_width', 0.0),
            grid_number=kwargs.get('grid_number', 2)
        )
        return [res]
    
    def object_image(self, **kwargs):
        object_image = ObjectImageMapping()
        res = object_image.run()
        return [res]
    def longitudinal(self, **kwargs):
        longitudinal = Longitudinal()
        res = longitudinal.run()
        return [res]
    def paraxial(self, **kwargs):
        paraxial = Paraxial()
        res = paraxial.run()
        return [res]
    def ray_fan(self, **kwargs):
        ray_fan = RayFan()
        res = ray_fan.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', 0),
            number_of_rays=kwargs.get('number_of_rays', 20),
            check_apertures=kwargs.get('check_apertures', True),
            vignetted_pupil=kwargs.get('vignetted_pupil', True),
            tangential=kwargs.get('tangential', 'aberration_y'),
            sagittal=kwargs.get('sagittal', 'aberration_x')
        )
        return [res]
    def relative_illumination(self, **kwargs):
        relative_illumination = RelativeIllumination()

        pwav = self.extremes['wave_primary']['number']
        res = relative_illumination.run(
            wavelength=kwargs.get('wavelength', pwav),
            scan_type=kwargs.get('scan_type', 'plus_y'),
            ray_density=kwargs.get('ray_density', 10),
            field_density=kwargs.get('field_density', 20),
            use_polarization=kwargs.get('use_polarization', False),
            log_scale=kwargs.get('log_scale', False),
            remove_vignetting_factors=kwargs.get('remove_vignetting_factors', True)
        )
        return [res]
    def rms_vs_field(self, **kwargs):
        rms_vs_field = RmsVsField()
        res = rms_vs_field.run(
            wavelength=kwargs.get('wavelength', 0),
            settings=kwargs.get('settings', 'wavefront'),
            field_density=kwargs.get('field_density', 15),
            ray_density=kwargs.get('ray_density', 3),
            refer_to=kwargs.get('refer_to', 'centroid'),
            method=kwargs.get('method', 'gaussquad'),
            orientation=kwargs.get('orientation', 'plus_y'),
            show_diffraction_limit=kwargs.get('show_diffraction_limit', False),
            use_polarization=kwargs.get('use_polarization', False),
            remove_vignetting_factors=kwargs.get('remove_vignetting_factors', True)
        )
        return [res]
    def sag_table(self, **kwargs):
        sag_table = SagTable()
        res = sag_table.run(
            density=kwargs.get('density', 50)
        )
        return [res]
    def seidel(self, **kwargs):
        seidel = Seidel()

        pwav = self.extremes['wave_primary']['number']
        res = seidel.run(
            wavelength=kwargs.get('wavelength', pwav),
            ignore_distortion=kwargs.get('ignore_distortion', False),
            ignore_chromatic=kwargs.get('ignore_chromatic', False)
        )
        return [res]
    def single_ray_trace(self, **kwargs):
        single_ray_trace = SingleRayTrace()

        pwav = self.extremes['wave_primary']['number']
        res = single_ray_trace.run(
            hx=kwargs.get('hx', 0.0),
            hy=kwargs.get('hy', 0.0),
            px=kwargs.get('px', 0.0),
            py=kwargs.get('py', 1.0),
            wavelength=kwargs.get('wavelength', pwav),
            use_global=kwargs.get('use_global', False)
        )
        return [res]
    def spot_diamgram(self, **kwargs):
        spot_diagram = SpotDiagram()
        res = spot_diagram.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', 0),
            pattern=kwargs.get('pattern', 'hexapolar'),
            refer_to=kwargs.get('refer_to', 'chiefray'),
            ray_density=kwargs.get('ray_density', 6),
            show_airy_disk=kwargs.get('show_airy_disk', False),
            config_number=kwargs.get('config_number', 1)
        )
        return [res]
    def spot_diagram_raytrace(self, **kwargs):
        spot_diagram_raytrace = SpotDiagramRayTrace()
        res = spot_diagram_raytrace.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', 0),
            pattern=kwargs.get('pattern', 'hexapolar'),
            refer_to=kwargs.get('refer_to', 'chiefray'),
            show_scale=kwargs.get('show_scale', 'scalebar'),
            color_rays_by=kwargs.get('color_rays_by', 'fields'),
            ray_density=kwargs.get('ray_density', 6),
            configuration=kwargs.get('configuration', 0),
            direction_cosines=kwargs.get('direction_cosines', False),
            use_symbols=kwargs.get('use_symbols', False),
            use_polarization=kwargs.get('use_polarization', False),
            scatter_rays=kwargs.get('scatter_rays', False),
            show_airy_disk=kwargs.get('show_airy_disk', False),
            ignore_lateral_color=kwargs.get('ignore_lateral_color', False),
            plot_scale=kwargs.get('plot_scale', 0.0),
            delta_focus=kwargs.get('delta_focus', 0.0),
            exaggerate=kwargs.get('exaggerate', 0.0)
        )
        return [res]
    def spot_diagram_through_focus(self, **kwargs):
        spot_diagram_through_focus = SpotDiagramThroughFocus()
        res = spot_diagram_through_focus.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', 0),
            pattern=kwargs.get('pattern', 'hexapolar'),
            refer_to=kwargs.get('refer_to', 'chiefray'),
            ray_density=kwargs.get('ray_density', 6),
            show_airy_disk=kwargs.get('show_airy_disk', False),
            focus_delta_um=kwargs.get('focus_delta_um', 50),
            config_number=kwargs.get('config_number', 1)
        )
        return [res]
    def through_focus(self, **kwargs):
        through_focus = ThroughFocus()

        pwav = self.extremes['wave_primary']['number']
        # use `wavelength=0` for polychromatic

        res = through_focus.run(
            wavelength=kwargs.get('wavelength', pwav),
            ray_density=kwargs.get('ray_density', 3),
            focus_density=kwargs.get('focus_density', 15),
            data=kwargs.get('data', 'strehlratio'),
            refer_to=kwargs.get('refer_to', 'centroid'),
            method=kwargs.get('method', 'gaussquad'),
            show_diffraction_limit=kwargs.get('show_diffraction_limit', False),
            use_polarization=kwargs.get('use_polarization', False),
            minimum_focus=kwargs.get('minimum_focus', -0.01),
            maximum_focus=kwargs.get('maximum_focus', 0.01)
        )
        return [res]
    def transmission(self, **kwargs):
        transmission = Transmission()

        pwav = self.extremes['wave_primary']['number']

        field_min = self.extremes['field_min']['number']
        field_max = self.extremes['field_max']['number']

        res_min = transmission.run(
            field=kwargs.get('field', field_min),
            wavelength=pwav,
            number_of_rays=51
        )
        res_max = transmission.run(
            field=kwargs.get('field', field_max),
            wavelength=pwav,
            number_of_rays=51
        )
        return [res_min, res_max]
    def wave_fan(self, **kwargs):
        wave_fan = WaveFan()
        res = wave_fan.run(
            field=kwargs.get('field', 0),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', 0),
            number_of_rays=kwargs.get('number_of_rays', 20),
            check_apertures=kwargs.get('check_apertures', True),
            vignetted_pupil=kwargs.get('vignetted_pupil', True)
        )
        return [res]
    def wavefront(self, **kwargs):
        wavefront = Wavefront()

        pwav = self.extremes['wave_primary']['number']
        field_min = self.extremes['field_min']['number']
        field_max = self.extremes['field_max']['number']

        res_min = wavefront.run(
            field=kwargs.get('field', field_min),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            rotation=kwargs.get('rotation', 'rotate_0'),
            sampling=kwargs.get('sampling', 's_64x64'),
            polarization=kwargs.get('polarization', 'none'),
            reference_to_primary=kwargs.get('reference_to_primary', False),
            use_exit_pupil=kwargs.get('use_exit_pupil', True),
            remove_tilt=kwargs.get('remove_tilt', False),
            subaperture_x=kwargs.get('subaperture_x', 0.0),
            subaperture_y=kwargs.get('subaperture_y', 0.0),
            subaperture_r=kwargs.get('subaperture_r', 1.0)
        )
        res_max = wavefront.run(
            field=kwargs.get('field', field_max),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            rotation=kwargs.get('rotation', 'rotate_0'),
            sampling=kwargs.get('sampling', 's_64x64'),
            polarization=kwargs.get('polarization', 'none'),
            reference_to_primary=kwargs.get('reference_to_primary', False),
            use_exit_pupil=kwargs.get('use_exit_pupil', True),
            remove_tilt=kwargs.get('remove_tilt', False),
            subaperture_x=kwargs.get('subaperture_x', 0.0),
            subaperture_y=kwargs.get('subaperture_y', 0.0),
            subaperture_r=kwargs.get('subaperture_r', 1.0)
        )
        return [res_min, res_max]
    def y_ybar(self, **kwargs):
        y_ybar = Y_YBar()

        pwav = self.extremes['wave_primary']['number']
        res = y_ybar.run(
            wavelength=kwargs.get('wavelength', pwav),
            first_surface=kwargs.get('first_surface', 1),
            last_surface=kwargs.get('last_surface', 0)
        )
        return [res]
    def zernike(self, **kwargs):
        zernike = Zernike()

        pwav = self.extremes['wave_primary']['number']
        field_min = self.extremes['field_min']['number']
        field_max = self.extremes['field_max']['number']

        res_min = zernike.run(
            window=kwargs.get('window', 'standard'),
            field=kwargs.get('field', field_min),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            sample_size=kwargs.get('sample_size', 's_64x64'),
            reference_to_vertex=kwargs.get('reference_to_vertex', False),
            obscuration=kwargs.get('obscuraton', 0.5)
        )
        res_max = zernike.run(
            window=kwargs.get('window', 'standard'),
            field=kwargs.get('field', field_max),
            surface=kwargs.get('surface', 0),
            wavelength=kwargs.get('wavelength', pwav),
            sample_size=kwargs.get('sample_size', 's_64x64'),
            reference_to_vertex=kwargs.get('reference_to_vertex', False),
            obscuration=kwargs.get('obscuraton', 0.5)
        )

        d_min = json.loads(res_min['data'][0])
        d_max = json.loads(res_max['data'][0])

        rows = []
        for entry_min, entry_max in zip(d_min, d_max):
            key = list(entry_min.keys())[0]
            rows.append({
                'Zn': key,
                'on_axis': entry_min[key],
                'full_field': entry_max[key]
            })

        df = pd.DataFrame(rows)

        res = {
            'type': 'table',
            'settings': res_min['settings'],
            'header': res_min['header'],
            'data': [df.to_json(orient='records')]
        }

        return [res]
    def get_extremes(self):
        if self.is_nonsequential():
            return {'wave_min': {'number': 1}, 'wave_max': {'number': 1},
                    'wave_primary': {'number': 1},
                    'field_min': {'number': 1}, 'field_max': {'number': 1}}

        # get the shortest wavelength @ f1
        wave_min = {'number': 1, 'value': 9e9}
        wave_max = {'number': 1, 'value': -9e9}
        wave_prim = {'number': 1, 'value': 0.55}
        for i in range(1, self.zos.TheSystem.SystemData.Wavelengths.NumberOfWavelengths + 1):
            tw = self.zos.TheSystem.SystemData.Wavelengths.GetWavelength(i)
            if tw.Wavelength < wave_min['value']: 
                wave_min = {'number': i, 'value': tw.Wavelength}
            if tw.Wavelength > wave_max['value']: 
                wave_max = {'number': i, 'value': tw.Wavelength}
            if tw.IsPrimary: 
                wave_prim = {'number': i, 'value': tw.Wavelength}
        
        # assume radial for simplicity
        field_min = {'number': 1, 'fx': 9e9, 'fy': 9e9, 'r': 9e9}
        field_max = {'number': 1, 'fx': 0.0, 'fy': 0.0, 'r': 0.0}
        for i in range(1, self.zos.TheSystem.SystemData.Fields.NumberOfFields + 1):
            tf = self.zos.TheSystem.SystemData.Fields.GetField(i)
            if (tf.X**2 + tf.Y**2) > field_max['r']: 
                field_max = {'number': i, 'fx': tf.X, 'fy': tf.Y, 'r': tf.X**2 + tf.Y**2}
            if (tf.X**2 + tf.Y**2) < field_min['r']: 
                field_min = {'number': i, 'fx': tf.X, 'fy': tf.Y, 'r': tf.X**2 + tf.Y**2}
        
        return {'wave_min': wave_min, 'wave_max': wave_max, 'wave_primary': wave_prim, 'field_min': field_min, 'field_max': field_max}

if __name__ == '__main__':
    pass
