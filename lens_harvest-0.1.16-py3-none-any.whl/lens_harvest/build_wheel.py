# MIT License
#
# Copyright (c) 2026 Paraxial
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
Build the lens_harvest wheel from a sanitized copy of the source.

Why this exists:
    Most modules carry an `if __name__ == '__main__':` block used only for local,
    interactive testing. Those blocks contain hard-coded developer filepaths
    (e.g. C:\\Users\\...). They are never executed when the package runs as
    a CLI (`python -m lens_harvest parse|viewer` goes through __main__.py), so we
    strip them out of the shipped wheel.

What it does:
    1. Copies the package into a temporary staging directory (your working tree is
       left completely untouched).
    2. In the staging copy, replaces the body of every `if __name__ == '__main__':`
       block with a single `pass` -- EXCEPT in __main__.py, whose guard is the real
       CLI entry point and must be preserved.
    3. Runs `pip wheel` from the staging copy, emitting the wheel into ./dist.
    4. Deletes the staging directory.

Usage (run from the repo root, C:\\git\\paraxial-product-management\\lens_harvest):
    c:/python313/python.exe build_wheel.py

    # keep the staging copy for inspection instead of deleting it:
    c:/python313/python.exe build_wheel.py --keep-staging
"""

import argparse
import ast
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parent

# files/dirs we never copy into the staging build
EXCLUDE_DIRS = {"build", "dist", "__pycache__", ".git", "build_staging"}
EXCLUDE_SUFFIX = ".egg-info"

# modules whose __main__ guard must be kept intact (the actual CLI entry point)
KEEP_GUARD = {"__main__.py"}


def _should_skip(path: Path) -> bool:
    parts = set(path.parts)
    if parts & EXCLUDE_DIRS:
        return True
    return any(p.endswith(EXCLUDE_SUFFIX) for p in path.parts)


def strip_main_guard(py_path: Path) -> bool:
    """Replace the body of the module-level `if __name__ == '__main__':` block
    with a single `pass`. Returns True if the file was modified."""
    source = py_path.read_text(encoding="utf-8")
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        print(f"  !! skipping (syntax error): {py_path} ({e})")
        return False

    for node in tree.body:  # module level only
        if not isinstance(node, ast.If):
            continue
        test = node.test
        if (
            isinstance(test, ast.Compare)
            and isinstance(test.left, ast.Name)
            and test.left.id == "__name__"
            and len(test.comparators) == 1
            and isinstance(test.comparators[0], ast.Constant)
            and test.comparators[0].value == "__main__"
        ):
            # keep every line up to and including the `if __name__ ...:` line,
            # then drop the body and append a single `pass`.
            lines = source.splitlines()
            head = lines[: node.lineno]  # node.lineno is 1-based -> includes the if line
            head.append("    pass")
            py_path.write_text("\n".join(head) + "\n", encoding="utf-8")
            return True
    return False


def read_version() -> str:
    """Read the single source of truth for the package version from pyproject.toml."""
    text = (REPO / "pyproject.toml").read_text(encoding="utf-8")
    m = re.search(r'^version\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
    if not m:
        sys.exit("Could not find version in pyproject.toml")
    return m.group(1)


def sync_readme_version(version: str) -> None:
    """Rewrite the wheel filename references in README.md to match `version`.
    Keeps the install instructions in sync with pyproject.toml's version."""
    readme = REPO / "README.md"
    text = readme.read_text(encoding="utf-8")
    updated = re.sub(
        r"lens_harvest-\d+\.\d+\.\d+-py3-none-any\.whl",
        f"lens_harvest-{version}-py3-none-any.whl",
        text,
    )
    if updated != text:
        readme.write_text(updated, encoding="utf-8")
        print(f"Synced README.md wheel references -> {version}")
    else:
        print(f"README.md already references {version}")


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--keep-staging", action="store_true",
                        help="do not delete the temporary staging directory")
    args = parser.parse_args()

    # keep README install instructions in sync with the pyproject.toml version
    # before staging, so the synced README is what ships in the wheel
    version = read_version()
    sync_readme_version(version)

    dist_dir = REPO / "dist"
    staging_root = Path(tempfile.mkdtemp(prefix="lens_harvest_build_"))
    staging = staging_root / "lens_harvest"

    print(f"Staging copy -> {staging}")
    shutil.copytree(
        REPO,
        staging,
        ignore=lambda d, names: [
            n for n in names
            if n in EXCLUDE_DIRS or n.endswith(EXCLUDE_SUFFIX)
        ],
    )

    print("Stripping __main__ guards (dev-only code + hard-coded paths):")
    stripped = 0
    for py in sorted(staging.rglob("*.py")):
        rel = py.relative_to(staging)
        if _should_skip(rel):
            continue
        if py.name in KEEP_GUARD:
            print(f"  keep   {rel}")
            continue
        if strip_main_guard(py):
            stripped += 1
            print(f"  strip  {rel}")
    print(f"Stripped {stripped} file(s).")

    dist_dir.mkdir(exist_ok=True)
    print(f"\nBuilding wheel into {dist_dir} ...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "wheel", ".", "--no-deps",
         "--wheel-dir", str(dist_dir)],
        cwd=str(staging),
    )

    if args.keep_staging:
        print(f"\nStaging kept at: {staging_root}")
    else:
        shutil.rmtree(staging_root, ignore_errors=True)

    if result.returncode != 0:
        sys.exit(result.returncode)

    print("\nDone. Wheel(s) in:", dist_dir)


if __name__ == "__main__":
    pass
